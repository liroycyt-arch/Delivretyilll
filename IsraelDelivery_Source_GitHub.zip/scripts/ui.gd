class_name UI
extends CanvasLayer
## כל הממשק נבנה בקוד: תפריטים, הגדרת דמות, HUD, טלפון ואפליקציותיו. עברית מלאה, פריסת RTL.

var main = null
var root: Control
var screen: Control = null
var hud: Control
var phone: PanelContainer
var phone_body: VBoxContainer
var phone_page := "home"
var phone_open := false
var toasts: VBoxContainer
var prompt: Label
var l_money: Label
var l_speed: Label
var l_mission: Label
var l_nav: Label
var l_rank: Label
var l_dbg: Label
var minimap: MapView
var loading_bar: ProgressBar
var preview_fig: Figure = null
var _look := {}
var _setup_name := ""
var _setup_company := "mishloha"
var _setup_vehicle := "ebike"


func _ready() -> void:
    process_mode = Node.PROCESS_MODE_ALWAYS
    root = Control.new()
    root.set_anchors_preset(Control.PRESET_FULL_RECT)
    root.layout_direction = Control.LAYOUT_DIRECTION_RTL
    root.theme = _make_theme()
    root.mouse_filter = Control.MOUSE_FILTER_IGNORE
    add_child(root)
    _build_hud()
    _build_phone()
    Game.notify.connect(toast)
    Game.money_changed.connect(_refresh_phone)
    Game.mission_changed.connect(_refresh_phone)


func _process(delta: float) -> void:
    if preview_fig != null and is_instance_valid(preview_fig):
        preview_fig.rotation.y += delta * 0.6


# ---------- עיצוב ----------
func _sb(c: Color, r := 14, border := Color(1, 1, 1, 0.0), bw := 0) -> StyleBoxFlat:
    var s := StyleBoxFlat.new()
    s.bg_color = c
    s.set_corner_radius_all(r)
    s.border_color = border
    s.set_border_width_all(bw)
    s.content_margin_left = 14
    s.content_margin_right = 14
    s.content_margin_top = 8
    s.content_margin_bottom = 8
    return s


func _make_theme() -> Theme:
    var th := Theme.new()
    th.default_font = Game.font
    th.default_font_size = 20
    th.set_stylebox("normal", "Button", _sb(Color(1, 1, 1, 0.12), 14, Color(1, 1, 1, 0.25), 1))
    th.set_stylebox("hover", "Button", _sb(Color(1, 1, 1, 0.22), 14, Color(1, 1, 1, 0.4), 1))
    th.set_stylebox("pressed", "Button", _sb(Color(1, 0.84, 0, 0.35), 14, Color(1, 0.84, 0, 0.8), 1))
    th.set_stylebox("disabled", "Button", _sb(Color(1, 1, 1, 0.05), 14))
    th.set_stylebox("focus", "Button", StyleBoxEmpty.new())
    th.set_color("font_color", "Button", Color.WHITE)
    th.set_color("font_disabled_color", "Button", Color(1, 1, 1, 0.35))
    th.set_color("font_color", "Label", Color.WHITE)
    th.set_color("font_color", "CheckBox", Color.WHITE)
    th.set_stylebox("panel", "PanelContainer", _sb(Color(0.06, 0.09, 0.14, 0.82), 22, Color(1, 1, 1, 0.18), 1))
    th.set_stylebox("normal", "LineEdit", _sb(Color(1, 1, 1, 0.1), 12, Color(1, 1, 1, 0.25), 1))
    th.set_color("font_color", "LineEdit", Color.WHITE)
    th.set_stylebox("normal", "OptionButton", _sb(Color(1, 1, 1, 0.12), 12, Color(1, 1, 1, 0.25), 1))
    th.set_color("font_color", "OptionButton", Color.WHITE)
    return th


func _lbl(text: String, size := 20, col := Color.WHITE, center := false) -> Label:
    var l := Label.new()
    l.text = text
    l.add_theme_font_size_override("font_size", size)
    l.add_theme_color_override("font_color", col)
    if center:
        l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    return l


func _wrap(text: String, w := 330.0, size := 18) -> Label:
    var l := _lbl(text, size)
    l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    l.custom_minimum_size.x = w
    return l


func _btn(text: String, cb: Callable, w := 0.0) -> Button:
    var b := Button.new()
    b.text = text
    b.custom_minimum_size = Vector2(w, 44)
    b.focus_mode = Control.FOCUS_NONE
    b.pressed.connect(cb)
    return b


func _set_screen(c: Control) -> void:
    if screen != null and is_instance_valid(screen):
        screen.queue_free()
    screen = c
    root.add_child(c)
    root.move_child(c, 0)


func _full(bgc := Color("0e1726")) -> Control:
    var c := Control.new()
    c.set_anchors_preset(Control.PRESET_FULL_RECT)
    var bg := ColorRect.new()
    bg.color = bgc
    bg.set_anchors_preset(Control.PRESET_FULL_RECT)
    c.add_child(bg)
    return c


func _centered(c: Control, inner: Control) -> void:
    var cc := CenterContainer.new()
    cc.set_anchors_preset(Control.PRESET_FULL_RECT)
    c.add_child(cc)
    cc.add_child(inner)


func clear_screen() -> void:
    if screen != null and is_instance_valid(screen):
        screen.queue_free()
    screen = null


# ---------- מסכים ----------
func show_main_menu() -> void:
    hud.visible = false
    close_phone()
    var c := _full()
    var art := TextureRect.new()
    art.texture = load("res://logo.png")
    art.set_anchors_preset(Control.PRESET_FULL_RECT)
    art.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
    art.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_COVERED
    c.add_child(art)
    var shade := ColorRect.new()
    shade.color = Color(0.03, 0.05, 0.1, 0.62)
    shade.set_anchors_preset(Control.PRESET_FULL_RECT)
    c.add_child(shade)
    var v := VBoxContainer.new()
    v.add_theme_constant_override("separation", 14)
    var logo := TextureRect.new()
    logo.texture = load("res://icon.png")
    logo.custom_minimum_size = Vector2(150, 150)
    logo.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
    logo.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
    v.add_child(logo)
    v.add_child(_lbl("משלוחים בישראל", 56, Color("ffd600"), true))
    v.add_child(_lbl("סימולטור שליחויות בתל אביב", 22, Color(1, 1, 1, 0.7), true))
    v.add_child(_btn("משחק חדש", main.new_game, 320))
    var cont := _btn("המשך משחק", main.continue_game, 320)
    cont.disabled = not Game.has_save
    v.add_child(cont)
    v.add_child(_btn("הגדרות", func(): show_settings(show_main_menu), 320))
    v.add_child(_btn("יציאה", func(): main.quit_game(), 320))
    _centered(c, v)
    _set_screen(c)


func _opt_row(parent: Control, title: String, items: Array, sel: int, cb: Callable) -> void:
    var h := HBoxContainer.new()
    var l := _lbl(title, 20)
    l.custom_minimum_size.x = 120
    h.add_child(l)
    var o := OptionButton.new()
    for it in items:
        o.add_item(it)
    o.select(clampi(sel, 0, items.size() - 1))
    o.item_selected.connect(cb)
    o.custom_minimum_size.x = 200
    h.add_child(o)
    parent.add_child(h)


func _vehicle_card(k: String) -> Control:
    var v: Dictionary = Game.VEHICLES[k]
    var p := PanelContainer.new()
    var b := VBoxContainer.new()
    b.add_child(_lbl(v.name, 22, Color("ffd600"), true))
    var rows := [["מהירות מרבית", "%d קמ״ש" % int(v.max)], ["תאוצה", "%d/10" % v.accel], ["יכולת תמרון", "%d/10" % v.handling], ["נוחות", "%d/10" % v.comfort], ["אמינות", "%d/10" % v.reliab], ["עלות תחזוקה", v.maint]]
    for r in rows:
        b.add_child(_lbl("%s: %s" % [r[0], r[1]], 17))
    p.add_child(b)
    p.set_meta("key", k)
    return p


func show_setup() -> void:
    hud.visible = false
    _look = Game.look.duplicate()
    _setup_name = ""
    _setup_company = "mishloha"
    _setup_vehicle = "ebike"
    var c := _full(Color("111c2e"))
    var h := HBoxContainer.new()
    h.add_theme_constant_override("separation", 30)
    h.set_anchors_preset(Control.PRESET_FULL_RECT)
    h.offset_left = 40
    h.offset_right = -40
    h.offset_top = 30
    h.offset_bottom = -30
    c.add_child(h)
    var side := VBoxContainer.new()
    var svc := SubViewportContainer.new()
    svc.custom_minimum_size = Vector2(340, 480)
    svc.stretch = true
    var vp := SubViewport.new()
    vp.own_world_3d = true
    vp.transparent_bg = true
    vp.size = Vector2i(340, 480)
    svc.add_child(vp)
    var cam := Camera3D.new()
    cam.fov = 38.0
    vp.add_child(cam)
    cam.look_at_from_position(Vector3(0, 1.05, 3.2), Vector3(0, 0.9, 0))
    var dl := DirectionalLight3D.new()
    dl.rotation_degrees = Vector3(-35, -25, 0)
    vp.add_child(dl)
    var we := WorldEnvironment.new()
    var en := Environment.new()
    en.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
    en.ambient_light_color = Color(0.7, 0.75, 0.85)
    we.environment = en
    vp.add_child(we)
    preview_fig = Figure.new()
    preview_fig.rotation.y = PI
    vp.add_child(preview_fig)
    side.add_child(svc)
    h.add_child(side)
    var sc := ScrollContainer.new()
    sc.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    sc.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
    var f := VBoxContainer.new()
    f.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    f.add_theme_constant_override("separation", 10)
    sc.add_child(f)
    h.add_child(sc)
    f.add_child(_lbl("יצירת שליח", 36, Color("ffd600")))
    var nrow := HBoxContainer.new()
    var nl := _lbl("שם", 20)
    nl.custom_minimum_size.x = 120
    nrow.add_child(nl)
    var le := LineEdit.new()
    le.max_length = 16
    le.placeholder_text = "שם השליח"
    le.custom_minimum_size.x = 260
    le.text_changed.connect(func(t): _setup_name = t)
    nrow.add_child(le)
    f.add_child(nrow)
    _opt_row(f, "גוון עור", ["בהיר מאוד", "בהיר", "בינוני", "כהה", "כהה מאוד"], int(_look.skin), func(i): _look.skin = i; _refresh_preview())
    _opt_row(f, "תסרוקת", ["קצרה", "קצוצה", "ארוכה", "ללא שיער"], int(_look.hair_style), func(i): _look.hair_style = i; _refresh_preview())
    _opt_row(f, "צבע שיער", ["שחור", "חום כהה", "ערמוני", "בלונד", "אפור"], int(_look.hair_color), func(i): _look.hair_color = i; _refresh_preview())
    _opt_row(f, "מבנה גוף", ["רזה", "רגיל", "רחב"], int(_look.body), func(i): _look.body = i; _refresh_preview())
    _opt_row(f, "מכנסיים", ["ארוכים", "קצרים"], 1 if _look.shorts else 0, func(i): _look.shorts = (i == 1); _refresh_preview())
    _opt_row(f, "צבע קסדה", ["לבן", "שחור", "אדום", "כחול", "צהוב"], int(_look.helmet), func(i): _look.helmet = i; _refresh_preview())
    f.add_child(_lbl("חברת משלוחים (הבגדים משתנים בהתאם)", 22, Color("ffd600")))
    _opt_row(f, "חברה", ["משלוחה (צהוב)", "וולט (כחול)", "שליח עצמאי (שחור)"], 0, func(i): _setup_company = ["mishloha", "wolt", "indie"][i]; _refresh_preview())
    f.add_child(_lbl("כלי תחבורה", 22, Color("ffd600")))
    var vr := HBoxContainer.new()
    vr.add_theme_constant_override("separation", 12)
    for k in ["ebike", "scooter", "moped"]:
        var card := _vehicle_card(k)
        vr.add_child(card)
    f.add_child(vr)
    _opt_row(f, "בחירה", ["אופניים חשמליים", "קורקינט חשמלי", "קטנוע ישן"], 0, func(i): _setup_vehicle = ["ebike", "scooter", "moped"][i])
    var go := _btn("התחל לעבוד", func(): _finish_setup(), 320)
    f.add_child(go)
    f.add_child(_btn("חזרה", show_main_menu, 320))
    _set_screen(c)
    _refresh_preview()


func _refresh_preview() -> void:
    if preview_fig != null and is_instance_valid(preview_fig):
        preview_fig.build(_look, _setup_company)
        preview_fig.helmet_node.visible = true


func _finish_setup() -> void:
    Game.player_name = Game.sanitize_name(_setup_name)
    Game.look = _look.duplicate()
    Game.company = _setup_company
    Game.vehicle = _setup_vehicle
    Game.owned = [_setup_vehicle]
    preview_fig = null
    main.begin_play(true)


func show_loading() -> void:
    hud.visible = false
    var c := _full(Color("0e1726"))
    var v := VBoxContainer.new()
    v.add_theme_constant_override("separation", 16)
    v.add_child(_lbl("טוען את תל אביב...", 40, Color("ffd600"), true))
    loading_bar = ProgressBar.new()
    loading_bar.custom_minimum_size = Vector2(480, 24)
    loading_bar.max_value = 1.0
    v.add_child(loading_bar)
    _centered(c, v)
    _set_screen(c)


func set_progress(p: float) -> void:
    if loading_bar != null and is_instance_valid(loading_bar):
        loading_bar.value = p


func show_pause() -> void:
    var c := Control.new()
    c.set_anchors_preset(Control.PRESET_FULL_RECT)
    var bg := ColorRect.new()
    bg.color = Color(0, 0, 0, 0.55)
    bg.set_anchors_preset(Control.PRESET_FULL_RECT)
    c.add_child(bg)
    var v := VBoxContainer.new()
    v.add_theme_constant_override("separation", 12)
    v.add_child(_lbl("השהיה", 44, Color("ffd600"), true))
    v.add_child(_btn("המשך", main.resume, 300))
    v.add_child(_btn("הגדרות", func(): show_settings(show_pause), 300))
    v.add_child(_btn("שמור וחזור לתפריט", main.save_and_menu, 300))
    v.add_child(_btn("שמור ויציאה", main.quit_game, 300))
    _centered(c, v)
    _set_screen(c)


func show_settings(back: Callable) -> void:
    var s: Dictionary = Game.settings
    var c := _full(Color("0e1726"))
    var v := VBoxContainer.new()
    v.add_theme_constant_override("separation", 10)
    v.custom_minimum_size.x = 560
    v.add_child(_lbl("הגדרות", 40, Color("ffd600"), true))
    _slider(v, "עוצמת קול", float(s.volume), 0.0, 1.0, 0.05, func(x): s.volume = x)
    _slider(v, "שדה ראייה", float(s.fov), 60.0, 100.0, 1.0, func(x): s.fov = x)
    _slider(v, "משך התראות (שניות)", float(s.notify_sec), 2.0, 8.0, 0.5, func(x): s.notify_sec = x)
    _opt_row(v, "שעה ביום", ["בוקר", "צהריים", "אחר הצהריים", "ערב"], [8.0, 12.0, 16.0, 19.0].find(float(s.time)), func(i): s.time = [8.0, 12.0, 16.0, 19.0][i]; main.apply_settings())
    _opt_row(v, "איכות / מרחק ציור", ["נמוכה", "בינונית", "גבוהה"], int(s.quality), func(i): s.quality = i; main.apply_settings())
    _opt_row(v, "הגבלת FPS", ["30", "60", "120", "ללא הגבלה"], [30, 60, 120, 0].find(int(s.fps)), func(i): s.fps = [30, 60, 120, 0][i]; main.apply_settings())
    _check(v, "צללים", bool(s.shadows), func(b): s.shadows = b; main.apply_settings())
    _check(v, "מסך מלא", bool(s.fullscreen), func(b): s.fullscreen = b; main.apply_settings())
    _check(v, "השתק צלילי התראות", bool(s.mute_notify), func(b): s.mute_notify = b)
    _check(v, "קול ניווט בעברית (תלוי בקול Windows מותקן)", bool(s.voice), func(b): s.voice = b)
    v.add_child(_lbl("מקשים: W/A/S/D תנועה · רווח בלימה · E פעולה · M מפה · P טלפון · C מצלמה · Esc השהיה", 16, Color(1, 1, 1, 0.65)))
    v.add_child(_lbl("שינוי מקשים: עדיין לא זמין בגרסה זו", 16, Color(1, 1, 1, 0.45)))
    v.add_child(_btn("חזרה", func(): Game.save_game(); back.call(), 240))
    _centered(c, v)
    _set_screen(c)


func _slider(parent: Control, title: String, val: float, mn: float, mx: float, step: float, cb: Callable) -> void:
    var h := HBoxContainer.new()
    var l := _lbl(title, 20)
    l.custom_minimum_size.x = 250
    h.add_child(l)
    var sl := HSlider.new()
    sl.min_value = mn
    sl.max_value = mx
    sl.step = step
    sl.value = val
    sl.custom_minimum_size = Vector2(260, 24)
    sl.value_changed.connect(func(x): cb.call(x); main.apply_settings())
    h.add_child(sl)
    parent.add_child(h)


func _check(parent: Control, title: String, val: bool, cb: Callable) -> void:
    var cbx := CheckBox.new()
    cbx.text = title
    cbx.button_pressed = val
    cbx.toggled.connect(cb)
    parent.add_child(cbx)


func show_summary(d: Dictionary) -> void:
    if d.is_empty():
        return
    var p := PanelContainer.new()
    var v := VBoxContainer.new()
    v.add_child(_lbl("המשלוח הושלם", 34, Color("2ecc71"), true))
    v.add_child(_lbl("מסעדה: %s" % d.rest, 20))
    v.add_child(_lbl("כתובת: %s" % d.addr, 20))
    v.add_child(_lbl("זמן: %d שניות — %s" % [d.time, "בזמן" if d.on_time else "באיחור"], 20))
    v.add_child(_lbl("תשלום: %d ₪" % d.pay, 24, Color("ffd600")))
    v.add_child(_lbl("עלות תחזוקה: %d ₪" % d.cost, 18, Color(1, 1, 1, 0.7)))
    v.add_child(_btn("אישור", func(): p.queue_free(), 200))
    p.add_child(v)
    root.add_child(p)
    p.set_anchors_and_offsets_preset(Control.PRESET_CENTER, Control.PRESET_MODE_MINSIZE)
    p.grow_horizontal = Control.GROW_DIRECTION_BOTH
    p.grow_vertical = Control.GROW_DIRECTION_BOTH
    var tw := p.create_tween()
    tw.tween_interval(8.0)
    tw.tween_callback(p.queue_free)


# ---------- HUD ----------
func _build_hud() -> void:
    hud = Control.new()
    hud.set_anchors_preset(Control.PRESET_FULL_RECT)
    hud.mouse_filter = Control.MOUSE_FILTER_IGNORE
    hud.visible = false
    root.add_child(hud)
    var tr := PanelContainer.new()
    var v := VBoxContainer.new()
    l_money = _lbl("", 30, Color("ffd600"))
    l_rank = _lbl("", 16, Color(1, 1, 1, 0.75))
    v.add_child(l_money)
    v.add_child(l_rank)
    tr.add_child(v)
    hud.add_child(tr)
    tr.set_anchors_and_offsets_preset(Control.PRESET_TOP_RIGHT, Control.PRESET_MODE_MINSIZE, 16)
    tr.grow_horizontal = Control.GROW_DIRECTION_BEGIN
    var left := VBoxContainer.new()
    minimap = MapView.new()
    minimap.range_m = 230.0
    minimap.custom_minimum_size = Vector2(230, 230)
    left.add_child(minimap)
    var mp := PanelContainer.new()
    var mv := VBoxContainer.new()
    l_mission = _wrap("", 230, 17)
    l_nav = _wrap("", 230, 17)
    l_nav.add_theme_color_override("font_color", Color("4dd0ff"))
    mv.add_child(l_mission)
    mv.add_child(l_nav)
    mp.add_child(mv)
    left.add_child(mp)
    hud.add_child(left)
    left.set_anchors_and_offsets_preset(Control.PRESET_TOP_LEFT, Control.PRESET_MODE_MINSIZE, 16)
    var br := PanelContainer.new()
    l_speed = _lbl("", 30)
    br.add_child(l_speed)
    hud.add_child(br)
    br.set_anchors_and_offsets_preset(Control.PRESET_BOTTOM_RIGHT, Control.PRESET_MODE_MINSIZE, 16)
    br.grow_horizontal = Control.GROW_DIRECTION_BEGIN
    br.grow_vertical = Control.GROW_DIRECTION_BEGIN
    l_dbg = _lbl("", 14, Color(1, 1, 1, 0.5))
    hud.add_child(l_dbg)
    l_dbg.set_anchors_and_offsets_preset(Control.PRESET_BOTTOM_LEFT, Control.PRESET_MODE_MINSIZE, 12)
    l_dbg.grow_vertical = Control.GROW_DIRECTION_BEGIN
    toasts = VBoxContainer.new()
    toasts.mouse_filter = Control.MOUSE_FILTER_IGNORE
    hud.add_child(toasts)
    toasts.set_anchors_and_offsets_preset(Control.PRESET_CENTER_TOP, Control.PRESET_MODE_MINSIZE, 16)
    toasts.grow_horizontal = Control.GROW_DIRECTION_BOTH
    prompt = _lbl("", 26, Color.WHITE, true)
    prompt.add_theme_color_override("font_outline_color", Color.BLACK)
    prompt.add_theme_constant_override("outline_size", 6)
    hud.add_child(prompt)
    prompt.set_anchors_and_offsets_preset(Control.PRESET_CENTER_BOTTOM, Control.PRESET_MODE_MINSIZE, 90)
    prompt.grow_horizontal = Control.GROW_DIRECTION_BOTH
    prompt.grow_vertical = Control.GROW_DIRECTION_BEGIN
    prompt.custom_minimum_size.x = 700


func show_hud(p: Player, w: World) -> void:
    hud.visible = true
    minimap.world = w
    minimap.player = p


func set_prompt(t: String) -> void:
    prompt.text = t


func update_hud(p: Player, w: World) -> void:
    l_money.text = "%d ₪" % Game.balance
    l_rank.text = "%s · %s" % [Game.player_name, Game.rank_name()]
    l_speed.text = "%d קמ״ש" % roundi(absf(p.speed) * 3.6)
    var m: Dictionary = Game.mission
    var t := ""
    if not m.is_empty():
        var rest: Dictionary = w.poi(m.ri, m.rj)
        var home: Dictionary = w.poi(m.hi, m.hj)
        var left := int(m.limit) - int(m.elapsed)
        var tm := "%d:%02d" % [absi(left) / 60, absi(left) % 60] if left >= 0 else "באיחור"
        match str(m.state):
            "offered":
                t = "הזמנה חדשה ממתינה בטלפון (P)"
            "to_pickup":
                t = "איסוף: %s\nתשלום: %d ₪ · זמן: %s" % [rest.name, m.pay, tm]
            "to_customer":
                t = "מסירה: %s\n%s · זמן: %s" % [home.addr, m.note, tm]
    l_mission.text = t
    l_nav.text = ("%s\nנותרו %d מ׳" % [Game.nav_text, roundi(Game.nav_remaining)]) if Game.nav_active else ""
    l_dbg.text = "FPS %d · אזורים טעונים %d" % [Engine.get_frames_per_second(), w.chunks.size()]


func toast(text: String) -> void:
    var p := PanelContainer.new()
    p.add_child(_lbl(text, 20))
    toasts.add_child(p)
    while toasts.get_child_count() > 3:
        var c := toasts.get_child(0)
        toasts.remove_child(c)
        c.queue_free()
    var tw := p.create_tween()
    tw.tween_interval(float(Game.settings.get("notify_sec", 4.0)))
    tw.tween_property(p, "modulate:a", 0.0, 0.4)
    tw.tween_callback(p.queue_free)


# ---------- טלפון ----------
func _build_phone() -> void:
    phone = PanelContainer.new()
    phone.visible = false
    phone.add_theme_stylebox_override("panel", _sb(Color(0.02, 0.03, 0.05, 0.96), 38, Color(0.25, 0.27, 0.3), 6))
    var v := VBoxContainer.new()
    var top := HBoxContainer.new()
    top.add_child(_lbl("הטלפון של השליח", 16, Color(1, 1, 1, 0.6)))
    var sp := Control.new()
    sp.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    top.add_child(sp)
    top.add_child(_btn("סגור", func(): main.set_phone(false), 70))
    v.add_child(top)
    var sc := ScrollContainer.new()
    sc.custom_minimum_size = Vector2(380, 620)
    sc.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
    phone_body = VBoxContainer.new()
    phone_body.add_theme_constant_override("separation", 8)
    phone_body.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    sc.add_child(phone_body)
    v.add_child(sc)
    v.add_child(_btn("מסך הבית", func(): open_app("home")))
    phone.add_child(v)
    root.add_child(phone)
    phone.set_anchors_and_offsets_preset(Control.PRESET_CENTER_RIGHT, Control.PRESET_MODE_MINSIZE, 24)
    phone.grow_horizontal = Control.GROW_DIRECTION_BEGIN
    phone.grow_vertical = Control.GROW_DIRECTION_BOTH


func open_phone(page := "home") -> void:
    phone_open = true
    phone.visible = true
    open_app(page)


func close_phone() -> void:
    phone_open = false
    if phone != null:
        phone.visible = false


func open_app(page: String) -> void:
    phone_page = page
    for c in phone_body.get_children():
        phone_body.remove_child(c)
        c.queue_free()
    match page:
        "home":
            _page_home()
        "delivery":
            _page_delivery()
        "map":
            _page_map()
        "bank":
            _page_bank()
        "msgs":
            _page_msgs()
        "profile":
            _page_profile()
        "vehicle":
            _page_vehicle()
        "history":
            _page_history()


func _refresh_phone() -> void:
    if phone_open and phone_page != "home" and phone_page != "map" and phone_page != "profile":
        open_app(phone_page)


func _title(t: String) -> void:
    phone_body.add_child(_lbl(t, 26, Color("ffd600"), true))


func _page_home() -> void:
    _title("יישומים")
    var g := GridContainer.new()
    g.columns = 2
    g.add_theme_constant_override("h_separation", 10)
    g.add_theme_constant_override("v_separation", 10)
    for a in [["delivery", "משלוחים"], ["map", "מפה וניווט"], ["bank", "הבנק שלי"], ["msgs", "שיחות והודעות"], ["profile", "פרופיל אישי"], ["vehicle", "כלי תחבורה"], ["history", "היסטוריית משלוחים"]]:
        var b := _btn(a[1], func(): open_app(a[0]), 180)
        b.custom_minimum_size.y = 80
        g.add_child(b)
    phone_body.add_child(g)


func _page_delivery() -> void:
    _title("אפליקציית משלוחים")
    var m: Dictionary = Game.mission
    if m.is_empty():
        phone_body.add_child(_wrap("אין הזמנה פעילה. הזמנות חדשות מגיעות בזמן שאתה מסתובב בעיר."))
        return
    var w: World = Game.world
    var r: Dictionary = w.poi(m.ri, m.rj)
    var h: Dictionary = w.poi(m.hi, m.hj)
    var lines := [
        "מסעדה: %s" % r.name, "כתובת איסוף: %s" % r.addr, "יעד מסירה: %s" % h.addr,
        "מרחק משוער: %d מ׳" % roundi(float(m.dist) + float(m.to_rest)),
        "זמן להשלמה: %d:%02d" % [int(m.limit) / 60, int(m.limit) % 60],
        "תשלום צפוי: %d ₪" % m.pay, "בונוס: %d ₪ (בעמידה בזמן)" % m.bonus, "הוראות: %s" % m.note,
    ]
    for t in lines:
        phone_body.add_child(_wrap(t))
    match str(m.state):
        "offered":
            phone_body.add_child(_btn("קבלת משלוח", func(): Game.accept()))
            phone_body.add_child(_btn("דחיית משלוח", func(): Game.decline()))
        "to_pickup":
            phone_body.add_child(_btn("נווט למסעדה", func(): Game.start_nav(r); main.set_phone(false)))
            phone_body.add_child(_btn("ביטול משלוח", func(): Game.cancel_mission()))
        "to_customer":
            phone_body.add_child(_btn("נווט ללקוח", func(): Game.start_nav(h); main.set_phone(false)))
            phone_body.add_child(_btn("ביטול משלוח", func(): Game.cancel_mission()))


func _page_map() -> void:
    _title("מפה וניווט")
    var mv := MapView.new()
    mv.selectable = true
    mv.world = Game.world
    mv.player = Game.player
    mv.custom_minimum_size = Vector2(360, 360)
    phone_body.add_child(mv)
    var info := _wrap("לחץ על המפה לבחירת יעד, או בחר מהרשימה")
    phone_body.add_child(info)
    var dests: Array = Game.world.destinations(Game.player.global_position)
    var ob := OptionButton.new()
    for d in dests:
        ob.add_item(("%s" % d.name) + (" (בנק)" if d.kind == "bank" else (" (מסעדה)" if d.kind == "restaurant" else "")))
    phone_body.add_child(ob)
    var sel := {"p": dests[0] if dests.size() > 0 else {}}
    ob.item_selected.connect(func(i): sel.p = dests[i]; mv.selected = dests[i])
    mv.picked.connect(func(p): sel.p = p; info.text = "יעד: " + str(p.name))
    phone_body.add_child(_btn("נווט", func():
        if not sel.p.is_empty():
            Game.start_nav(sel.p)
            main.set_phone(false)))
    phone_body.add_child(_btn("בטל ניווט", func(): Game.stop_nav()))


func _page_bank() -> void:
    _title("הבנק שלי")
    phone_body.add_child(_lbl("%d ₪" % Game.balance, 44, Color("ffd600"), true))
    phone_body.add_child(_lbl("סך הכנסות: %d ₪" % Game.total_income, 18))
    phone_body.add_child(_lbl("סך הוצאות: %d ₪" % Game.total_spent, 18))
    phone_body.add_child(_lbl("פעולות אחרונות", 20, Color(1, 1, 1, 0.7)))
    var n := Game.ledger.size()
    for k in range(n - 1, maxi(-1, n - 16), -1):
        var e: Dictionary = Game.ledger[k]
        var a := int(e.a)
        phone_body.add_child(_wrap("%s%d ₪ — %s" % ["+" if a > 0 else "", a, e.r], 330, 17))


func _page_msgs() -> void:
    _title("שיחות והודעות")
    if Game.messages.is_empty():
        phone_body.add_child(_wrap("אין הודעות עדיין."))
    for k in range(Game.messages.size() - 1, maxi(-1, Game.messages.size() - 25), -1):
        var e: Dictionary = Game.messages[k]
        var p := PanelContainer.new()
        var v := VBoxContainer.new()
        v.add_child(_lbl(str(e["from"]), 16, Color("ffd600")))
        v.add_child(_wrap(str(e.text), 320, 17))
        p.add_child(v)
        phone_body.add_child(p)


func _page_profile() -> void:
    _title("פרופיל אישי")
    var le := LineEdit.new()
    le.text = Game.player_name
    le.max_length = 16
    le.text_submitted.connect(func(t): Game.player_name = Game.sanitize_name(t); le.text = Game.player_name; Game.save_game())
    phone_body.add_child(le)
    _opt_row(phone_body, "חברה", ["משלוחה", "וולט", "שליח עצמאי"], ["mishloha", "wolt", "indie"].find(Game.company), func(i): Game.company = ["mishloha", "wolt", "indie"][i]; Game.appearance_changed.emit(); Game.save_game())
    phone_body.add_child(_lbl("דרגה: %s" % Game.rank_name(), 20, Color("ffd600")))
    var s: Dictionary = Game.stats
    var done := int(s.done)
    var avg := (float(s.time_sum) / done) if done > 0 else 0.0
    var fav := "—"
    var best := 0
    for k in s.by_veh:
        if int(s.by_veh[k]) > best:
            best = int(s.by_veh[k])
            fav = Game.VEHICLES[k].name
    for t in ["משלוחים שהושלמו: %d" % done, "משלוחים שנדחו: %d" % int(s.declined), "משלוחים בזמן: %d" % int(s.on_time), "סך הכסף שהרווחת: %d ₪" % Game.total_income, "ממוצע זמן למשלוח: %d שניות" % roundi(avg), "מרחק כולל: %.1f ק״מ" % (float(s.dist) / 1000.0), "כלי תחבורה מועדף: %s" % fav]:
        phone_body.add_child(_wrap(t))


func _page_vehicle() -> void:
    _title("כלי תחבורה")
    var v: Dictionary = Game.VEHICLES[Game.vehicle]
    phone_body.add_child(_lbl(v.name, 24, Color("ffd600"), true))
    for r in [["תאוצה", v.accel], ["יכולת תמרון", v.handling], ["נוחות", v.comfort], ["אמינות", v.reliab]]:
        var h := HBoxContainer.new()
        var l := _lbl(r[0], 17)
        l.custom_minimum_size.x = 110
        h.add_child(l)
        var pb := ProgressBar.new()
        pb.max_value = 10
        pb.value = r[1]
        pb.custom_minimum_size = Vector2(200, 18)
        pb.show_percentage = false
        h.add_child(pb)
        phone_body.add_child(h)
    phone_body.add_child(_lbl("עלות תחזוקה: %s" % v.maint, 17))
    phone_body.add_child(_lbl("שדרוגים", 22, Color("ffd600")))
    for k in Game.UPGRADES:
        var u: Dictionary = Game.UPGRADES[k]
        var lvl: int = Game.upgrades[Game.vehicle][k]
        var txt := "%s — מקסימום" % u.name if lvl >= 3 else "שדרג %s (רמה %d/3) — %d ₪" % [u.name, lvl, u.costs[lvl]]
        var b := _btn(txt, func(): Game.buy_upgrade(k))
        b.disabled = lvl >= 3
        phone_body.add_child(b)
        phone_body.add_child(_wrap(u.desc, 330, 15))
    phone_body.add_child(_lbl("הכלים שלך", 22, Color("ffd600")))
    for k in Game.VEHICLES:
        var vv: Dictionary = Game.VEHICLES[k]
        if Game.owned.has(k):
            var b := _btn("%s%s" % [vv.name, " (בשימוש)" if k == Game.vehicle else ""], func(): Game.switch_vehicle(k); Game.save_game())
            b.disabled = k == Game.vehicle
            phone_body.add_child(b)
        else:
            phone_body.add_child(_btn("קנה %s — %d ₪" % [vv.name, vv.price], func(): Game.buy_vehicle(k)))


func _page_history() -> void:
    _title("היסטוריית משלוחים")
    if Game.history.is_empty():
        phone_body.add_child(_wrap("עדיין לא הושלמו משלוחים."))
    for k in range(Game.history.size() - 1, maxi(-1, Game.history.size() - 21), -1):
        var e: Dictionary = Game.history[k]
        phone_body.add_child(_wrap("%s ← %s\n%d ₪ · %d שניות · %s" % [e.rest, e.addr, e.pay, e.time, "בזמן" if e.on_time else "באיחור"], 330, 16))
