; Inno Setup 6 - מתקין Windows למשחק
[Setup]
SetupIconFile=..\icon.ico
AppName=Israel Delivery
AppVersion=0.1.0
DefaultDirName={autopf}\IsraelDelivery
DefaultGroupName=משלוחים בישראל
OutputDir=..\build
OutputBaseFilename=IsraelDelivery_Setup
Compression=lzma
SolidCompression=yes
ArchitecturesInstallIn64BitMode=x64compatible

[Files]
Source: "..\build\IsraelDelivery.exe"; DestDir: "{app}"; Flags: ignoreversion

[Icons]
Name: "{group}\משלוחים בישראל"; Filename: "{app}\IsraelDelivery.exe"
Name: "{autodesktop}\משלוחים בישראל"; Filename: "{app}\IsraelDelivery.exe"

[Run]
Filename: "{app}\IsraelDelivery.exe"; Description: "הפעל את המשחק"; Flags: nowait postinstall skipifsilent
