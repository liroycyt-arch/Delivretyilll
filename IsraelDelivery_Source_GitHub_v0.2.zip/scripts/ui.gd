class_name UI
extends CanvasLayer
## כל הממשק נבנה בקוד: תפריטים, הגדרת דמות, HUD, טלפון ואפליקציותיו. עברית מלאה, פריסת RTL.

var main = null
var root: Control
var screen: Control = null
var hud: Control
var phone: PanelContainer
var phone_body: VBoxContainer
var phone_page := "home"
var phone_open := false
var toasts: VBoxContainer
var prompt: Label
var l_money: Label
var l_speed: Label
var l_mission: Label
var l_nav: Label
var l_rank: Label
var l_dbg: Label
var minimap: MapView
var loading_bar: ProgressBar
var preview_fig: Figure = null
var _look := {}
var modal: Control = null
var modal_open := false
var l_clock: Label
var l_cash: Label
var l_boost: Label
var boost_bar: ProgressBar
var phone_clock: Label
var _last_tx_ms := 0
var _sel_poi := {}
var _setup_name := ""
var _setup_company := "mishloha"
var _setup_vehicle := "ebike"


func _ready() -> void:
    process_mode = Node.PROCESS_MODE_ALWAYS
    root = Control.new()
    root.set_anchors_preset(Control.PRESET_FULL_RECT)
    root.layout_direction = Control.LAYOUT_DIRECTION_RTL
    root.theme = _make_theme()
    root.mouse_filter = Control.MOUSE_FILTER_IGNORE
    add_child(root)
    _build_hud()
    _build_phone()
    Game.notify.connect(toast)
    Game.money_changed.connect(_refresh_phone)
    Game.mission_changed.connect(_refresh_phone)


func _process(delta: float) -> void:
    if preview_fig != null and is_instance_valid(preview_fig):
        preview_fig.rotation.y += delta * 0.6


# ---------- עיצוב ----------
func _sb(c: Color, r := 14, border := Color(1, 1, 1, 0.0), bw := 0) -> StyleBoxFlat:
    var s := StyleBoxFlat.new()
    s.bg_color = c
    s.set_corner_radius_all(r)
    s.border_color = border
    s.set_border_width_all(bw)
    s.content_margin_left = 14
    s.content_margin_right = 14
    s.content_margin_top = 8
    s.content_margin_bottom = 8
    return s


func _make_theme() -> Theme:
    var th := Theme.new()
    th.default_font = Game.font
    th.default_font_size = 20
    th.set_stylebox("normal", "Button", _sb(Color(1, 1, 1, 0.12), 14, Color(1, 1, 1, 0.25), 1))
    th.set_stylebox("hover", "Button", _sb(Color(1, 1, 1, 0.22), 14, Color(1, 1, 1, 0.4), 1))
    th.set_stylebox("pressed", "Button", _sb(Color(1, 0.84, 0, 0.35), 14, Color(1, 0.84, 0, 0.8), 1))
    th.set_stylebox("disabled", "Button", _sb(Color(1, 1, 1, 0.05), 14))
    th.set_stylebox("focus", "Button", StyleBoxEmpty.new())
    th.set_color("font_color", "Button", Color.WHITE)
    th.set_color("font_disabled_color", "Button", Color(1, 1, 1, 0.35))
    th.set_color("font_color", "Label", Color.WHITE)
    th.set_color("font_color", "CheckBox", Color.WHITE)
    th.set_stylebox("panel", "PanelContainer", _sb(Color(0.06, 0.09, 0.14, 0.82), 22, Color(1, 1, 1, 0.18), 1))
    th.set_stylebox("normal", "LineEdit", _sb(Color(1, 1, 1, 0.1), 12, Color(1, 1, 1, 0.25), 1))
    th.set_color("font_color", "LineEdit", Color.WHITE)
    th.set_stylebox("normal", "OptionButton", _sb(Color(1, 1, 1, 0.12), 12, Color(1, 1, 1, 0.25), 1))
    th.set_color("font_color", "OptionButton", Color.WHITE)
    return th


func _lbl(text: String, size := 20, col := Color.WHITE, center := false) -> Label:
    var l := Label.new()
    l.text = text
    l.add_theme_font_size_override("font_size", size)
    l.add_theme_color_override("font_color", col)
    if center:
        l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    return l


func _wrap(text: String, w := 330.0, size := 18) -> Label:
    var l := _lbl(text, size)
    l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    l.custom_minimum_size.x = w
    return l


func _btn(text: String, cb: Callable, w := 0.0) -> Button:
    var b := Button.new()
    b.text = text
    b.custom_minimum_size = Vector2(w, 44)
    b.focus_mode = Control.FOCUS_NONE
    b.pressed.connect(cb)
    return b


func _set_screen(c: Control) -> void:
    if screen != null and is_instance_valid(screen):
        screen.queue_free()
    screen = c
    root.add_child(c)
    root.move_child(c, 0)


func _full(bgc := Color("0e1726")) -> Control:
    var c := Control.new()
    c.set_anchors_preset(Control.PRESET_FULL_RECT)
    var bg := ColorRect.new()
    bg.color = bgc
    bg.set_anchors_preset(Control.PRESET_FULL_RECT)
    c.add_child(bg)
    return c


func _centered(c: Control, inner: Control) -> void:
    var cc := CenterContainer.new()
    cc.set_anchors_preset(Control.PRESET_FULL_RECT)
    c.add_child(cc)
    cc.add_child(inner)


func clear_screen() -> void:
    if screen != null and is_instance_valid(screen):
        screen.queue_free()
    screen = null


# ---------- מסכים ----------
func show_main_menu() -> void:
    hud.visible = false
    close_phone()
    var c := _full()
    var art := TextureRect.new()
    art.texture = load("res://logo.png")
    art.set_anchors_preset(Control.PRESET_FULL_RECT)
    art.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
    art.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_COVERED
    c.add_child(art)
    var shade := ColorRect.new()
    shade.color = Color(0.03, 0.05, 0.1, 0.62)
    shade.set_anchors_preset(Control.PRESET_FULL_RECT)
    c.add_child(shade)
    var v := VBoxContainer.new()
    v.add_theme_constant_override("separation", 14)
    var logo := TextureRect.new()
    logo.texture = load("res://icon.png")
    logo.custom_minimum_size = Vector2(150, 150)
    logo.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
    logo.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
    v.add_child(logo)
    v.add_child(_lbl("משלוחים בישראל", 56, Color("ffd600"), true))
    v.add_child(_lbl("סימולטור שליחויות בתל אביב", 22, Color(1, 1, 1, 0.7), true))
    v.add_child(_btn("משחק חדש", main.new_game, 320))
    var cont := _btn("המשך משחק", main.continue_game, 320)
    cont.disabled = not Game.has_save
    v.add_child(cont)
    v.add_child(_btn("הגדרות", func(): show_settings(show_main_menu), 320))
    v.add_child(_btn("יציאה", func(): main.quit_game(), 320))
    _centered(c, v)
    _set_screen(c)


func _opt_row(parent: Control, title: String, items: Array, sel: int, cb: Callable) -> void:
    var h := HBoxContainer.new()
    var l := _lbl(title, 20)
    l.custom_minimum_size.x = 120
    h.add_child(l)
    var o := OptionButton.new()
    for it in items:
        o.add_item(it)
    o.select(clampi(sel, 0, items.size() - 1))
    o.item_selected.connect(cb)
    o.custom_minimum_size.x = 200
    h.add_child(o)
    parent.add_child(h)


func _vehicle_card(k: String) -> Control:
    var v: Dictionary = Game.VEHICLES[k]
    var p := PanelContainer.new()
    var b := VBoxContainer.new()
    b.add_child(_lbl(v.name, 22, Color("ffd600"), true))
    var rows := [["מהירות מרבית", "%d קמ״ש" % int(v.max)], ["תאוצה", "%d/10" % v.accel], ["יכולת תמרון", "%d/10" % v.handling], ["נוחות", "%d/10" % v.comfort], ["אמינות", "%d/10" % v.reliab], ["עלות תחזוקה", v.maint]]
    for r in rows:
        b.add_child(_lbl("%s: %s" % [r[0], r[1]], 17))
    p.add_child(b)
    p.set_meta("key", k)
    return p


func show_setup() -> void:
    hud.visible = false
    _look = Game.look.duplicate()
    _setup_name = ""
    _setup_company = "mishloha"
    _setup_vehicle = "ebike"
    var c := _full(Color("111c2e"))
    var h := HBoxContainer.new()
    h.add_theme_constant_override("separation", 30)
    h.set_anchors_preset(Control.PRESET_FULL_RECT)
    h.offset_left = 40
    h.offset_right = -40
    h.offset_top = 30
    h.offset_bottom = -30
    c.add_child(h)
    var side := VBoxContainer.new()
    var svc := SubViewportContainer.new()
    svc.custom_minimum_size = Vector2(340, 480)
    svc.stretch = true
    var vp := SubViewport.new()
    vp.own_world_3d = true
    vp.transparent_bg = true
    vp.size = Vector2i(340, 480)
    svc.add_child(vp)
    var cam := Camera3D.new()
    cam.fov = 38.0
    vp.add_child(cam)
    cam.look_at_from_position(Vector3(0, 1.05, 3.2), Vector3(0, 0.9, 0))
    var dl := DirectionalLight3D.new()
    dl.rotation_degrees = Vector3(-35, -25, 0)
    vp.add_child(dl)
    var we := WorldEnvironment.new()
    var en := Environment.new()
    en.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
    en.ambient_light_color = Color(0.7, 0.75, 0.85)
    we.environment = en
    vp.add_child(we)
    preview_fig = Figure.new()
    preview_fig.rotation.y = PI
    vp.add_child(preview_fig)
    side.add_child(svc)
    h.add_child(side)
    var sc := ScrollContainer.new()
    sc.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    sc.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
    var f := VBoxContainer.new()
    f.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    f.add_theme_constant_override("separation", 10)
    sc.add_child(f)
    h.add_child(sc)
    f.add_child(_lbl("יצירת שליח", 36, Color("ffd600")))
    var nrow := HBoxContainer.new()
    var nl := _lbl("שם", 20)
    nl.custom_minimum_size.x = 120
    nrow.add_child(nl)
    var le := LineEdit.new()
    le.max_length = 16
    le.placeholder_text = "שם השליח"
    le.custom_minimum_size.x = 260
    le.text_changed.connect(func(t): _setup_name = t)
    nrow.add_child(le)
    f.add_child(nrow)
    _opt_row(f, "גוון עור", ["בהיר מאוד", "בהיר", "בינוני", "כהה", "כהה מאוד"], int(_look.skin), func(i): _look.skin = i; _refresh_preview())
    _opt_row(f, "תסרוקת", ["קצרה", "קצוצה", "ארוכה", "ללא שיער"], int(_look.hair_style), func(i): _look.hair_style = i; _refresh_preview())
    _opt_row(f, "צבע שיער", ["שחור", "חום כהה", "ערמוני", "בלונד", "אפור"], int(_look.hair_color), func(i): _look.hair_color = i; _refresh_preview())
    _opt_row(f, "מבנה גוף", ["רזה", "רגיל", "רחב"], int(_look.body), func(i): _look.body = i; _refresh_preview())
    _opt_row(f, "מכנסיים", ["ארוכים", "קצרים"], 1 if _look.shorts else 0, func(i): _look.shorts = (i == 1); _refresh_preview())
    _opt_row(f, "צבע קסדה", ["לבן", "שחור", "אדום", "כחול", "צהוב"], int(_look.helmet), func(i): _look.helmet = i; _refresh_preview())
    f.add_child(_lbl("חברת משלוחים (הבגדים משתנים בהתאם)", 22, Color("ffd600")))
    _opt_row(f, "חברה", ["משלוחה (צהוב)", "וולט (כחול)", "שליח עצמאי (שחור)"], 0, func(i): _setup_company = ["mishloha", "wolt", "indie"][i]; _refresh_preview())
    f.add_child(_lbl("כלי תחבורה", 22, Color("ffd600")))
    var vr := HBoxContainer.new()
    vr.add_theme_constant_override("separation", 12)
    for k in ["ebike", "scooter", "moped"]:
        var card := _vehicle_card(k)
        vr.add_child(card)
    f.add_child(vr)
    _opt_row(f, "בחירה", ["אופניים חשמליים", "קורקינט חשמלי", "קטנוע ישן"], 0, func(i): _setup_vehicle = ["ebike", "scooter", "moped"][i])
    var go := _btn("התחל לעבוד", func(): _finish_setup(), 320)
    f.add_child(go)
    f.add_child(_btn("חזרה", show_main_menu, 320))
    _set_screen(c)
    _refresh_preview()


func _refresh_preview() -> void:
    if preview_fig != null and is_instance_valid(preview_fig):
        preview_fig.build(_look, _setup_company)
        preview_fig.helmet_node.visible = true


func _finish_setup() -> void:
    Game.player_name = Game.sanitize_name(_setup_name)
    Game.look = _look.duplicate()
    Game.company = _setup_company
    Game.vehicle = _setup_vehicle
    Game.owned = [_setup_vehicle]
    preview_fig = null
    main.begin_play(true)


func show_loading() -> void:
    hud.visible = false
    var c := _full(Color("0e1726"))
    var v := VBoxContainer.new()
    v.add_theme_constant_override("separation", 16)
    v.add_child(_lbl("טוען את תל אביב...", 40, Color("ffd600"), true))
    loading_bar = ProgressBar.new()
    loading_bar.custom_minimum_size = Vector2(480, 24)
    loading_bar.max_value = 1.0
    v.add_child(loading_bar)
    _centered(c, v)
    _set_screen(c)


func set_progress(p: float) -> void:
    if loading_bar != null and is_instance_valid(loading_bar):
        loading_bar.value = p


func show_pause() -> void:
    var c := Control.new()
    c.set_anchors_preset(Control.PRESET_FULL_RECT)
    var bg := ColorRect.new()
    bg.color = Color(0, 0, 0, 0.55)
    bg.set_anchors_preset(Control.PRESET_FULL_RECT)
    c.add_child(bg)
    var v := VBoxContainer.new()
    v.add_theme_constant_override("separation", 12)
    v.add_child(_lbl("השהיה", 44, Color("ffd600"), true))
    v.add_child(_btn("המשך", main.resume, 300))
    v.add_child(_btn("הגדרות", func(): show_settings(show_pause), 300))
    v.add_child(_btn("שמור וחזור לתפריט", main.save_and_menu, 300))
    v.add_child(_btn("שמור ויציאה", main.quit_game, 300))
    _centered(c, v)
    _set_screen(c)


func show_settings(back: Callable) -> void:
    var c := _full(Color("0e1726"))
    var sc := ScrollContainer.new()
    sc.set_anchors_preset(Control.PRESET_FULL_RECT)
    sc.offset_left = 200
    sc.offset_right = -200
    sc.offset_top = 20
    sc.offset_bottom = -20
    var v := VBoxContainer.new()
    v.add_theme_constant_override("separation", 8)
    v.custom_minimum_size.x = 640
    v.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    v.add_child(_lbl("הגדרות", 40, Color("ffd600"), true))
    _settings_body(v)
    v.add_child(_lbl("מקשים: W/A/S/D תנועה · רווח בלימה · Shift/B Boost · F ירידה/עלייה · E פעולה · M מפה · P טלפון · C מצלמה · לחצן ימני לחוץ: סיבוב מצלמה · גלגלת: זום · Esc השהיה", 15, Color(1, 1, 1, 0.65)))
    v.add_child(_btn("חזרה", func(): Game.save_game(); back.call(), 240))
    sc.add_child(v)
    c.add_child(sc)
    _set_screen(c)


func _settings_body(v: Control) -> void:
    var s: Dictionary = Game.settings
    _slider(v, "עוצמת קול", float(s.volume), 0.0, 1.0, 0.05, func(x): s.volume = x)
    _slider(v, "שדה ראייה", float(s.fov), 60.0, 100.0, 1.0, func(x): s.fov = x)
    _slider(v, "רגישות מצלמה", float(s.cam_sens), 0.3, 2.5, 0.1, func(x): s.cam_sens = x)
    _slider(v, "מרחק מצלמה", float(s.cam_zoom), 0.5, 2.0, 0.1, func(x): s.cam_zoom = x)
    _check(v, "היפוך ציר אנכי של המצלמה", bool(s.cam_invert_y), func(b): s.cam_invert_y = b)
    _slider(v, "משך התראות (שניות)", float(s.notify_sec), 2.0, 8.0, 0.5, func(x): s.notify_sec = x)
    _opt_row(v, "מצב תצוגה", ["חלון", "מסך מלא", "חלון ללא מסגרת"], int(s.display_mode), func(i): s.display_mode = i; main.apply_settings())
    _opt_row(v, "רזולוציה (חלון)", ["1280×720", "1600×900", "1920×1080", "2560×1440"], int(s.resolution), func(i): s.resolution = i; main.apply_settings())
    _opt_row(v, "איכות / מרחק ציור", ["נמוכה", "בינונית", "גבוהה"], int(s.quality), func(i): s.quality = i; main.apply_settings())
    _opt_row(v, "צפיפות תנועה", ["ללא", "נמוכה", "בינונית", "גבוהה"], int(s.traffic), func(i): s.traffic = i)
    _opt_row(v, "הגבלת FPS", ["30", "60", "120", "ללא הגבלה"], [30, 60, 120, 0].find(int(s.fps)), func(i): s.fps = [30, 60, 120, 0][i]; main.apply_settings())
    _check(v, "צללים", bool(s.shadows), func(b): s.shadows = b; main.apply_settings())
    _check(v, "השתק צלילי התראות", bool(s.mute_notify), func(b): s.mute_notify = b)
    _check(v, "קול ניווט בעברית (תלוי בקול Windows מותקן)", bool(s.voice), func(b): s.voice = b)


func _slider(parent: Control, title: String, val: float, mn: float, mx: float, step: float, cb: Callable) -> void:
    var h := HBoxContainer.new()
    var l := _lbl(title, 20)
    l.custom_minimum_size.x = 250
    h.add_child(l)
    var sl := HSlider.new()
    sl.min_value = mn
    sl.max_value = mx
    sl.step = step
    sl.value = val
    sl.custom_minimum_size = Vector2(260, 24)
    sl.value_changed.connect(func(x): cb.call(x); main.apply_settings())
    h.add_child(sl)
    parent.add_child(h)


func _check(parent: Control, title: String, val: bool, cb: Callable) -> void:
    var cbx := CheckBox.new()
    cbx.text = title
    cbx.button_pressed = val
    cbx.toggled.connect(cb)
    parent.add_child(cbx)


func show_summary(d: Dictionary) -> void:
    if d.is_empty():
        return
    var p := PanelContainer.new()
    var v := VBoxContainer.new()
    v.add_child(_lbl("המשלוח הושלם", 34, Color("2ecc71"), true))
    v.add_child(_lbl("מסעדה: %s" % d.rest, 20))
    v.add_child(_lbl("כתובת: %s" % d.addr, 20))
    v.add_child(_lbl("זמן: %d שניות — %s" % [d.time, "בזמן" if d.on_time else "באיחור"], 20))
    v.add_child(_lbl("תשלום: %d ₪" % d.pay, 24, Color("ffd600")))
    v.add_child(_lbl("עלות תחזוקה: %d ₪" % d.cost, 18, Color(1, 1, 1, 0.7)))
    v.add_child(_btn("אישור", func(): p.queue_free(), 200))
    p.add_child(v)
    root.add_child(p)
    p.set_anchors_and_offsets_preset(Control.PRESET_CENTER, Control.PRESET_MODE_MINSIZE)
    p.grow_horizontal = Control.GROW_DIRECTION_BOTH
    p.grow_vertical = Control.GROW_DIRECTION_BOTH
    var tw := p.create_tween()
    tw.tween_interval(8.0)
    tw.tween_callback(p.queue_free)


# ---------- HUD ----------
func _build_hud() -> void:
    hud = Control.new()
    hud.set_anchors_preset(Control.PRESET_FULL_RECT)
    hud.mouse_filter = Control.MOUSE_FILTER_IGNORE
    hud.visible = false
    root.add_child(hud)
    var tr := PanelContainer.new()
    var v := VBoxContainer.new()
    l_clock = _lbl("08:00", 34, Color.WHITE)
    l_money = _lbl("", 26, Color("ffd600"))
    l_cash = _lbl("", 20, Color("a8e6a1"))
    l_rank = _lbl("", 16, Color(1, 1, 1, 0.75))
    v.add_child(l_clock)
    v.add_child(l_money)
    v.add_child(l_cash)
    v.add_child(l_rank)
    tr.add_child(v)
    hud.add_child(tr)
    tr.set_anchors_and_offsets_preset(Control.PRESET_TOP_RIGHT, Control.PRESET_MODE_MINSIZE, 16)
    tr.grow_horizontal = Control.GROW_DIRECTION_BEGIN
    var left := VBoxContainer.new()
    minimap = MapView.new()
    minimap.range_m = 230.0
    minimap.custom_minimum_size = Vector2(230, 230)
    left.add_child(minimap)
    var mp := PanelContainer.new()
    var mv := VBoxContainer.new()
    l_mission = _wrap("", 230, 17)
    l_nav = _wrap("", 230, 17)
    l_nav.add_theme_color_override("font_color", Color("4dd0ff"))
    mv.add_child(l_mission)
    mv.add_child(l_nav)
    mp.add_child(mv)
    left.add_child(mp)
    hud.add_child(left)
    left.set_anchors_and_offsets_preset(Control.PRESET_TOP_LEFT, Control.PRESET_MODE_MINSIZE, 16)
    var br := PanelContainer.new()
    var bv := VBoxContainer.new()
    l_speed = _lbl("", 30)
    l_boost = _lbl("", 17, Color("a8e6a1"))
    boost_bar = ProgressBar.new()
    boost_bar.custom_minimum_size = Vector2(190, 12)
    boost_bar.max_value = 1.0
    boost_bar.show_percentage = false
    bv.add_child(l_speed)
    bv.add_child(l_boost)
    bv.add_child(boost_bar)
    br.add_child(bv)
    hud.add_child(br)
    br.set_anchors_and_offsets_preset(Control.PRESET_BOTTOM_RIGHT, Control.PRESET_MODE_MINSIZE, 16)
    br.grow_horizontal = Control.GROW_DIRECTION_BEGIN
    br.grow_vertical = Control.GROW_DIRECTION_BEGIN
    l_dbg = _lbl("", 14, Color(1, 1, 1, 0.5))
    hud.add_child(l_dbg)
    l_dbg.set_anchors_and_offsets_preset(Control.PRESET_BOTTOM_LEFT, Control.PRESET_MODE_MINSIZE, 12)
    l_dbg.grow_vertical = Control.GROW_DIRECTION_BEGIN
    toasts = VBoxContainer.new()
    toasts.mouse_filter = Control.MOUSE_FILTER_IGNORE
    hud.add_child(toasts)
    toasts.set_anchors_and_offsets_preset(Control.PRESET_CENTER_TOP, Control.PRESET_MODE_MINSIZE, 16)
    toasts.grow_horizontal = Control.GROW_DIRECTION_BOTH
    prompt = _lbl("", 26, Color.WHITE, true)
    prompt.add_theme_color_override("font_outline_color", Color.BLACK)
    prompt.add_theme_constant_override("outline_size", 6)
    hud.add_child(prompt)
    prompt.set_anchors_and_offsets_preset(Control.PRESET_CENTER_BOTTOM, Control.PRESET_MODE_MINSIZE, 90)
    prompt.grow_horizontal = Control.GROW_DIRECTION_BOTH
    prompt.grow_vertical = Control.GROW_DIRECTION_BEGIN
    prompt.custom_minimum_size.x = 700


func show_hud(p: Player, w: World) -> void:
    hud.visible = true
    minimap.world = w
    minimap.player = p


func set_prompt(t: String) -> void:
    prompt.text = t


func update_hud(p: Player, w: World) -> void:
    l_clock.text = Game.time_string()
    l_money.text = "בנק: %d ₪" % Game.balance
    l_cash.text = "מזומן: %d ₪" % Game.cash
    l_rank.text = "%s · %s" % [Game.player_name, Game.rank_name()]
    l_speed.text = "%d קמ״ש" % roundi(absf(p.speed) * 3.6)
    match Game.boost_state():
        "active":
            l_boost.text = "Boost פעיל — %.1f ש׳" % Game.boost_t
            l_boost.add_theme_color_override("font_color", Color("ff9d2e"))
            boost_bar.value = Game.boost_t / Game.BOOST_DURATION
        "cooldown":
            l_boost.text = "Boost בטעינה — %d ש׳" % ceili(Game.boost_cd)
            l_boost.add_theme_color_override("font_color", Color(1, 1, 1, 0.55))
            boost_bar.value = 1.0 - Game.boost_cd / Game.BOOST_COOLDOWN
        _:
            l_boost.text = "Boost מוכן (Shift / B)"
            l_boost.add_theme_color_override("font_color", Color("a8e6a1"))
            boost_bar.value = 1.0
    if phone_clock != null and phone_open:
        phone_clock.text = Game.time_string()
    var m: Dictionary = Game.mission
    var t := ""
    if not m.is_empty():
        var rest: Dictionary = w.poi(m.ri, m.rj)
        var home: Dictionary = w.poi(m.hi, m.hj)
        var left := int(m.limit) - int(m.elapsed)
        var tm := "%d:%02d" % [absi(left) / 60, absi(left) % 60] if left >= 0 else "באיחור"
        match str(m.state):
            "offered":
                t = "הזמנה חדשה ממתינה בטלפון (P)"
            "to_pickup":
                t = "איסוף: %s\nתשלום: %d ₪ · זמן: %s" % [rest.name, m.pay, tm]
            "to_customer":
                t = "מסירה: %s\n%s · זמן: %s" % [home.addr, m.note, tm]
    l_mission.text = t
    if Game.nav_active:
        var eta := Game.nav_remaining / maxf(6.0, absf(p.speed))
        l_nav.text = "%s\nנותרו %d מ׳ · הגעה בעוד %d:%02d%s" % [Game.nav_text, roundi(Game.nav_remaining), int(eta) / 60, int(eta) % 60, " (ניווט חופשי)" if Game.nav_free else ""]
    else:
        l_nav.text = ""
    l_dbg.text = "FPS %d · אזורים טעונים %d" % [Engine.get_frames_per_second(), w.chunks.size()]


func toast(text: String) -> void:
    var p := PanelContainer.new()
    p.add_child(_lbl(text, 20))
    toasts.add_child(p)
    while toasts.get_child_count() > 3:
        var c := toasts.get_child(0)
        toasts.remove_child(c)
        c.queue_free()
    var tw := p.create_tween()
    tw.tween_interval(float(Game.settings.get("notify_sec", 4.0)))
    tw.tween_property(p, "modulate:a", 0.0, 0.4)
    tw.tween_callback(p.queue_free)


# ---------- טלפון ----------
func _build_phone() -> void:
    phone = PanelContainer.new()
    phone.visible = false
    # גוף מעוגל, מסגרת דקה, מסך כהה
    var body := _sb(Color(0.03, 0.04, 0.07, 0.98), 52, Color(0.32, 0.34, 0.38), 5)
    body.content_margin_left = 12
    body.content_margin_right = 12
    body.content_margin_top = 10
    body.content_margin_bottom = 14
    phone.add_theme_stylebox_override("panel", body)
    var v := VBoxContainer.new()
    v.add_theme_constant_override("separation", 6)
    var top := HBoxContainer.new()
    phone_clock = _lbl("08:00", 20, Color.WHITE)
    top.add_child(phone_clock)
    var sp := Control.new()
    sp.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    top.add_child(sp)
    top.add_child(_lbl("5G ▮▮▮▮ 100%", 14, Color(1, 1, 1, 0.7)))
    v.add_child(top)
    var sc := ScrollContainer.new()
    sc.custom_minimum_size = Vector2(390, 620)
    sc.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
    phone_body = VBoxContainer.new()
    phone_body.add_theme_constant_override("separation", 8)
    phone_body.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    sc.add_child(phone_body)
    v.add_child(sc)
    var nav := HBoxContainer.new()
    nav.add_theme_constant_override("separation", 10)
    nav.add_child(_btn("בית", func(): open_app("home"), 110))
    nav.add_child(_btn("סגור (P)", func(): main.set_phone(false), 150))
    v.add_child(nav)
    phone.add_child(v)
    root.add_child(phone)
    phone.set_anchors_and_offsets_preset(Control.PRESET_CENTER_RIGHT, Control.PRESET_MODE_MINSIZE, 24)
    phone.grow_horizontal = Control.GROW_DIRECTION_BEGIN
    phone.grow_vertical = Control.GROW_DIRECTION_BOTH


func open_phone(page := "home") -> void:
    phone_open = true
    phone.visible = true
    phone.modulate.a = 0.0
    phone.pivot_offset = phone.size * 0.5
    phone.scale = Vector2(0.92, 0.92)
    var tw := phone.create_tween().set_parallel(true)
    tw.tween_property(phone, "modulate:a", 1.0, 0.16)
    tw.tween_property(phone, "scale", Vector2.ONE, 0.16).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
    open_app(page)


func close_phone() -> void:
    phone_open = false
    if phone != null:
        phone.visible = false


func open_app(page: String) -> void:
    phone_page = page
    for c in phone_body.get_children():
        phone_body.remove_child(c)
        c.queue_free()
    match page:
        "home":
            _page_home()
        "delivery":
            _page_delivery()
        "map":
            _page_map()
        "bank":
            _page_bank()
        "clock":
            _page_clock()
        "settings":
            _page_settings()
        "msgs":
            _page_msgs()
        "profile":
            _page_profile()
        "vehicle":
            _page_vehicle()
        "history":
            _page_history()


func _refresh_phone() -> void:
    if phone_open and phone_page in ["delivery", "bank", "msgs", "vehicle", "history"]:
        open_app(phone_page)


## מניעת לחיצות כפולות מהירות שיכולות ליצור/לאבד כסף
func _tx_guard() -> bool:
    var now := Time.get_ticks_msec()
    if now - _last_tx_ms < 300:
        return false
    _last_tx_ms = now
    return true


func _day_part() -> String:
    var h := Game.hour_float()
    if h < 5.0 or h >= 21.0:
        return "לילה"
    if h < 7.0:
        return "זריחה"
    if h < 12.0:
        return "בוקר"
    if h < 15.0:
        return "צהריים"
    if h < 18.0:
        return "אחר הצהריים"
    if h < 19.5:
        return "שקיעה"
    return "ערב"


func _page_clock() -> void:
    _title("שעון")
    phone_body.add_child(_lbl(Game.time_string(), 72, Color.WHITE, true))
    phone_body.add_child(_lbl(_day_part(), 26, Color("ffd600"), true))
    phone_body.add_child(_wrap("שעון המשחק: כל שנייה אמיתית = דקה במשחק. יום שלם נמשך 24 דקות אמיתיות. השעה מסונכרנת עם השעון בפינת המסך ונשמרת בשמירה.", 340, 16))
    phone_body.add_child(_lbl("שעון המשחק מתעדכן בזמן אמת בזמן שהטלפון פתוח", 14, Color(1, 1, 1, 0.5)))


func _page_settings() -> void:
    _title("הגדרות")
    _settings_body(phone_body)
    phone_body.add_child(_btn("שמור", func(): Game.save_game()))


func _title(t: String) -> void:
    phone_body.add_child(_lbl(t, 26, Color("ffd600"), true))


func _page_home() -> void:
    _title("יישומים")
    var g := GridContainer.new()
    g.columns = 3
    g.add_theme_constant_override("h_separation", 10)
    g.add_theme_constant_override("v_separation", 10)
    var apps := [
        ["delivery", "משלוחים", Color("e67e22")], ["map", "מפה וניווט", Color("2e86de")], ["bank", "בנק", Color("1f9d6b")],
        ["clock", "שעון", Color("8e44ad")], ["settings", "הגדרות", Color("5d6d7e")], ["msgs", "הודעות", Color("27ae60")],
        ["profile", "פרופיל", Color("c0392b")], ["vehicle", "כלי תחבורה", Color("d4a017")], ["history", "היסטוריה", Color("16a085")],
    ]
    for a in apps:
        var b := _btn(a[1], func(): open_app(a[0]), 118)
        b.custom_minimum_size.y = 96
        var col: Color = a[2]
        b.add_theme_stylebox_override("normal", _sb(col.darkened(0.15), 24, col.lightened(0.2), 1))
        b.add_theme_stylebox_override("hover", _sb(col, 24, Color.WHITE, 1))
        b.add_theme_stylebox_override("pressed", _sb(col.lightened(0.2), 24, Color.WHITE, 2))
        g.add_child(b)
    phone_body.add_child(g)
    phone_body.add_child(_lbl(Game.time_string(), 56, Color.WHITE, true))
    phone_body.add_child(_lbl(_day_part(), 20, Color(1, 1, 1, 0.7), true))


func _page_delivery() -> void:
    _title("אפליקציית משלוחים")
    var m: Dictionary = Game.mission
    if m.is_empty():
        phone_body.add_child(_wrap("אין הזמנה פעילה. הזמנות חדשות מגיעות בזמן שאתה מסתובב בעיר."))
        return
    var w: World = Game.world
    var r: Dictionary = w.poi(m.ri, m.rj)
    var h: Dictionary = w.poi(m.hi, m.hj)
    var lines := [
        "מסעדה: %s" % r.name, "כתובת איסוף: %s" % r.addr, "יעד מסירה: %s" % h.addr,
        "מרחק משוער: %d מ׳" % roundi(float(m.dist) + float(m.to_rest)),
        "זמן להשלמה: %d:%02d" % [int(m.limit) / 60, int(m.limit) % 60],
        "תשלום צפוי: %d ₪" % m.pay, "בונוס: %d ₪ (בעמידה בזמן)" % m.bonus, "הוראות: %s" % m.note,
    ]
    for t in lines:
        phone_body.add_child(_wrap(t))
    match str(m.state):
        "offered":
            phone_body.add_child(_btn("קבלת משלוח", func(): Game.accept()))
            phone_body.add_child(_btn("דחיית משלוח", func(): Game.decline()))
        "to_pickup":
            if Game.nav_active and Game.nav_free:
                phone_body.add_child(_wrap("ניווט חופשי פעיל. הניווט להזמנה יחליף אותו רק אם תבחר בכך.", 330, 15))
            phone_body.add_child(_btn("נווט למסעדה (יעד ההזמנה)", func(): Game.start_nav(r); main.set_phone(false)))
            phone_body.add_child(_btn("ביטול משלוח", func(): Game.cancel_mission()))
        "to_customer":
            if Game.nav_active and Game.nav_free:
                phone_body.add_child(_wrap("ניווט חופשי פעיל. הניווט להזמנה יחליף אותו רק אם תבחר בכך.", 330, 15))
            phone_body.add_child(_btn("נווט ללקוח (יעד ההזמנה)", func(): Game.start_nav(h); main.set_phone(false)))
            phone_body.add_child(_btn("ביטול משלוח", func(): Game.cancel_mission()))


func _page_map() -> void:
    _title("מפה וניווט")
    var mv := MapView.new()
    mv.selectable = true
    mv.world = Game.world
    mv.player = Game.player
    mv.custom_minimum_size = Vector2(370, 340)
    phone_body.add_child(mv)
    var info := _wrap("לחץ על בניין במפה לבחירת יעד, או בחר מהרשימה. הניווט מוביל לכניסה / נקודת גישה, לא למרכז הבניין.", 340, 15)
    phone_body.add_child(info)
    var dests: Array = Game.world.destinations(Game.player.global_position)
    var ob := OptionButton.new()
    for d in dests:
        var kl: String = Game.world.kind_label(str(d.kind))
        ob.add_item(str(d.name) + ((" (" + kl + ")") if (kl != "" and d.kind != "landmark") else ""))
    phone_body.add_child(ob)
    _sel_poi = dests[0] if dests.size() > 0 else {}
    ob.item_selected.connect(func(i): _sel_poi = dests[i]; mv.selected = dests[i]; info.text = "יעד: " + str(dests[i].name))
    mv.picked.connect(func(p): _sel_poi = p; info.text = "יעד: %s (%s)" % [p.name, Game.world.kind_label(str(p.kind))])
    phone_body.add_child(_btn("התחל ניווט ליעד שבחרתי", func():
        if _sel_poi.is_empty():
            return
        if not Game.world.is_reachable(Game.player.global_position, _sel_poi):
            toast("אין מסלול נגיש ליעד הזה")
            return
        Game.start_free_nav(_sel_poi)
        main.set_phone(false)))
    var m: Dictionary = Game.mission
    var st: String = m.get("state", "")
    if st == "to_pickup" or st == "to_customer":
        var tgt: Dictionary = Game.world.poi(m.ri, m.rj) if st == "to_pickup" else Game.world.poi(m.hi, m.hj)
        phone_body.add_child(_btn("נווט ליעד ההזמנה", func(): Game.start_nav(tgt); main.set_phone(false)))
    if Game.nav_active:
        phone_body.add_child(_wrap("ניווט פעיל אל: %s\nנותרו %d מ׳" % [Game.nav_poi.get("name", ""), roundi(Game.nav_remaining)], 340, 15))
    phone_body.add_child(_btn("בטל ניווט / בחר יעד אחר", func(): Game.stop_nav()))


func _page_bank() -> void:
    _title("הבנק שלי")
    phone_body.add_child(_lbl("יתרת בנק", 16, Color(1, 1, 1, 0.6), true))
    phone_body.add_child(_lbl("%d ₪" % Game.balance, 42, Color("ffd600"), true))
    phone_body.add_child(_lbl("מזומן בכיס: %d ₪" % Game.cash, 22, Color("a8e6a1"), true))
    var near: bool = main.near_atm()
    if not near:
        phone_body.add_child(_wrap("הפקדה ומשיכה אפשריות רק ליד בנק או כספומט (בנקים, קניונים, תחנות דלק וסופרים).", 340, 15))
    else:
        var sb := SpinBox.new()
        sb.min_value = 1
        sb.max_value = 100000
        sb.step = 1
        sb.value = 100
        sb.custom_minimum_size = Vector2(300, 40)
        phone_body.add_child(sb)
        var q := HBoxContainer.new()
        for amt in [50, 100, 500]:
            q.add_child(_btn(str(amt), func(): _set_val(sb, amt), 70))
        q.add_child(_btn("הכל", func(): _set_val(sb, maxi(1, maxi(Game.cash, Game.balance))), 70))
        phone_body.add_child(q)
        phone_body.add_child(_btn("הפקדת מזומן", func():
            if _tx_guard():
                Game.deposit(int(sb.value))))
        phone_body.add_child(_btn("משיכת מזומן", func():
            if _tx_guard():
                Game.withdraw(int(sb.value))))
    phone_body.add_child(_lbl("סך הכנסות: %d ₪ · סך הוצאות: %d ₪" % [Game.total_income, Game.total_spent], 15, Color(1, 1, 1, 0.65)))
    phone_body.add_child(_lbl("פעולות אחרונות", 20, Color(1, 1, 1, 0.7)))
    var n := Game.ledger.size()
    for k in range(n - 1, maxi(-1, n - 16), -1):
        var e: Dictionary = Game.ledger[k]
        var a := int(e.a)
        phone_body.add_child(_wrap("%s%d ₪ — %s" % ["+" if a > 0 else "", a, e.r], 330, 16))


func _page_msgs() -> void:
    _title("שיחות והודעות")
    if Game.messages.is_empty():
        phone_body.add_child(_wrap("אין הודעות עדיין."))
    for k in range(Game.messages.size() - 1, maxi(-1, Game.messages.size() - 25), -1):
        var e: Dictionary = Game.messages[k]
        var p := PanelContainer.new()
        var v := VBoxContainer.new()
        v.add_child(_lbl(str(e["from"]), 16, Color("ffd600")))
        v.add_child(_wrap(str(e.text), 320, 17))
        p.add_child(v)
        phone_body.add_child(p)


func _page_profile() -> void:
    _title("פרופיל אישי")
    var le := LineEdit.new()
    le.text = Game.player_name
    le.max_length = 16
    le.text_submitted.connect(func(t): Game.player_name = Game.sanitize_name(t); le.text = Game.player_name; Game.save_game())
    phone_body.add_child(le)
    _opt_row(phone_body, "חברה", ["משלוחה", "וולט", "שליח עצמאי"], ["mishloha", "wolt", "indie"].find(Game.company), func(i): Game.company = ["mishloha", "wolt", "indie"][i]; Game.appearance_changed.emit(); Game.save_game())
    phone_body.add_child(_lbl("דרגה: %s" % Game.rank_name(), 20, Color("ffd600")))
    var s: Dictionary = Game.stats
    var done := int(s.done)
    var avg := (float(s.time_sum) / done) if done > 0 else 0.0
    var fav := "—"
    var best := 0
    for k in s.by_veh:
        if int(s.by_veh[k]) > best:
            best = int(s.by_veh[k])
            fav = Game.VEHICLES[k].name
    var inv_txt := ""
    for k in Game.inventory:
        if int(Game.inventory[k]) > 0:
            inv_txt += "%s ×%d  " % [Game.SHOP_ITEMS[k].name, int(Game.inventory[k])]
    phone_body.add_child(_wrap("מלאי: %s" % (inv_txt if inv_txt != "" else "ריק"), 330, 16))
    for t in ["משלוחים שהושלמו: %d" % done, "משלוחים שנדחו: %d" % int(s.declined), "משלוחים בזמן: %d" % int(s.on_time), "סך הכסף שהרווחת: %d ₪" % Game.total_income, "ממוצע זמן למשלוח: %d שניות" % roundi(avg), "מרחק כולל: %.1f ק״מ" % (float(s.dist) / 1000.0), "כלי תחבורה מועדף: %s" % fav]:
        phone_body.add_child(_wrap(t))


func _page_vehicle() -> void:
    _title("כלי תחבורה")
    var v: Dictionary = Game.VEHICLES[Game.vehicle]
    phone_body.add_child(_lbl(v.name, 24, Color("ffd600"), true))
    for r in [["תאוצה", v.accel], ["יכולת תמרון", v.handling], ["נוחות", v.comfort], ["אמינות", v.reliab]]:
        var h := HBoxContainer.new()
        var l := _lbl(r[0], 17)
        l.custom_minimum_size.x = 110
        h.add_child(l)
        var pb := ProgressBar.new()
        pb.max_value = 10
        pb.value = r[1]
        pb.custom_minimum_size = Vector2(200, 18)
        pb.show_percentage = false
        h.add_child(pb)
        phone_body.add_child(h)
    phone_body.add_child(_lbl("עלות תחזוקה: %s" % v.maint, 17))
    phone_body.add_child(_lbl("שדרוגים", 22, Color("ffd600")))
    for k in Game.UPGRADES:
        var u: Dictionary = Game.UPGRADES[k]
        var lvl: int = Game.upgrades[Game.vehicle][k]
        var txt := "%s — מקסימום" % u.name if lvl >= 3 else "שדרג %s (רמה %d/3) — %d ₪" % [u.name, lvl, u.costs[lvl]]
        var b := _btn(txt, func(): Game.buy_upgrade(k))
        b.disabled = lvl >= 3
        phone_body.add_child(b)
        phone_body.add_child(_wrap(u.desc, 330, 15))
    phone_body.add_child(_lbl("הכלים שלך", 22, Color("ffd600")))
    for k in Game.VEHICLES:
        var vv: Dictionary = Game.VEHICLES[k]
        if Game.owned.has(k):
            var b := _btn("%s%s" % [vv.name, " (בשימוש)" if k == Game.vehicle else ""], func(): Game.switch_vehicle(k); Game.save_game())
            b.disabled = k == Game.vehicle
            phone_body.add_child(b)
        else:
            phone_body.add_child(_btn("קנה %s — %d ₪" % [vv.name, vv.price], func(): Game.buy_vehicle(k)))


func _page_history() -> void:
    _title("היסטוריית משלוחים")
    if Game.history.is_empty():
        phone_body.add_child(_wrap("עדיין לא הושלמו משלוחים."))
    for k in range(Game.history.size() - 1, maxi(-1, Game.history.size() - 21), -1):
        var e: Dictionary = Game.history[k]
        phone_body.add_child(_wrap("%s ← %s\n%d ₪ · %d שניות · %s" % [e.rest, e.addr, e.pay, e.time, "בזמן" if e.on_time else "באיחור"], 330, 16))


# ---------- חלון קניות (סופרמרקט / קניון / שוק / תחנת דלק) ----------
func show_shop(poi: Dictionary) -> void:
    close_modal(false)
    modal_open = true
    var p := PanelContainer.new()
    var v := VBoxContainer.new()
    v.add_theme_constant_override("separation", 8)
    v.add_child(_lbl(str(poi.name), 30, Color("ffd600"), true))
    v.add_child(_lbl("מזומן: %d ₪ · בנק: %d ₪" % [Game.cash, Game.balance], 20, Color("a8e6a1"), true))
    v.add_child(_wrap("תשלום במזומן; אם אין מספיק מזומן - בכרטיס מהחשבון.", 420, 15))
    for k in Game.SHOP_ITEMS:
        var it: Dictionary = Game.SHOP_ITEMS[k]
        var row := HBoxContainer.new()
        row.add_theme_constant_override("separation", 10)
        var nm := _lbl("%s — %d ₪" % [it.name, it.price], 22)
        nm.custom_minimum_size.x = 230
        row.add_child(nm)
        row.add_child(_lbl("ברשותך: %d" % int(Game.inventory.get(k, 0)), 16, Color(1, 1, 1, 0.6)))
        row.add_child(_btn("קנה", func(): _buy(k, poi), 90))
        v.add_child(row)
    v.add_child(_btn("סגור (Esc)", func(): close_modal(), 200))
    p.add_child(v)
    root.add_child(p)
    p.set_anchors_and_offsets_preset(Control.PRESET_CENTER, Control.PRESET_MODE_MINSIZE)
    p.grow_horizontal = Control.GROW_DIRECTION_BOTH
    p.grow_vertical = Control.GROW_DIRECTION_BOTH
    modal = p
    main.set_modal(true)


func close_modal(notify_main := true) -> void:
    if modal != null and is_instance_valid(modal):
        modal.queue_free()
    modal = null
    modal_open = false
    if notify_main:
        main.set_modal(false)


func _set_val(sb: SpinBox, v: int) -> void:
    sb.value = v


func _buy(k: String, poi: Dictionary) -> void:
    if _tx_guard():
        Game.buy_item(k)
        show_shop(poi)
