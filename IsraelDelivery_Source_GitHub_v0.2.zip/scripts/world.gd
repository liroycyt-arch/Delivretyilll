class_name World
extends Node3D
## עולם סכמטי בהשראת תל אביב: רשת רחובות, גרף ניווט, פיזור POI, בנייה מאוחדת (MeshBatch),
## תאורה מבוססת-חומרים פולטי אור (בלי אלפי מקורות אור), תנועה, רמזורים ורכבת.
## טעינה הדרגתית: אריחים (2x2 בלוקים) נטענים לפי מיקום וכיוון נסיעה; בנייה מתפזרת על פני פריימים (בלוק לפריים).

const N := 24
const S := 64.0
const R := 14.0
const SET := 4.0
const CHUNK := 2
const SIZE := 1536.0
const RAIL_I := 23
const SIG_CYCLE := 28.0
const SHADOW_KEYS := ["solid", "foliage", "metal"]
const VIS_END := {"win_a": 150.0, "win_b": 150.0, "glass_dark": 170.0, "shop_glass": 130.0, "sign": 140.0, "lamp_pool": 90.0, "paint": 120.0}

const V_NAMES := {0: "טיילת הרברט סמואל", 3: "רחוב בן יהודה", 7: "רחוב דיזנגוף", 12: "רחוב אבן גבירול", 22: "נתיבי איילון"}
const H_NAMES := {4: "רחוב ארלוזורוב", 8: "רחוב פרישמן", 12: "שדרות רוטשילד", 16: "רחוב אלנבי", 20: "רחוב ז'בוטינסקי"}
const ONEWAY_V := {5: 1}
const ONEWAY_H := {10: 1}
const LAND := {
    Vector2i(20, 5): ["מגדלי עזריאלי", "azrieli"],
    Vector2i(20, 6): ["קניון עזריאלי", "mall"],
    Vector2i(13, 3): ["קניון TLV", "mall"],
    Vector2i(3, 16): ["שוק הכרמל", "market"],
    Vector2i(0, 11): ["חוף תל אביב", "beach"],
    Vector2i(9, 13): ["שדרות רוטשילד", "plaza"],
    Vector2i(21, 12): ["נתיבי איילון", "ayalon"],
    Vector2i(23, 12): ["תחנת הרכבת", "station"],
}
## מקומות קבועים (מובטחים ליד נקודת ההתחלה: בנק, סופר, תחנת דלק, פארק, בית ספר)
const SPECIAL := {
    Vector2i(8, 11): ["supermarket", "סופר השכונה"],
    Vector2i(7, 12): ["bank", "בנק העיר"],
    Vector2i(9, 11): ["gas", "תחנת דלק הצפון"],
    Vector2i(6, 11): ["park", "גן העצמאות"],
    Vector2i(10, 12): ["school", "בית ספר יסודי אילון"],
    Vector2i(4, 6): ["supermarket", "מגה מרקט"],
    Vector2i(15, 8): ["supermarket", "סופר דיל"],
    Vector2i(12, 17): ["bank", "בנק המרכז"],
    Vector2i(2, 6): ["waterpark", "פארק המים"],
    Vector2i(5, 14): ["sport", "מגרש כדורגל שכונתי"],
    Vector2i(3, 10): ["sport", "מגרש כדורסל"],
    Vector2i(10, 15): ["construction", "אתר בנייה"],
    Vector2i(17, 10): ["clinic", "מרפאת הקהילה"],
    Vector2i(14, 13): ["gas", "תחנת דלק הדרום"],
    Vector2i(18, 15): ["supermarket", "מכולת פלוס"],
    Vector2i(19, 18): ["park", "פארק הירקון הקטן"],
    Vector2i(8, 20): ["school", "תיכון עירוני"],
    Vector2i(11, 8): ["park", "גינת הכיכר"],
}
const R_NAMES := ["פלאפל הפינה", "שווארמה הכיכר", "פיצה הים", "המבורגר העיר", "קפה הבוקר", "מאפיית הלחם", "סושי הנמל", "חומוס השכונה", "פיצה שמש", "בורקס הדר", "קפה לב העיר", "סלט וקפה"]
const B_NAMES := ["בנק העיר", "בנק הים", "בנק המרכז"]
const SUPER_NAMES := ["סופר פלוס", "מכולת הפינה", "מגה בעיר", "סופר דיל", "מינימרקט הכיכר"]
const GAS_NAMES := ["תחנת דלק הים", "תחנת דלק צמרת", "תחנת דלק איילון"]
const SHOP_NAMES := ["מכולת", "בית מרקחת", "מספרה", "פיצה", "קפה", "פרחים", "מאפייה", "חנות ספרים", "סלולר", "אופטיקה", "פלאפל", "סושי", "ירקן", "חנות בגדים"]
const PALETTE := [Color("efe9dd"), Color("e6e0d2"), Color("f4f1ea"), Color("dcd6c8"), Color("e9e4d6"), Color("d7dde0"), Color("cfc7b6"), Color("e8dcc4"), Color("c9c3b8"), Color("f1ede4")]
const STONE := [Color("c8b79a"), Color("b9a98c"), Color("d2c3a6"), Color("a99f8f")]
const SIGN_COLS := [Color("c0392b"), Color("e67e22"), Color("27ae60"), Color("8e44ad"), Color("2980b9"), Color("d35400"), Color("16a085")]
const AWNING := [Color("c0392b"), Color("2c7fb8"), Color("e5a50a"), Color("2f8f5b"), Color("7d3c98")]

var load_r := 2
var chunks := {}
var astar := AStar2D.new()
var mats: Dictionary = {}
var traffic = null
var train: AnimatableBody3D = null
var train_speed := 17.0
var sig_time := 0.0
var _sig_h := -1
var _sig_v := -1
var _hour := 12.0
var _applied_hour := -99.0
var _queue: Array = []
var _cur_c := Vector2i(-99, -99)
var _cur_node: Node3D = null
var _cur_idx := 0
var _poi_cache := {}


func _ready() -> void:
    for j in range(N + 1):
        for i in range(N + 1):
            astar.add_point(_nid(i, j), Vector2(i * S, j * S))
    for j in range(N + 1):
        for i in range(N + 1):
            if i < N:
                _link(_nid(i, j), _nid(i + 1, j), int(ONEWAY_H.get(j, 0)))
            if j < N:
                _link(_nid(i, j), _nid(i, j + 1), int(ONEWAY_V.get(i, 0)))
    _make_mats()
    _build_ground()
    _build_train()
    traffic = Traffic.new()
    traffic.world = self
    traffic.name = "Traffic"
    add_child(traffic)
    set_hour(12.0)
    _update_signals(true)


func _nid(i: int, j: int) -> int:
    return j * (N + 1) + i


func _link(a: int, b: int, dir: int) -> void:
    if dir == 0:
        astar.connect_points(a, b, true)
    elif dir > 0:
        astar.connect_points(a, b, false)
    else:
        astar.connect_points(b, a, false)


func _h(i: int, j: int) -> int:
    return absi(((i + 7) * 73856093) ^ ((j + 13) * 19349663))


# ---------- חומרים ----------
func _vm(rough: float, metal: float) -> StandardMaterial3D:
    var m := StandardMaterial3D.new()
    m.vertex_color_use_as_albedo = true
    m.roughness = rough
    m.metallic = metal
    m.cull_mode = BaseMaterial3D.CULL_DISABLED
    return m


func _em(col: Color, rough: float) -> StandardMaterial3D:
    var m := _vm(rough, 0.0)
    m.emission_enabled = true
    m.emission = col
    m.emission_energy_multiplier = 0.0
    return m


func _make_mats() -> void:
    mats["solid"] = _vm(0.92, 0.0)
    mats["paint"] = _vm(0.8, 0.0)
    mats["metal"] = _vm(0.45, 0.65)
    mats["foliage"] = _vm(1.0, 0.0)
    mats["water"] = _vm(0.06, 0.35)
    mats["glass_dark"] = _vm(0.1, 0.55)
    mats["win_a"] = _em(Color(1.0, 0.82, 0.5), 0.15)
    mats["win_b"] = _em(Color(0.85, 0.92, 1.0), 0.15)
    mats["shop_glass"] = _em(Color(1.0, 0.9, 0.7), 0.1)
    mats["sign"] = _em(Color(1.0, 1.0, 1.0), 0.4)
    mats["lamp"] = _em(Color(1.0, 0.85, 0.55), 0.3)
    var lp := StandardMaterial3D.new()
    lp.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    lp.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
    lp.blend_mode = BaseMaterial3D.BLEND_MODE_ADD
    lp.cull_mode = BaseMaterial3D.CULL_DISABLED
    lp.albedo_color = Color(1.0, 0.8, 0.45, 0.0)
    mats["lamp_pool"] = lp
    mats["sigH_r"] = _em(Color(1, 0.1, 0.05), 0.3)
    mats["sigH_y"] = _em(Color(1, 0.75, 0.0), 0.3)
    mats["sigH_g"] = _em(Color(0.1, 1, 0.3), 0.3)
    mats["sigV_r"] = _em(Color(1, 0.1, 0.05), 0.3)
    mats["sigV_y"] = _em(Color(1, 0.75, 0.0), 0.3)
    mats["sigV_g"] = _em(Color(0.1, 1, 0.3), 0.3)
    mats["carlight"] = _em(Color(1.0, 0.95, 0.8), 0.2)
    mats["taillight"] = _em(Color(1.0, 0.1, 0.05), 0.2)


func _night_factor(h: float) -> float:
    if h >= 19.5 or h < 5.0:
        return 1.0
    if h < 6.5:
        return 1.0 - smoothstep(5.0, 6.5, h)
    if h < 17.5:
        return 0.0
    return smoothstep(17.5, 19.5, h)


func night_factor() -> float:
    return _night_factor(_hour)


## מעדכן את כל הפולטים לפי שעת משחק (נקרא מ-Main; רק כשהשעה השתנתה מספיק).
func set_hour(h: float) -> void:
    _hour = h
    if absf(h - _applied_hour) < 0.004:
        return
    _applied_hour = h
    var n := _night_factor(h)
    var b_on := 1.0 if (h >= 17.5 or h < 1.5) else 0.0
    var shops_open := h >= 7.0 and h < 22.5
    _set_em("win_a", n * 2.2)
    _set_em("win_b", n * 2.0 * b_on)
    _set_em("lamp", n * 4.0)
    _set_em("sign", (0.25 + 1.8 * n) if shops_open else n * 0.0)
    _set_em("shop_glass", (0.35 + 1.0 * n) if shops_open else 0.04)
    _set_em("carlight", n * 3.0)
    _set_em("taillight", 0.4 + n * 1.2)
    var lp: StandardMaterial3D = mats["lamp_pool"]
    lp.albedo_color = Color(1.0, 0.8, 0.45, n * 0.22)


func _set_em(key: String, e: float) -> void:
    var m: StandardMaterial3D = mats[key]
    m.emission_energy_multiplier = e


# ---------- רמזורים ----------
## 0=אדום, 1=צהוב, 2=ירוק. axis 0 = נסיעה לאורך x, axis 1 = לאורך z
func signal_state(axis: int) -> int:
    var t := fposmod(sig_time, SIG_CYCLE)
    if axis == 0:
        if t < 11.0:
            return 2
        if t < 13.0:
            return 1
        return 0
    if t >= 14.0 and t < 25.0:
        return 2
    if t >= 25.0 and t < 27.0:
        return 1
    return 0


func _update_signals(force := false) -> void:
    var sh := signal_state(0)
    var sv := signal_state(1)
    if not force and sh == _sig_h and sv == _sig_v:
        return
    _sig_h = sh
    _sig_v = sv
    for pair in [["sigH", sh], ["sigV", sv]]:
        var pre: String = pair[0]
        var st: int = pair[1]
        _set_em(pre + "_r", 3.0 if st == 0 else 0.0)
        _set_em(pre + "_y", 3.0 if st == 1 else 0.0)
        _set_em(pre + "_g", 3.0 if st == 2 else 0.0)


## האם הרכבת תופסת את מעבר הרכבת בשורה j (מרחק בטיחות כלול)
func train_blocks_row(j: int) -> bool:
    if train == null:
        return false
    var zc := train.global_position.z
    var zr := j * S
    return absf(zc - zr) < 50.0


func _process(delta: float) -> void:
    sig_time += delta
    _update_signals()
    _stream_step()


func _physics_process(delta: float) -> void:
    if train != null:
        train.global_position.z += train_speed * delta
        if train.global_position.z > SIZE + 140.0:
            train.global_position.z = -140.0


# ---------- נתונים ----------
func _decide(i: int, j: int, h: int) -> Array:
    var key := Vector2i(i, j)
    if LAND.has(key):
        return ["landmark", LAND[key][0], LAND[key][1]]
    if SPECIAL.has(key):
        return [SPECIAL[key][0], SPECIAL[key][1], ""]
    if i == RAIL_I:
        return ["rail", "מסילת הרכבת", ""]
    var m := h % 100
    var q := floori(h / 100.0)
    if m < 11:
        return ["restaurant", R_NAMES[q % R_NAMES.size()], ""]
    if m < 14:
        return ["bank", B_NAMES[q % B_NAMES.size()], ""]
    if m < 18:
        return ["supermarket", SUPER_NAMES[q % SUPER_NAMES.size()], ""]
    if m < 20:
        return ["gas", GAS_NAMES[q % GAS_NAMES.size()], ""]
    if m < 22:
        return ["school", "בית ספר " + str(1 + q % 9), ""]
    if m < 28:
        return ["park", "גן " + str(1 + q % 20), ""]
    if m < 30:
        return ["sport", "מגרש ספורט " + str(1 + q % 6), ""]
    if m < 32:
        return ["construction", "אתר בנייה", ""]
    if m < 34:
        return ["clinic", "מרפאה " + str(1 + q % 6), ""]
    return ["home", "", ""]


func poi(i_in, j_in) -> Dictionary:
    var i := int(i_in)
    var j := int(j_in)
    var key := Vector2i(i, j)
    if _poi_cache.has(key):
        return _poi_cache[key]
    var h := _h(i, j)
    var dec: Array = _decide(i, j, h)
    var kind: String = dec[0]
    var nm: String = dec[1]
    var sub: String = dec[2]
    var addr := "%s %d" % [street_name_h(j + 1), 1 + floori(h / 7.0) % 60]
    var door := Vector3(i * S + S * 0.5, 0.0, (j + 1) * S - R * 0.5 - SET * 0.5)
    if kind == "rail":
        door.x = i * S + 16.0
    elif kind == "landmark" and sub == "station":
        door.x = i * S + 23.5
    var entry := door
    if kind == "supermarket" or kind == "gas":
        entry = Vector3(door.x, 0.0, j * S + R * 0.5 + 36.0)
    elif kind == "landmark" and sub == "mall":
        entry = Vector3(door.x, 0.0, j * S + R * 0.5 + 34.0)
    var p := {
        "kind": kind, "name": nm if nm != "" else addr, "sub": sub, "i": i, "j": j, "h": h,
        "door": door, "entry": entry,
        "node": Vector2i(i, j + 1), "addr": addr,
    }
    _poi_cache[key] = p
    return p


## יש כספומט? (בנק, קניונים, תחנות דלק, סופרמרקטים)
func has_atm(p: Dictionary) -> bool:
    var k: String = p.kind
    return k == "bank" or k == "gas" or k == "supermarket" or (k == "landmark" and (p.sub == "mall" or p.sub == "azrieli"))


func has_shop(p: Dictionary) -> bool:
    var k: String = p.kind
    return k == "supermarket" or (k == "landmark" and (p.sub == "mall" or p.sub == "market")) or k == "gas"


## נקודת הגישה האמיתית של מקום: הכניסה ללקוח (entry), ואם אין - הדלת/רחבה סמוכה לכביש
func access_point(p: Dictionary) -> Vector3:
    return p.entry


func random_poi(kind: String, near: Vector3, radius: float) -> Dictionary:
    for _t in range(300):
        var p := poi(randi() % N, randi() % N)
        if p.kind == kind and p.door.distance_to(near) <= radius and p.door.distance_to(near) > 40.0:
            return p
    for i in range(N):
        for j in range(N):
            var p := poi(i, j)
            if p.kind == kind:
                return p
    return poi(0, 0)


func nearest_poi(kind: String, pos: Vector3) -> Dictionary:
    var best := {}
    var bd := 1e12
    for i in range(N):
        for j in range(N):
            var p := poi(i, j)
            if p.kind == kind:
                var d: float = p.door.distance_to(pos)
                if d < bd:
                    bd = d
                    best = p
    return best


func destinations(pos: Vector3) -> Array:
    var out: Array = []
    for k in LAND:
        out.append(poi(k.x, k.y))
    for kind in ["restaurant", "bank", "supermarket", "gas", "park", "school", "sport", "clinic", "waterpark", "construction"]:
        var r := nearest_poi(kind, pos)
        if not r.is_empty():
            out.append(r)
    return out


## בלוק במיקום עולמי
func poi_at(pos: Vector3) -> Dictionary:
    return poi(clampi(floori(pos.x / S), 0, N - 1), clampi(floori(pos.z / S), 0, N - 1))


func kind_label(k: String) -> String:
    var names := {"restaurant": "מסעדה", "bank": "בנק", "supermarket": "סופרמרקט", "gas": "תחנת דלק", "park": "פארק", "school": "בית ספר",
        "sport": "מגרש ספורט", "clinic": "מרפאה", "waterpark": "פארק מים", "construction": "אתר בנייה", "landmark": "ציון דרך", "rail": "מסילת רכבת", "home": "כתובת"}
    return str(names.get(k, ""))


func street_name_h(row: int) -> String:
    return H_NAMES.get(row, "רחוב %d" % row)


func street_name_v(col: int) -> String:
    return V_NAMES.get(col, "רחוב %d" % (col + 30))


func street_name(a: Vector3, b: Vector3) -> String:
    if absf(b.x - a.x) > absf(b.z - a.z):
        return street_name_h(roundi(a.z / S))
    return street_name_v(roundi(a.x / S))


## מסלול על רשת הכבישים (A*, חד-סטריות) ואז: נקודת כביש מול הכניסה -> דלת -> כניסה. לא קו ישר בין שתי נקודות.
func route(from: Vector3, p: Dictionary) -> PackedVector3Array:
    var a := _nid(clampi(roundi(from.x / S), 0, N), clampi(roundi(from.z / S), 0, N))
    var b := _nid(p.node.x, p.node.y)
    var out := PackedVector3Array()
    for id in astar.get_id_path(a, b):
        out.append(Vector3((id % (N + 1)) * S, 0.0, floori(float(id) / (N + 1)) * S))
    var door: Vector3 = p.door
    out.append(Vector3(door.x, 0.0, (int(p.j) + 1) * S))
    out.append(door)
    var entry: Vector3 = p.entry
    if entry.distance_to(door) > 1.0:
        out.append(entry)
    return out


## האם קיים מסלול ליעד (לבדיקת נגישות לפני התחלת ניווט)
func is_reachable(from: Vector3, p: Dictionary) -> bool:
    var a := _nid(clampi(roundi(from.x / S), 0, N), clampi(roundi(from.z / S), 0, N))
    var b := _nid(p.node.x, p.node.y)
    return not astar.get_id_path(a, b).is_empty()


# ---------- טעינה הדרגתית ----------
func _cc(pos: Vector3) -> Vector2i:
    return Vector2i(floori(pos.x / (CHUNK * S)), floori(pos.z / (CHUNK * S)))


func _valid(c: Vector2i) -> bool:
    return c.x >= 0 and c.y >= 0 and c.x < N / CHUNK and c.y < N / CHUNK


func _wanted(pos: Vector3, vel: Vector3) -> Array:
    var c := _cc(pos)
    var out: Array = []
    for dx in range(-load_r, load_r + 1):
        for dz in range(-load_r, load_r + 1):
            var w := c + Vector2i(dx, dz)
            if _valid(w) and not out.has(w):
                out.append(w)
    if vel.length() > 1.0:
        var dir := vel.normalized()
        for k in range(1, 4):
            var w := _cc(pos + dir * k * CHUNK * S * 0.9)
            if _valid(w) and not out.has(w):
                out.append(w)
    out.sort_custom(func(a, b): return (a - c).length_squared() < (b - c).length_squared())
    return out


func update_streaming(pos: Vector3, vel: Vector3) -> void:
    var c := _cc(pos)
    for w in _wanted(pos, vel):
        if not chunks.has(w) and not _queue.has(w):
            _queue.append(w)
    for k in chunks.keys():
        if absi(k.x - c.x) > load_r + 1 or absi(k.y - c.y) > load_r + 1:
            if k == _cur_c:
                _cur_node = null
            chunks[k].queue_free()
            chunks.erase(k)
    _queue = _queue.filter(func(q): return absi(q.x - c.x) <= load_r + 2 and absi(q.y - c.y) <= load_r + 2)


## בנייה הדרגתית: בלוק אחד בכל פריים כדי למנוע קפיצות (hitches)
func _stream_step() -> void:
    if _cur_node != null and not is_instance_valid(_cur_node):
        _cur_node = null
    if _cur_node == null:
        if _queue.is_empty():
            return
        var k: Vector2i = _queue.pop_front()
        if chunks.has(k) or not _valid(k):
            return
        _cur_c = k
        _cur_node = Node3D.new()
        _cur_node.name = "C_%d_%d" % [k.x, k.y]
        add_child(_cur_node)
        chunks[k] = _cur_node
        _cur_idx = 0
    var bi := _cur_c.x * CHUNK + _cur_idx % CHUNK
    var bj := _cur_c.y * CHUNK + _cur_idx / CHUNK
    _build_block(_cur_node, bi, bj)
    _cur_idx += 1
    if _cur_idx >= CHUNK * CHUNK:
        _cur_node = null


func _ensure(c: Vector2i) -> void:
    if chunks.has(c) or not _valid(c):
        return
    var node := Node3D.new()
    node.name = "C_%d_%d" % [c.x, c.y]
    add_child(node)
    chunks[c] = node
    for bj in range(c.y * CHUNK, (c.y + 1) * CHUNK):
        for bi in range(c.x * CHUNK, (c.x + 1) * CHUNK):
            _build_block(node, bi, bj)


func preload_around(pos: Vector3, cb: Callable) -> void:
    var need := _wanted(pos, Vector3.ZERO)
    var total := maxi(1, need.size())
    var k := 0
    for c in need:
        _ensure(c)
        k += 1
        cb.call(float(k) / total)
        await get_tree().process_frame


func set_quality(q: int) -> void:
    load_r = [1, 2, 3][clampi(q, 0, 2)]


# ---------- קרקע ----------
func _plain_mat(c: Color) -> StandardMaterial3D:
    var m := StandardMaterial3D.new()
    m.albedo_color = c
    m.roughness = 0.95
    return m


func _gbox(pos: Vector3, size: Vector3, col: Color, solid := true) -> void:
    var mi := MeshInstance3D.new()
    var bm := BoxMesh.new()
    bm.size = size
    mi.mesh = bm
    mi.material_override = _plain_mat(col)
    mi.position = pos
    mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
    add_child(mi)
    if solid:
        var sb := StaticBody3D.new()
        var cs := CollisionShape3D.new()
        var sh := BoxShape3D.new()
        sh.size = size
        cs.shape = sh
        sb.add_child(cs)
        mi.add_child(sb)


func _wall(pos: Vector3, size: Vector3) -> void:
    var sb := StaticBody3D.new()
    sb.position = pos
    var cs := CollisionShape3D.new()
    var sh := BoxShape3D.new()
    sh.size = size
    cs.shape = sh
    sb.add_child(cs)
    add_child(sb)


func _build_ground() -> void:
    _gbox(Vector3(SIZE * 0.5 - 15.0, -0.5, SIZE * 0.5), Vector3(SIZE + 150.0, 1.0, SIZE + 120.0), Color("34373c"))
    _gbox(Vector3(-48.5, 0.02, SIZE * 0.5), Vector3(83.0, 0.04, SIZE + 120.0), Color("e3cf9f"), false)
    _gbox(Vector3(-345.0, -0.3, SIZE * 0.5), Vector3(510.0, 0.2, SIZE + 400.0), Color("2a7fb8"), false)
    _wall(Vector3(-90.0, 10, SIZE * 0.5), Vector3(2, 20, SIZE + 120))
    _wall(Vector3(SIZE + 60.0, 10, SIZE * 0.5), Vector3(2, 20, SIZE + 120))
    _wall(Vector3(SIZE * 0.5, 10, -60.0), Vector3(SIZE + 150, 20, 2))
    _wall(Vector3(SIZE * 0.5, 10, SIZE + 60.0), Vector3(SIZE + 150, 20, 2))


# ---------- אביזרי עזר לבנייה ----------
var _rng := RandomNumberGenerator.new()


func _jit(c: Color, amt: float) -> Color:
    var k := _rng.randf_range(-amt, amt)
    return Color(clampf(c.r + k, 0, 1), clampf(c.g + k, 0, 1), clampf(c.b + k, 0, 1), 1.0)


func _pick(arr: Array) -> Color:
    return arr[_rng.randi() % arr.size()]


func _label(parent: Node, text: String, pos: Vector3, px: int, col: Color, face := 0, range_end := 85.0) -> void:
    var l := Label3D.new()
    l.text = text
    l.font = Game.font
    l.font_size = px
    l.pixel_size = 0.01
    l.modulate = col
    l.outline_size = 6
    l.outline_modulate = Color(0, 0, 0, 0.55)
    l.position = pos
    l.visibility_range_end = range_end
    l.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
    match face:
        1:
            l.rotation.y = PI
        2:
            l.rotation.y = PI / 2.0
        3:
            l.rotation.y = -PI / 2.0
    parent.add_child(l)


func _lamp(b: MeshBatch, x: float, z: float, dx: float, dz: float) -> void:
    b.box("metal", Vector3(x, 3.75, z), Vector3(0.18, 7.5, 0.18), Color("5a5f66"), 0.0, true)
    var ax := x + dx * 0.9
    var az := z + dz * 0.9
    b.box("metal", Vector3(ax, 7.4, az), Vector3(absf(dx) * 1.8 + 0.1, 0.1, absf(dz) * 1.8 + 0.1), Color("5a5f66"))
    var hx := x + dx * 1.7
    var hz := z + dz * 1.7
    b.box("lamp", Vector3(hx, 7.3, hz), Vector3(0.7, 0.14, 0.7), Color("fff2cc"))
    b.flat("lamp_pool", Vector3(hx, 0.07, hz), 13.0, 13.0, Color.WHITE)
    b.flat("lamp_pool", Vector3(hx, 0.075, hz), 13.0, 13.0, Color.WHITE, PI / 4.0)


func _bench(b: MeshBatch, x: float, z: float, rot: float) -> void:
    b.box("solid", Vector3(x, 0.45, z), Vector3(1.8, 0.1, 0.5), Color("8a5a33"), rot)
    var back := Vector3(0, 0, -0.25).rotated(Vector3.UP, rot)
    b.box("solid", Vector3(x + back.x, 0.75, z + back.z), Vector3(1.8, 0.4, 0.08), Color("8a5a33"), rot)
    b.box("metal", Vector3(x, 0.22, z), Vector3(1.6, 0.44, 0.1), Color("3c3f44"), rot)


func _bin(b: MeshBatch, x: float, z: float) -> void:
    b.cyl("solid", Vector3(x, 0.45, z), 0.28, 0.9, _pick([Color("2f6f4f"), Color("34495e"), Color("5d6d7e")]), true)


func _cabinet(b: MeshBatch, x: float, z: float, rot: float) -> void:
    b.box("metal", Vector3(x, 0.7, z), Vector3(1.1, 1.4, 0.55), Color("8d949b"), rot, true)
    b.box("solid", Vector3(x, 1.43, z), Vector3(1.2, 0.06, 0.6), Color("6d737a"), rot)


func _power_pole(b: MeshBatch, x: float, z: float) -> void:
    b.cyl("solid", Vector3(x, 4.5, z), 0.16, 9.0, Color("7b6a58"), true)
    b.box("solid", Vector3(x, 8.4, z), Vector3(2.2, 0.12, 0.12), Color("6a5a4a"))
    b.box("solid", Vector3(x, 7.7, z), Vector3(1.6, 0.1, 0.1), Color("6a5a4a"))


func _wires(b: MeshBatch, x0: float, z0: float, x1: float, z1: float) -> void:
    var c := Vector3((x0 + x1) * 0.5, 8.2, (z0 + z1) * 0.5)
    var seg_len := Vector2(x1 - x0, z1 - z0).length()
    var ang := atan2(-(z1 - z0), x1 - x0)
    b.box("metal", c, Vector3(seg_len, 0.03, 0.03), Color("202225"), ang)
    b.box("metal", c + Vector3(0, -0.7, 0), Vector3(seg_len, 0.03, 0.03), Color("202225"), ang)


func _sign_pole(b: MeshBatch, x: float, z: float, col: Color, rot := 0.0) -> void:
    b.box("metal", Vector3(x, 1.2, z), Vector3(0.07, 2.4, 0.07), Color("8d949b"), 0.0, true)
    b.box("solid", Vector3(x, 2.3, z), Vector3(0.6, 0.6, 0.04), col, rot)
    b.box("solid", Vector3(x, 2.3, z), Vector3(0.45, 0.45, 0.05), Color.WHITE, rot)


func _fence(b: MeshBatch, x0: float, z0: float, x1: float, z1: float, h := 1.4, col := Color("5d6670"), gaps: Array = []) -> void:
    ## גדר ישרה (אופקית או אנכית). gaps: רשימת [מ,עד] לפתחים לאורך הציר.
    var horiz := absf(z1 - z0) < 0.01
    var a := minf(x0, x1) if horiz else minf(z0, z1)
    var e := maxf(x0, x1) if horiz else maxf(z0, z1)
    var segs: Array = [[a, e]]
    for g in gaps:
        var nxt: Array = []
        for sg in segs:
            if g[1] <= sg[0] or g[0] >= sg[1]:
                nxt.append(sg)
            else:
                if g[0] > sg[0]:
                    nxt.append([sg[0], g[0]])
                if g[1] < sg[1]:
                    nxt.append([g[1], sg[1]])
        segs = nxt
    for sg in segs:
        var seg_len: float = sg[1] - sg[0]
        if seg_len < 0.2:
            continue
        var mid: float = (sg[0] + sg[1]) * 0.5
        if horiz:
            b.box("metal", Vector3(mid, h * 0.5, z0), Vector3(seg_len, h, 0.08), col, 0.0, true)
        else:
            b.box("metal", Vector3(x0, h * 0.5, mid), Vector3(0.08, h, seg_len), col, 0.0, true)


# ---------- צמחייה ----------
func _tree(b: MeshBatch, x: float, z: float, kind := -1) -> void:
    var k := kind if kind >= 0 else _rng.randi() % 10
    if k < 5:
        _broadleaf(b, x, z)
    elif k < 8:
        _palm(b, x, z)
    elif k < 9:
        _ficus(b, x, z)
    else:
        _shrub(b, x, z)


func _broadleaf(b: MeshBatch, x: float, z: float) -> void:
    var th := _rng.randf_range(2.4, 3.6)
    b.cyl("foliage", Vector3(x, th * 0.5, z), 0.17, th, Color("5b4636"), true)
    var gc := Color("3f7d3a").lerp(Color("5f9a44"), _rng.randf())
    for _n in range(3):
        var r := _rng.randf_range(1.1, 1.9)
        b.sphere("foliage", Vector3(x + _rng.randf_range(-0.8, 0.8), th + _rng.randf_range(0.4, 1.6), z + _rng.randf_range(-0.8, 0.8)), Vector3(r * 2.0, r * 1.7, r * 2.0), _jit(gc, 0.05))


func _palm(b: MeshBatch, x: float, z: float) -> void:
    var lean := Vector3(_rng.randf_range(-0.12, 0.12), 0.0, _rng.randf_range(-0.12, 0.12))
    var segs := 5
    var seg_h := _rng.randf_range(1.2, 1.7)
    var pos := Vector3(x, 0, z)
    for k in range(segs):
        var rad := 0.2 - k * 0.012
        b.cyl("foliage", pos + Vector3(0, seg_h * 0.5, 0), rad, seg_h + 0.05, Color("8a6e4b").lerp(Color("6e5a40"), float(k) / segs), k == 0)
        pos += Vector3(lean.x * (k + 1) * 0.5, seg_h, lean.z * (k + 1) * 0.5)
    var crown := pos
    var gc := Color("3d8a3a").lerp(Color("5aa044"), _rng.randf())
    var n := 8
    var phase := _rng.randf() * TAU
    for f in range(n):
        var ang := phase + TAU * f / n
        var dir := Vector3(cos(ang), 0.0, sin(ang))
        var tip := crown + dir * _rng.randf_range(2.0, 2.6) + Vector3(0, -_rng.randf_range(0.6, 1.1), 0)
        b.blade("foliage", crown + Vector3(0, 0.1, 0), tip, 0.7, _jit(gc, 0.06))
    b.sphere("foliage", crown, Vector3(0.4, 0.4, 0.4), Color("6b5a2c"))


func _ficus(b: MeshBatch, x: float, z: float) -> void:
    b.cyl("foliage", Vector3(x, 1.6, z), 0.45, 3.2, Color("6b5a48"), true)
    var gc := Color("2f6f34")
    for _n in range(5):
        var r := _rng.randf_range(1.8, 2.6)
        b.sphere("foliage", Vector3(x + _rng.randf_range(-1.6, 1.6), 4.0 + _rng.randf_range(0.0, 2.0), z + _rng.randf_range(-1.6, 1.6)), Vector3(r * 2.0, r * 1.6, r * 2.0), _jit(gc, 0.05))


func _shrub(b: MeshBatch, x: float, z: float) -> void:
    var gc := Color("4a8a3c").lerp(Color("2f6f34"), _rng.randf())
    for _n in range(_rng.randi_range(2, 3)):
        var r := _rng.randf_range(0.4, 0.8)
        b.sphere("foliage", Vector3(x + _rng.randf_range(-0.5, 0.5), r * 0.7, z + _rng.randf_range(-0.5, 0.5)), Vector3(r * 2.0, r * 1.4, r * 2.0), _jit(gc, 0.06))
    if _rng.randf() < 0.5:
        var fc: Color = _pick([Color("e84a8a"), Color("f2c200"), Color("e8e8f0"), Color("e0503a"), Color("b46cff")])
        for _n in range(4):
            b.box("foliage", Vector3(x + _rng.randf_range(-0.6, 0.6), 0.75 + _rng.randf_range(0, 0.3), z + _rng.randf_range(-0.6, 0.6)), Vector3(0.14, 0.14, 0.14), fc)


## פיזור טבעי של עצים לאורך רצועה (ללא מרווחים קבועים), תוך הימנעות מאזורים שמורים (x בלבד)
func _scatter_row(b: MeshBatch, xa: float, xb: float, z: float, spacing: float, avoid: Array, jitter_z := 1.2, density := 0.85) -> void:
    var x := xa + _rng.randf_range(0.0, spacing * 0.6)
    while x < xb:
        var ok := true
        for av in avoid:
            if x > av[0] and x < av[1]:
                ok = false
        if ok and _rng.randf() < density:
            _tree(b, x, z + _rng.randf_range(-jitter_z, jitter_z))
        x += spacing * _rng.randf_range(0.7, 1.5)


func _scatter_area(b: MeshBatch, x0: float, z0: float, x1: float, z1: float, count: int, avoid_rects: Array = []) -> void:
    for _n in range(count):
        var x := _rng.randf_range(x0, x1)
        var z := _rng.randf_range(z0, z1)
        var ok := true
        for r in avoid_rects:
            if x > r[0] and x < r[2] and z > r[1] and z < r[3]:
                ok = false
        if ok:
            _tree(b, x, z)


# ---------- חזיתות ----------
## חלונות בחזית. face: 0=+z, 1=-z, 2=+x, 3=-x.  c = מרכז החזית (x,z), len_w = אורך החזית.
func _windows(b: MeshBatch, face: int, c: Vector3, len_w: float, floors: int, fh: float, y0: float, ww: float, wh: float, gap: float, first_floor := 0, shutters := false) -> void:
    var cols := maxi(1, int((len_w - gap) / (ww + gap)))
    var start := -((cols - 1) * (ww + gap)) * 0.5
    var off := 0.04
    for f in range(first_floor, floors):
        var y := y0 + f * fh + fh * 0.55
        for k in range(cols):
            var u := start + k * (ww + gap)
            var pos := c
            match face:
                0:
                    pos = Vector3(c.x + u, y, c.z + off)
                1:
                    pos = Vector3(c.x + u, y, c.z - off)
                2:
                    pos = Vector3(c.x + off, y, c.z + u)
                3:
                    pos = Vector3(c.x - off, y, c.z + u)
            var r := _rng.randf()
            var key := "glass_dark"
            var col := Color(0.18, 0.24, 0.3).lerp(Color(0.35, 0.45, 0.55), _rng.randf())
            if r < 0.3:
                key = "win_a"
                col = Color(1.0, 0.85, 0.55)
            elif r < 0.45:
                key = "win_b"
                col = Color(0.9, 0.95, 1.0)
            b.wall_quad(key, pos, ww, wh, face, col)
            if shutters and _rng.randf() < 0.45:
                var frac := _rng.randf_range(0.25, 0.7)
                var sp := pos + Vector3(0, wh * 0.5 - wh * frac * 0.5, 0)
                var sc := Color("9aa0a6").lerp(Color("b9a98c"), _rng.randf())
                match face:
                    0:
                        sp.z += 0.03
                    1:
                        sp.z -= 0.03
                    2:
                        sp.x += 0.03
                    3:
                        sp.x -= 0.03
                b.wall_quad("solid", sp, ww, wh * frac, face, sc)


## מרפסות בחזית הקדמית (+z): לוח, מעקה, לפעמים סוכך/צמח
func _balconies(b: MeshBatch, cx: float, zf: float, bw: float, floors: int, fh: float, y0: float, every := 2, glass := false) -> void:
    var cols := maxi(1, int(bw / 5.5))
    var start := -((cols - 1) * 5.5) * 0.5
    for f in range(1, floors):
        if f % every != 0 and every > 1:
            continue
        for k in range(cols):
            if _rng.randf() < 0.25:
                continue
            var x := cx + start + k * 5.5
            var y := y0 + f * fh
            b.box("solid", Vector3(x, y + 0.08, zf + 0.7), Vector3(3.2, 0.16, 1.4), Color("d9d4c8"))
            var rk := "glass_dark" if glass else "metal"
            var rc := Color(0.3, 0.45, 0.5) if glass else Color("4a4f55")
            b.box(rk, Vector3(x, y + 0.7, zf + 1.38), Vector3(3.2, 0.95, 0.05), rc)
            b.box(rk, Vector3(x - 1.58, y + 0.7, zf + 0.7), Vector3(0.05, 0.95, 1.4), rc)
            b.box(rk, Vector3(x + 1.58, y + 0.7, zf + 0.7), Vector3(0.05, 0.95, 1.4), rc)
            if _rng.randf() < 0.3:
                b.box("foliage", Vector3(x + _rng.randf_range(-1.0, 1.0), y + 0.35, zf + 1.2), Vector3(0.7, 0.4, 0.3), Color("3f7d3a"))
            if _rng.randf() < 0.18:
                b.box("solid", Vector3(x, y + fh - 0.5, zf + 0.9), Vector3(3.2, 0.06, 1.8), _pick(AWNING), 0.0, false, Vector3(0.25, 0, 0))


## גג: מעקה, דודי שמש, מיכלי מים, מזגנים, חדר מדרגות
func _roof(b: MeshBatch, cx: float, cz: float, bw: float, bd: float, top: float) -> void:
    var pc := Color("d8d2c4")
    b.box("solid", Vector3(cx, top + 0.4, cz + bd * 0.5), Vector3(bw, 0.8, 0.2), pc)
    b.box("solid", Vector3(cx, top + 0.4, cz - bd * 0.5), Vector3(bw, 0.8, 0.2), pc)
    b.box("solid", Vector3(cx + bw * 0.5, top + 0.4, cz), Vector3(0.2, 0.8, bd), pc)
    b.box("solid", Vector3(cx - bw * 0.5, top + 0.4, cz), Vector3(0.2, 0.8, bd), pc)
    b.box("solid", Vector3(cx + _rng.randf_range(-bw * 0.25, bw * 0.25), top + 1.3, cz - bd * 0.2), Vector3(3.2, 2.6, 3.0), Color("c9c3b4"))
    var n := _rng.randi_range(1, 3)
    for _k in range(n):
        var px := cx + _rng.randf_range(-bw * 0.35, bw * 0.35)
        var pz := cz + _rng.randf_range(-bd * 0.3, bd * 0.3)
        match _rng.randi() % 3:
            0:
                b.cyl("metal", Vector3(px, top + 1.2, pz), 0.55, 1.1, Color("e8ecef"))
                b.box("metal", Vector3(px, top + 0.4, pz), Vector3(0.9, 0.8, 0.9), Color("6d737a"))
            1:
                b.box("metal", Vector3(px, top + 0.7, pz), Vector3(1.8, 0.08, 1.2), Color("1f3b5c"), 0.0, false, Vector3(-0.5, 0, 0))
                b.cyl("metal", Vector3(px, top + 0.9, pz - 1.0), 0.35, 1.2, Color("dfe3e6"))
            2:
                b.box("metal", Vector3(px, top + 0.4, pz), Vector3(0.9, 0.7, 0.7), Color("b8bec4"))
    if _rng.randf() < 0.35:
        b.box("metal", Vector3(cx + bw * 0.3, top + 3.0, cz), Vector3(0.06, 4.0, 0.06), Color("4a4f55"))


## כניסה ראשית: דלת, גגון, מספר בניין (נקודת הכניסה היא תמיד door.x)
func _entrance(b: MeshBatch, root: Node3D, g: Dictionary, p: Dictionary, glass := false) -> void:
    var dx: float = g.door.x
    var zf: float = g.zf
    var dc := Color(0.15, 0.22, 0.28) if glass else Color("33373d")
    b.box("glass_dark" if glass else "solid", Vector3(dx, 1.2, zf + 0.06), Vector3(2.2 if glass else 1.6, 2.4, 0.12), dc)
    b.box("solid", Vector3(dx, 2.7, zf + 0.7), Vector3(3.2, 0.14, 1.5), Color("8d949b"))
    b.box("solid", Vector3(dx - 1.5, 1.35, zf + 1.35), Vector3(0.1, 2.7, 0.1), Color("6d737a"))
    b.box("solid", Vector3(dx + 1.5, 1.35, zf + 1.35), Vector3(0.1, 2.7, 0.1), Color("6d737a"))
    b.box("solid", Vector3(dx, 0.08, zf + 0.9), Vector3(3.6, 0.16, 2.2), Color("a8a49b"))
    if p.kind == "home":
        _label(root, str(p.addr), Vector3(dx, 3.2, zf + 0.25), 44, Color.WHITE, 0, 70.0)


# ---------- אזורים ----------
func _zone(i: int, j: int) -> String:
    if i <= 1:
        return "beach"
    if i >= 20 and j <= 9:
        return "business"
    if i >= 19 and j >= 14:
        return "industrial"
    if i >= 6 and i <= 13 and j >= 7 and j <= 17:
        return "center"
    return "resid"


func _on_main(i: int, j: int) -> bool:
    return V_NAMES.has(i) or V_NAMES.has(i + 1) or H_NAMES.has(j) or H_NAMES.has(j + 1)


# ---------- בניית בלוק ----------
func _build_block(root: Node3D, bi: int, bj: int) -> void:
    var p: Dictionary = poi(bi, bj)
    _rng.seed = int(p.h)
    var blk := Node3D.new()
    blk.name = "K_%d_%d" % [bi, bj]
    root.add_child(blk)
    var b := MeshBatch.new()
    var w := S - R
    var x0 := bi * S + R * 0.5
    var z0 := bj * S + R * 0.5
    var g := {
        "bi": bi, "bj": bj, "x0": x0, "z0": z0, "w": w, "cx": x0 + w * 0.5, "cz": z0 + w * 0.5,
        "zf": z0 + w - SET, "door": p.door, "p": p, "root": blk,
    }
    b.flat("solid", Vector3(g.cx, 0.03, g.cz), w, w, Color("c9c6bf"))
    _street_common(b, blk, g)
    var kind: String = p.kind
    match kind:
        "landmark":
            _build_landmark(b, blk, g)
        "restaurant":
            _build_restaurant(b, blk, g)
        "bank":
            _build_bank(b, blk, g)
        "supermarket":
            _build_supermarket(b, blk, g)
        "gas":
            _build_gas(b, blk, g)
        "school":
            _build_school(b, blk, g)
        "park":
            _build_park(b, blk, g)
        "sport":
            _build_sport(b, blk, g)
        "construction":
            _build_construction(b, blk, g)
        "clinic":
            _build_clinic(b, blk, g)
        "waterpark":
            _build_waterpark(b, blk, g)
        "rail":
            _build_rail(b, blk, g)
        _:
            _build_home(b, blk, g)
    b.commit(blk, mats, SHADOW_KEYS, VIS_END)


## תשתית רחוב משותפת: סימוני כביש, מעברי חציה, רמזורים, עמודי תאורה, שלטי רחוב, תחנות, ארונות
func _street_common(b: MeshBatch, blk: Node3D, g: Dictionary) -> void:
    var bi: int = g.bi
    var bj: int = g.bj
    var x0: float = g.x0
    var z0: float = g.z0
    var w: float = g.w
    var nx := (bi + 1) * S
    var nz := (bj + 1) * S
    var rail := bi == RAIL_I
    # קווי אמצע מקווקווים (לא בחד-סטרי)
    if not ONEWAY_H.has(bj + 1):
        var xx := bi * S + 12.0
        while xx < (bi + 1) * S - 12.0:
            b.flat("paint", Vector3(xx + 2.0, 0.02, nz), 4.0, 0.25, Color("e8e8e8"))
            xx += 8.0
    if not ONEWAY_V.has(bi + 1):
        var zz := bj * S + 12.0
        while zz < (bj + 1) * S - 12.0:
            b.flat("paint", Vector3(nx, 0.02, zz + 2.0), 0.25, 4.0, Color("e8e8e8"))
            zz += 8.0
    # שפת מדרכה (ויזואלית בלבד, בלי התנגשות כדי לא לתקוע כלי רכב)
    b.box("solid", Vector3(g.cx, 0.08, z0 + w + 0.15), Vector3(w, 0.16, 0.3), Color("dedad2"))
    b.box("solid", Vector3(x0 + w + 0.15, 0.08, g.cz), Vector3(0.3, 0.16, w), Color("dedad2"))
    if bi >= N - 1 and bj >= N - 1:
        return
    # מעבר חציה בשתי זרועות של הצומת הדרום-מזרחי
    if bi + 1 < N and bj + 1 < N:
        for k in range(8):
            var off := -4.2 + k * 1.2
            b.flat("paint", Vector3(nx - 11.0, 0.022, nz + off), 4.0, 0.6, Color("f0f0f0"))
            b.flat("paint", Vector3(nx + off, 0.022, nz - 11.0), 0.6, 4.0, Color("f0f0f0"))
        _signal_pole(b, nx - 8.3, nz - 8.3, 3, 1)
        _signal_pole(b, nx + 8.3, nz + 8.3, 2, 0)
        # שלטי רחוב (בעברית) על עמוד הרמזור
        var hn := street_name_h(bj + 1)
        var vn := street_name_v(bi + 1)
        b.box("solid", Vector3(nx - 8.3, 5.9, nz - 8.42), Vector3(1.9, 0.42, 0.05), Color("1d5fa8"))
        b.box("solid", Vector3(nx - 8.42, 5.4, nz - 8.3), Vector3(0.05, 0.42, 1.9), Color("1d5fa8"))
        if H_NAMES.has(bj + 1) or V_NAMES.has(bi + 1) or rail:
            _label(blk, hn, Vector3(nx - 8.3, 5.9, nz - 8.46), 22, Color.WHITE, 1, 55.0)
            _label(blk, vn, Vector3(nx - 8.46, 5.4, nz - 8.3), 22, Color.WHITE, 3, 55.0)
    # עמודי תאורה לאורך החזית והצד המזרחי (מקום פנוי ליד הדלת)
    _lamp(b, bi * S + 14.0, z0 + w - 1.0, 0.0, 1.0)
    _lamp(b, bi * S + 50.0, z0 + w - 1.0, 0.0, 1.0)
    _lamp(b, x0 + w - 1.0, bj * S + 18.0, 1.0, 0.0)
    _lamp(b, x0 + w - 1.0, bj * S + 46.0, 1.0, 0.0)
    # ארון תקשורת / חשמל ופח (הסתברותי)
    if _rng.randf() < 0.5:
        _cabinet(b, x0 + w - 1.8, z0 + _rng.randf_range(8.0, 40.0), PI / 2.0)
    if _rng.randf() < 0.5:
        _bin(b, bi * S + _rng.randf_range(38.0, 46.0), z0 + w - 1.2)
    # תמרורים
    if _rng.randf() < 0.35:
        _sign_pole(b, bi * S + 20.0, z0 + w - 0.8, Color("c0392b"))
    # תחנת אוטובוס
    var pk: String = g.p.kind
    if (pk == "home" or pk == "restaurant" or pk == "bank" or pk == "clinic") and not rail and _rng.randf() < 0.28:
        _bus_stop(b, blk, bi * S + 23.0, z0 + w - 1.6)
    # עמודי חשמל באזור התעשייה / מסילה
    var zn := _zone(bi, bj)
    if zn == "industrial" or rail:
        _power_pole(b, x0 + 3.0, z0 + w - 0.6)
        _power_pole(b, x0 + w - 3.0, z0 + w - 0.6)
        _wires(b, x0 + 3.0, z0 + w - 0.6, x0 + w - 3.0, z0 + w - 0.6)


func _signal_pole(b: MeshBatch, px: float, pz: float, face_h: int, face_v: int) -> void:
    ## face_h: כיוון הפנס של ציר H (3 = אל -x, 2 = אל +x); face_v: של ציר V (1 = אל -z, 0 = אל +z)
    b.box("metal", Vector3(px, 2.8, pz), Vector3(0.16, 5.6, 0.16), Color("3c3f44"), 0.0, true)
    var sx := -1.0 if face_h == 3 else 1.0
    var sz := -1.0 if face_v == 1 else 1.0
    b.box("metal", Vector3(px + sx * 0.32, 4.7, pz), Vector3(0.34, 1.1, 0.34), Color("1d1f22"))
    b.box("metal", Vector3(px, 4.7, pz + sz * 0.32), Vector3(0.34, 1.1, 0.34), Color("1d1f22"))
    var hx := px + sx * 0.5
    var vz := pz + sz * 0.5
    b.wall_quad("sigH_r", Vector3(hx, 5.0, pz), 0.24, 0.24, face_h, Color.WHITE)
    b.wall_quad("sigH_y", Vector3(hx, 4.7, pz), 0.24, 0.24, face_h, Color.WHITE)
    b.wall_quad("sigH_g", Vector3(hx, 4.4, pz), 0.24, 0.24, face_h, Color.WHITE)
    b.wall_quad("sigV_r", Vector3(px, 5.0, vz), 0.24, 0.24, face_v, Color.WHITE)
    b.wall_quad("sigV_y", Vector3(px, 4.7, vz), 0.24, 0.24, face_v, Color.WHITE)
    b.wall_quad("sigV_g", Vector3(px, 4.4, vz), 0.24, 0.24, face_v, Color.WHITE)


func _bus_stop(b: MeshBatch, blk: Node3D, x: float, z: float) -> void:
    b.box("glass_dark", Vector3(x, 1.2, z - 0.7), Vector3(4.0, 2.2, 0.06), Color(0.45, 0.62, 0.7))
    b.box("metal", Vector3(x, 2.4, z), Vector3(4.4, 0.12, 1.7), Color("2f5d8a"))
    b.box("metal", Vector3(x - 2.0, 1.2, z + 0.7), Vector3(0.08, 2.4, 0.08), Color("5a5f66"), 0.0, true)
    b.box("metal", Vector3(x + 2.0, 1.2, z + 0.7), Vector3(0.08, 2.4, 0.08), Color("5a5f66"), 0.0, true)
    b.box("solid", Vector3(x, 0.45, z - 0.35), Vector3(2.4, 0.08, 0.45), Color("8a5a33"))
    b.box("sign", Vector3(x + 2.6, 2.6, z + 0.7), Vector3(0.5, 0.5, 0.06), Color("1d5fa8"))
    b.box("metal", Vector3(x + 2.6, 1.3, z + 0.7), Vector3(0.07, 2.6, 0.07), Color("8d949b"), 0.0, true)
    _label(blk, "תחנה · קו %d" % (1 + _rng.randi() % 99), Vector3(x, 2.0, z + 0.9), 28, Color.WHITE, 0, 45.0)


# ---------- מגורים / מסחר / משרדים ----------
func _build_home(b: MeshBatch, blk: Node3D, g: Dictionary) -> void:
    var bi: int = g.bi
    var bj: int = g.bj
    var zone := _zone(bi, bj)
    var main_st := _on_main(bi, bj)
    var roll := _rng.randi() % 100
    var style := "lowrise"
    match zone:
        "beach":
            style = "hotel" if roll < 55 else ("midrise" if roll < 85 else "lowrise")
        "business":
            style = "office" if roll < 55 else ("tower" if roll < 70 else ("mixed" if roll < 85 else "stepped"))
        "industrial":
            style = "warehouse" if roll < 55 else ("office_low" if roll < 75 else "lowrise")
        "center":
            style = "bauhaus" if roll < 38 else ("mixed" if roll < 62 else ("midrise" if roll < 82 else "lowrise"))
        _:
            if main_st and roll < 35:
                style = "mixed"
            elif roll < 25:
                style = "lowrise"
            elif roll < 52:
                style = "midrise"
            elif roll < 64:
                style = "slab"
            elif roll < 74:
                style = "tower"
            elif roll < 86:
                style = "compound"
            else:
                style = "stepped"
    match style:
        "lowrise":
            _b_lowrise(b, blk, g)
        "midrise":
            _b_midrise(b, blk, g)
        "tower":
            _b_tower(b, blk, g, false)
        "hotel":
            _b_tower(b, blk, g, true)
        "office":
            _b_office(b, blk, g)
        "office_low":
            _b_office_low(b, blk, g)
        "bauhaus":
            _b_bauhaus(b, blk, g)
        "mixed":
            _b_mixed(b, blk, g)
        "slab":
            _b_slab(b, blk, g)
        "stepped":
            _b_stepped(b, blk, g)
        "compound":
            _b_compound(b, blk, g)
        "warehouse":
            _b_warehouse(b, blk, g)


## מסה בסיסית של בניין: גוף, פסי קומות, חלונות בארבע חזיתות. מחזיר את גובה הגג.
func _mass(b: MeshBatch, cx: float, zf: float, bw: float, bd: float, floors: int, fh: float, y0: float, wall: Color, o: Dictionary = {}) -> float:
    var cz := zf - bd * 0.5
    var h := floors * fh
    var key := "glass_dark" if o.get("glass", false) else "solid"
    b.box(key, Vector3(cx, y0 + h * 0.5, cz), Vector3(bw, h, bd), wall, 0.0, true)
    if o.get("bands", true):
        var bc := wall.darkened(0.08)
        for f in range(1, floors):
            b.box("solid", Vector3(cx, y0 + f * fh, cz), Vector3(bw + 0.14, 0.18, bd + 0.14), bc)
    var ww: float = o.get("ww", 1.3)
    var wh: float = o.get("wh", 1.5)
    var gap: float = o.get("gap", 1.6)
    var ff: int = o.get("ff", 0)
    var sh: bool = o.get("shutters", false)
    _windows(b, 0, Vector3(cx, 0, zf), bw, floors, fh, y0, ww, wh, gap, ff, sh)
    _windows(b, 1, Vector3(cx, 0, zf - bd), bw, floors, fh, y0, ww, wh, gap, 0, sh)
    _windows(b, 2, Vector3(cx + bw * 0.5, 0, cz), bd, floors, fh, y0, ww, wh, gap, 0, sh)
    _windows(b, 3, Vector3(cx - bw * 0.5, 0, cz), bd, floors, fh, y0, ww, wh, gap, 0, sh)
    return y0 + h


func _front_yard(b: MeshBatch, blk: Node3D, g: Dictionary, fence := true) -> void:
    var zf: float = g.zf
    var dx: float = g.door.x
    var x0: float = g.x0
    var w: float = g.w
    var avoid := [[dx - 5.0, dx + 5.0], [bi_x(g, 14.0) - 2.0, bi_x(g, 14.0) + 2.0], [bi_x(g, 50.0) - 2.0, bi_x(g, 50.0) + 2.0], [bi_x(g, 21.0), bi_x(g, 26.0)]]
    _scatter_row(b, x0 + 2.0, x0 + w - 2.0, zf + 2.4, 11.0, avoid, 0.8, 0.85)
    if _rng.randf() < 0.5:
        _scatter_row(b, x0 + 2.0, x0 + w - 2.0, g.z0 + 2.5, 12.0, [], 1.5, 0.7)
    if fence and _rng.randf() < 0.4:
        _fence(b, x0 + 1.0, zf + 3.2, x0 + w - 1.0, zf + 3.2, 0.5, Color("b8b2a4"), [[dx - 3.0, dx + 3.0], [bi_x(g, 21.0), bi_x(g, 26.0)]])


func bi_x(g: Dictionary, off: float) -> float:
    return float(g.bi) * S + off


func _b_lowrise(b: MeshBatch, blk: Node3D, g: Dictionary) -> void:
    var floors := _rng.randi_range(3, 5)
    var bw := _rng.randf_range(24.0, 38.0)
    var bd := _rng.randf_range(16.0, 24.0)
    var cx: float = g.cx + _rng.randf_range(-3.0, 3.0)
    var wall := _pick(PALETTE) if _rng.randf() < 0.75 else _pick(STONE)
    var top := _mass(b, cx, g.zf, bw, bd, floors, 3.2, 0.0, wall, {"shutters": _rng.randf() < 0.5})
    _balconies(b, cx, g.zf, bw, floors, 3.2, 0.0, 1 if _rng.randf() < 0.5 else 2)
    _roof(b, cx, g.zf - bd * 0.5, bw, bd, top)
    _entrance(b, blk, g, g.p)
    _front_yard(b, blk, g)
    _scatter_area(b, g.x0 + 2.0, g.z0 + 2.0, g.x0 + g.w - 2.0, g.zf - bd - 2.0, 4)


func _b_midrise(b: MeshBatch, blk: Node3D, g: Dictionary) -> void:
    var floors := _rng.randi_range(6, 9)
    var bw := _rng.randf_range(26.0, 38.0)
    var bd := _rng.randf_range(16.0, 22.0)
    var cx: float = g.cx + _rng.randf_range(-3.0, 3.0)
    var wall := _pick(PALETTE)
    var top := _mass(b, cx, g.zf, bw, bd, floors, 3.2, 0.0, wall, {"ww": 1.5, "wh": 1.7, "gap": 1.5})
    _balconies(b, cx, g.zf, bw, floors, 3.2, 0.0, 1, _rng.randf() < 0.4)
    # חיפוי אבן בקומת הקרקע
    b.box("solid", Vector3(cx, 1.3, g.zf + 0.06), Vector3(bw + 0.1, 2.6, 0.14), _pick(STONE))
    _roof(b, cx, g.zf - bd * 0.5, bw, bd, top)
    _entrance(b, blk, g, g.p, true)
    _front_yard(b, blk, g)
    _scatter_area(b, g.x0 + 2.0, g.z0 + 2.0, g.x0 + g.w - 2.0, g.zf - bd - 2.0, 5)


func _b_tower(b: MeshBatch, blk: Node3D, g: Dictionary, hotel: bool) -> void:
    var floors := _rng.randi_range(14, 24) if not hotel else _rng.randi_range(10, 18)
    var bw := _rng.randf_range(18.0, 26.0) if not hotel else _rng.randf_range(30.0, 40.0)
    var bd := _rng.randf_range(18.0, 24.0)
    var cx: float = g.cx
    var wall := _pick([Color("e9e4d6"), Color("d7dde0"), Color("cfd6dc"), Color("f4f1ea")])
    var top := _mass(b, cx, g.zf, bw, bd, floors, 3.1, 0.0, wall, {"ww": 1.6, "wh": 1.8, "gap": 1.4})
    # פסי מרפסות אנכיים
    for k in range(3):
        var vx := cx - bw * 0.5 + bw * (0.2 + 0.3 * k)
        b.box("solid", Vector3(vx, top * 0.5, g.zf + 0.1), Vector3(0.5, top, 0.3), wall.darkened(0.12))
    _balconies(b, cx, g.zf, bw, floors, 3.1, 0.0, 1, true)
    # בסיס רחב (פודיום)
    b.box("solid", Vector3(cx, 2.0, g.zf - bd * 0.5 + 1.0), Vector3(bw + 4.0, 4.0, bd + 2.0), _pick(STONE), 0.0, true)
    _roof(b, cx, g.zf - bd * 0.5, bw, bd, top)
    _entrance(b, blk, g, g.p, true)
    _front_yard(b, blk, g)
    if hotel:
        _label(blk, "מלון " + street_name_h(int(g.bj) + 1), Vector3(g.door.x, 6.5, g.zf + 1.9), 70, Color("ffd600"), 0, 120.0)
    _scatter_area(b, g.x0 + 2.0, g.z0 + 2.0, g.x0 + g.w - 2.0, g.zf - bd - 2.0, 4)


func _b_office(b: MeshBatch, blk: Node3D, g: Dictionary) -> void:
    var floors := _rng.randi_range(9, 22)
    var bw := _rng.randf_range(28.0, 38.0)
    var bd := _rng.randf_range(22.0, 30.0)
    var cx: float = g.cx
    var glass := Color(0.2, 0.32, 0.42).lerp(Color(0.3, 0.45, 0.55), _rng.randf())
    var podium_h := 2
    # פודיום עם לובי זכוכית
    var ptop := _mass(b, cx, g.zf, bw + 6.0, bd + 4.0, podium_h, 4.0, 0.0, Color("c9cdd1"), {"ww": 3.4, "wh": 2.6, "gap": 0.6, "glass": false})
    # מגדל עם קירות מסך
    var ztow: float = g.zf - 3.0
    var top := _mass(b, cx, ztow, bw - 4.0, bd - 6.0, floors, 3.6, ptop, glass, {"glass": true, "ww": 3.0, "wh": 2.4, "gap": 0.5, "bands": false})
    if floors > 14 and _rng.randf() < 0.6:
        top = _mass(b, cx, ztow - 3.0, bw - 12.0, bd - 12.0, 3, 3.6, top, glass.darkened(0.1), {"glass": true, "ww": 3.0, "wh": 2.4, "gap": 0.5, "bands": false})
    _roof(b, cx, ztow - (bd - 6.0) * 0.5, bw - 4.0, bd - 6.0, top)
    _entrance(b, blk, g, g.p, true)
    b.box("sign", Vector3(g.door.x, 4.6, g.zf + 0.1), Vector3(5.0, 0.6, 0.1), Color("1d5fa8"))
    _label(blk, "משרדי " + street_name_h(int(g.bj) + 1).replace("רחוב ", ""), Vector3(g.door.x, 4.6, g.zf + 0.2), 36, Color.WHITE, 0, 80.0)
    _front_yard(b, blk, g, false)
    _scatter_area(b, g.x0 + 2.0, g.z0 + 2.0, g.x0 + g.w - 2.0, g.zf - bd - 4.0, 3)


func _b_office_low(b: MeshBatch, blk: Node3D, g: Dictionary) -> void:
    var floors := _rng.randi_range(3, 5)
    var bw := _rng.randf_range(34.0, 44.0)
    var bd := _rng.randf_range(18.0, 24.0)
    var cx: float = g.cx
    var top := _mass(b, cx, g.zf - 12.0, bw, bd, floors, 3.8, 0.0, Color("c9ced3"), {"ww": 3.0, "wh": 2.2, "gap": 0.7})
    _roof(b, cx, g.zf - 12.0 - bd * 0.5, bw, bd, top)
    g["zf_entry"] = g.zf
    _entrance(b, blk, g, g.p, true)
    _parking_lot(b, g, g.zf - 11.0, g.zf - 1.0)
    _front_yard(b, blk, g, false)


func _b_bauhaus(b: MeshBatch, blk: Node3D, g: Dictionary) -> void:
    var floors := _rng.randi_range(4, 5)
    var bw := _rng.randf_range(28.0, 36.0)
    var bd := _rng.randf_range(16.0, 20.0)
    var cx: float = g.cx
    var wall := Color("f1ede4").lerp(Color("e6e0d2"), _rng.randf())
    var top := _mass(b, cx, g.zf, bw, bd, floors, 3.2, 0.0, wall, {"ww": 1.3, "wh": 1.5, "gap": 1.7, "shutters": true, "ff": 1})
    # מרפסות רציפות מעוגלות (פסים אופקיים בולטים)
    for f in range(1, floors):
        b.box("solid", Vector3(cx, f * 3.2 + 0.1, g.zf + 0.55), Vector3(bw * 0.7, 0.2, 1.1), Color("ffffff"))
        b.box("metal", Vector3(cx, f * 3.2 + 0.7, g.zf + 1.08), Vector3(bw * 0.7, 0.9, 0.05), Color("d9d9d9"))
    # פינה מעוגלת (גליל) בצד אחד
    var side := 1.0 if _rng.randf() < 0.5 else -1.0
    var cyx := cx + side * (bw * 0.5 - 1.0)
    b.cyl("solid", Vector3(cyx, floors * 1.6, g.zf - 1.0), 3.4, floors * 3.2, wall.lightened(0.05), false)
    for f in range(floors):
        b.cyl("glass_dark", Vector3(cyx, f * 3.2 + 1.8, g.zf - 1.0), 3.45, 1.4, Color(0.25, 0.33, 0.4), false)
    _shopfronts(b, blk, g, cx, bw, 3.2, 1)
    _roof(b, cx, g.zf - bd * 0.5, bw, bd, top)
    _entrance(b, blk, g, g.p)
    _front_yard(b, blk, g, false)


func _b_mixed(b: MeshBatch, blk: Node3D, g: Dictionary) -> void:
    var floors := _rng.randi_range(4, 8)
    var bw := _rng.randf_range(32.0, 42.0)
    var bd := _rng.randf_range(16.0, 22.0)
    var cx: float = g.cx
    var wall := _pick(PALETTE) if _rng.randf() < 0.7 else _pick(STONE)
    var top := _mass(b, cx, g.zf, bw, bd, floors, 3.4, 0.0, wall, {"ww": 1.4, "wh": 1.6, "gap": 1.5, "ff": 1, "shutters": _rng.randf() < 0.4})
    _balconies(b, cx, g.zf, bw, floors, 3.4, 0.0, 2)
    _shopfronts(b, blk, g, cx, bw, 3.4, 1)
    _roof(b, cx, g.zf - bd * 0.5, bw, bd, top)
    _entrance(b, blk, g, g.p)
    _front_yard(b, blk, g, false)


func _b_slab(b: MeshBatch, blk: Node3D, g: Dictionary) -> void:
    var floors := 5
    var bw := _rng.randf_range(42.0, 48.0)
    var bd := 12.0
    var cx: float = g.cx
    var wall := _pick([Color("d9d3c4"), Color("cfc7b6"), Color("e0dacb")])
    var top := _mass(b, cx, g.zf, bw, bd, floors, 3.0, 0.0, wall, {"ww": 1.2, "wh": 1.3, "gap": 2.0, "shutters": true})
    # מסדרון גישה / מרפסות פתוחות לכל אורך החזית
    for f in range(1, floors):
        b.box("solid", Vector3(cx, f * 3.0 + 0.08, g.zf + 0.9), Vector3(bw, 0.16, 1.8), Color("cfc9bb"))
        b.box("solid", Vector3(cx, f * 3.0 + 0.65, g.zf + 1.75), Vector3(bw, 1.0, 0.1), Color("b9b3a6"))
    for sx in [-0.3, 0.3]:
        b.box("solid", Vector3(cx + bw * sx, 7.5, g.zf + 0.4), Vector3(4.0, 15.0, 3.0), wall.darkened(0.06), 0.0, true)
    _roof(b, cx, g.zf - bd * 0.5, bw, bd, top)
    _entrance(b, blk, g, g.p)
    _front_yard(b, blk, g)
    # מגרש משחקים קטן מאחור
    _playground(b, g.cx + _rng.randf_range(-8.0, 8.0), g.z0 + 10.0)
    _scatter_area(b, g.x0 + 2.0, g.z0 + 2.0, g.x0 + g.w - 2.0, g.zf - bd - 2.0, 6)


func _b_stepped(b: MeshBatch, blk: Node3D, g: Dictionary) -> void:
    var tiers := _rng.randi_range(3, 4)
    var bw := _rng.randf_range(34.0, 40.0)
    var bd := _rng.randf_range(22.0, 28.0)
    var cx: float = g.cx
    var wall := _pick(PALETTE)
    var y := 0.0
    var zf: float = g.zf
    var top := 0.0
    for t in range(tiers):
        var floors := _rng.randi_range(2, 3)
        var tbw := bw - t * 5.0
        var tbd := bd - t * 5.0
        top = _mass(b, cx, zf, tbw, tbd, floors, 3.2, y, wall.darkened(0.03 * t), {"ww": 1.6, "wh": 1.7, "gap": 1.4})
        # מרפסת גג מדורגת עם עציצים
        b.box("foliage", Vector3(cx, top + 0.3, zf - 1.2), Vector3(tbw - 3.0, 0.6, 1.0), Color("3f7d3a"))
        b.box("solid", Vector3(cx, top + 0.5, zf), Vector3(tbw, 1.0, 0.15), Color("d8d2c4"))
        y = top
        zf -= 5.0
    _roof(b, cx, zf, bw - tiers * 5.0, bd - tiers * 5.0, top)
    _entrance(b, blk, g, g.p, true)
    _front_yard(b, blk, g)


func _b_compound(b: MeshBatch, blk: Node3D, g: Dictionary) -> void:
    ## מתחם מגורים: 2-3 בניינים סביב חצר משותפת עם גדר, שער, בקתת שומר, בריכה וגן משחקים
    var x0: float = g.x0
    var z0: float = g.z0
    var w: float = g.w
    var wall := _pick(PALETTE)
    var floors_a := _rng.randi_range(6, 10)
    var floors_b := _rng.randi_range(5, 8)
    var top := _mass(b, x0 + 11.0, z0 + 24.0, 18.0, 16.0, floors_a, 3.1, 0.0, wall, {"ww": 1.5, "wh": 1.7, "gap": 1.4})
    _balconies(b, x0 + 11.0, z0 + 24.0, 18.0, floors_a, 3.1, 0.0, 1)
    _roof(b, x0 + 11.0, z0 + 16.0, 18.0, 16.0, top)
    var top2 := _mass(b, x0 + w - 11.0, z0 + 24.0, 18.0, 16.0, floors_b, 3.1, 0.0, wall.darkened(0.04), {"ww": 1.5, "wh": 1.7, "gap": 1.4})
    _balconies(b, x0 + w - 11.0, z0 + 24.0, 18.0, floors_b, 3.1, 0.0, 1)
    _roof(b, x0 + w - 11.0, z0 + 16.0, 18.0, 16.0, top2)
    var zf: float = g.zf
    var top3 := _mass(b, g.cx, zf, 20.0, 10.0, 4, 3.1, 0.0, wall.lightened(0.03), {"ww": 1.4, "wh": 1.5, "gap": 1.6, "shutters": true})
    _roof(b, g.cx, zf - 5.0, 20.0, 10.0, top3)
    _entrance(b, blk, g, g.p)
    # חצר משותפת: בריכה וגן משחקים
    b.box("water", Vector3(g.cx, 0.1, z0 + 20.0), Vector3(10.0, 0.2, 5.0), Color("4fb3d9"))
    b.box("solid", Vector3(g.cx, 0.12, z0 + 20.0), Vector3(11.0, 0.14, 6.0), Color("e8e4d8"))
    _playground(b, g.cx, z0 + 31.0)
    _fence(b, x0 + 0.5, z0 + w - 1.5, x0 + w - 0.5, z0 + w - 1.5, 1.6, Color("4a5560"), [[g.door.x - 3.0, g.door.x + 3.0]])
    b.box("solid", Vector3(g.door.x + 5.0, 1.4, z0 + w - 3.0), Vector3(2.4, 2.8, 2.4), Color("c9c3b4"), 0.0, true)
    _scatter_area(b, x0 + 2.0, z0 + 2.0, x0 + w - 2.0, z0 + 14.0, 6)
    _scatter_area(b, x0 + 2.0, z0 + 30.0, x0 + w - 2.0, z0 + w - 4.0, 5, [[g.door.x - 5.0, z0 + 28.0, g.door.x + 5.0, z0 + w]])


func _b_warehouse(b: MeshBatch, blk: Node3D, g: Dictionary) -> void:
    var bw := _rng.randf_range(34.0, 44.0)
    var bd := _rng.randf_range(20.0, 26.0)
    var h := _rng.randf_range(8.0, 11.0)
    var zf: float = g.zf - 10.0
    var cx: float = g.cx
    var col := _pick([Color("b9c0c6"), Color("a9b2b9"), Color("c4c0b4")])
    b.box("solid", Vector3(cx, h * 0.5, zf - bd * 0.5), Vector3(bw, h, bd), col, 0.0, true)
    b.box("solid", Vector3(cx, h + 0.3, zf - bd * 0.5), Vector3(bw + 0.4, 0.6, bd + 0.4), col.darkened(0.12))
    for k in range(3):
        var dx := cx - bw * 0.3 + k * bw * 0.3
        b.box("metal", Vector3(dx, 2.2, zf + 0.06), Vector3(4.0, 4.4, 0.1), _pick([Color("8b2a2a"), Color("2a5b8b"), Color("5a5f66")]))
    _windows(b, 0, Vector3(cx, 0, zf), bw, 1, 6.0, 5.5, 1.8, 1.0, 1.4)
    for k in range(2):
        b.box("solid", Vector3(cx - 8.0 + k * 16.0, h + 1.0, zf - bd * 0.5), Vector3(2.0, 2.0, 2.0), Color("9aa0a6"))
    # משטח העמסה, מכולות ומשאית
    b.flat("paint", Vector3(cx, 0.035, zf + 5.5), bw, 9.0, Color("8d8f92"))
    for k in range(3):
        b.box("solid", Vector3(g.x0 + 5.0 + k * 3.0, 1.3, g.z0 + 4.0), Vector3(2.4, 2.6, 6.0), _pick([Color("c0392b"), Color("2980b9"), Color("27ae60"), Color("d68910")]), 0.0, true)
    Traffic.add_car(b, 3, Color("f2f2f2"), Vector3(cx + bw * 0.3, 0.0, zf + 6.0), PI * 0.5, true)
    _entrance(b, blk, g, g.p)
    b.box("solid", Vector3(g.door.x, 0.9, zf + 3.0), Vector3(3.0, 1.8, 1.0), Color("a8a49b"))
    _fence(b, g.x0 + 0.5, g.z0 + g.w - 1.5, g.x0 + g.w - 0.5, g.z0 + g.w - 1.5, 2.0, Color("6d737a"), [[g.door.x - 4.0, g.door.x + 4.0]])


# ---------- חזיתות חנויות ----------
## חזית מסחרית לאורך הקומה הקרקעית: חלונות ראווה, דלתות, סוככים, שלטים (בעברית) בלי לחסום את הכניסה הראשית.
func _shopfronts(b: MeshBatch, blk: Node3D, g: Dictionary, cx: float, bw: float, fh: float, _n: int) -> void:
    var zf: float = g.zf
    var dx: float = g.door.x
    var left_a := cx - bw * 0.5
    var right_b := cx + bw * 0.5
    var regions: Array = []
    if dx - 2.4 > left_a + 3.0:
        regions.append([left_a, dx - 2.4])
    if dx + 2.4 < right_b - 3.0:
        regions.append([dx + 2.4, right_b])
    for r in regions:
        var a: float = r[0]
        var e: float = r[1]
        var n := maxi(1, int(round((e - a) / 7.5)))
        var sw := (e - a) / n
        for k in range(n):
            var sc := a + sw * (k + 0.5)
            b.box("shop_glass", Vector3(sc, 1.25, zf + 0.07), Vector3(sw - 1.0, 2.3, 0.1), Color(0.35, 0.5, 0.58))
            b.box("metal", Vector3(sc - sw * 0.5 + 0.35, 1.3, zf + 0.1), Vector3(0.12, 2.6, 0.14), Color("3c3f44"))
            b.box("metal", Vector3(sc, 0.12, zf + 0.1), Vector3(sw - 0.6, 0.24, 0.14), Color("3c3f44"))
            b.box("solid", Vector3(sc, fh - 0.6, zf + 0.75), Vector3(sw - 0.5, 0.08, 1.5), _pick(AWNING), 0.0, false, Vector3(0.28, 0, 0))
            b.box("sign", Vector3(sc, fh - 0.15, zf + 0.12), Vector3(sw - 0.8, 0.5, 0.1), _pick(SIGN_COLS))
            if _rng.randf() < 0.6:
                _label(blk, SHOP_NAMES[_rng.randi() % SHOP_NAMES.size()], Vector3(sc, fh - 0.15, zf + 0.2), 34, Color.WHITE, 0, 60.0)
            if _rng.randf() < 0.5:
                b.box("solid", Vector3(sc + sw * 0.3, 0.55, zf + 0.5), Vector3(0.9, 1.1, 0.7), _pick([Color("8a5a33"), Color("c9b88a"), Color("7d8a6a")]))
    # תחתית אבן לקומת הקרקע בצדי הכניסה
    b.box("solid", Vector3(dx, 0.5, zf + 0.04), Vector3(5.0, 1.0, 0.1), Color("8d8a82"))


# ---------- חנייה וגן משחקים ----------
func _parking_lot(b: MeshBatch, g: Dictionary, z_a: float, z_b: float) -> void:
    ## שורות חנייה משני צדי פרוזדור פנוי ברוחב 8 מ' סביב door.x. z_a..z_b אזור החנייה.
    var dx: float = g.door.x
    var x0: float = g.x0
    var w: float = g.w
    b.flat("paint", Vector3(g.cx, 0.035, (z_a + z_b) * 0.5), w - 2.0, z_b - z_a, Color("6f7378"))
    var rows := 1 if (z_b - z_a) < 9.0 else 2
    for side in [-1.0, 1.0]:
        var xa: float = x0 + 3.0 if side < 0.0 else dx + 4.5
        var xb: float = dx - 4.5 if side < 0.0 else x0 + w - 3.0
        var x := xa
        while x + 2.6 <= xb:
            for r in range(rows):
                var zc: float = z_a + 3.0 + r * 6.0
                b.box("paint", Vector3(x, 0.04, zc), Vector3(0.1, 0.01, 5.0), Color("f0f0f0"))
                if _rng.randf() < 0.55:
                    var ct := 0 if _rng.randf() < 0.8 else 1
                    Traffic.add_car(b, ct, Traffic.random_color(_rng), Vector3(x + 1.3, 0.0, zc), 0.0 if r == 0 else PI, true)
            x += 2.6


func _playground(b: MeshBatch, x: float, z: float) -> void:
    b.flat("solid", Vector3(x, 0.05, z), 9.0, 6.0, Color("c9a96e"))
    # נדנדות
    for sx in [-1.5, 1.5]:
        b.box("metal", Vector3(x - 3.0 + sx * 0.0, 1.1, z + sx * 0.0), Vector3(0.1, 2.2, 0.1), Color("c0392b"))
    b.box("metal", Vector3(x - 3.0, 2.15, z), Vector3(0.1, 0.1, 3.4), Color("c0392b"))
    b.box("metal", Vector3(x - 3.0, 1.1, z - 1.7), Vector3(0.1, 2.2, 0.1), Color("c0392b"))
    b.box("metal", Vector3(x - 3.0, 1.1, z + 1.7), Vector3(0.1, 2.2, 0.1), Color("c0392b"))
    b.box("solid", Vector3(x - 3.0, 0.7, z - 0.7), Vector3(0.5, 0.06, 0.25), Color("222222"))
    b.box("solid", Vector3(x - 3.0, 0.7, z + 0.7), Vector3(0.5, 0.06, 0.25), Color("222222"))
    # מגלשה
    b.box("solid", Vector3(x + 2.0, 1.0, z), Vector3(1.2, 2.0, 1.2), Color("2980b9"), 0.0, true)
    b.box("solid", Vector3(x + 3.7, 0.9, z), Vector3(0.7, 0.06, 2.4), Color("f2c200"), 0.0, false, Vector3(0, 0, 0.55))


# ---------- מקומות מיוחדים ----------
func _sign_board(b: MeshBatch, blk: Node3D, x: float, y: float, z: float, wd: float, ht: float, col: Color, text: String, px := 60, range_end := 110.0) -> void:
    b.box("sign", Vector3(x, y, z), Vector3(wd, ht, 0.16), col)
    _label(blk, text, Vector3(x, y, z + 0.12), px, Color.WHITE, 0, range_end)


func _atm(b: MeshBatch, blk: Node3D, x: float, z: float) -> void:
    b.box("metal", Vector3(x, 1.0, z), Vector3(0.9, 2.0, 0.6), Color("37474f"), 0.0, true)
    b.wall_quad("sign", Vector3(x, 1.45, z + 0.31), 0.5, 0.35, 0, Color(0.4, 0.8, 1.0))
    b.box("sign", Vector3(x, 2.15, z), Vector3(0.9, 0.25, 0.65), Color("1d5fa8"))
    _label(blk, "כספומט", Vector3(x, 2.15, z + 0.34), 18, Color.WHITE, 0, 30.0)


func _build_restaurant(b: MeshBatch, blk: Node3D, g: Dictionary) -> void:
    var p: Dictionary = g.p
    var bw := _rng.randf_range(22.0, 30.0)
    var bd := _rng.randf_range(14.0, 18.0)
    var cx: float = g.cx
    var h := 5.0
    var wall := _pick([Color("e8dcc4"), Color("d9c9a8"), Color("c9b88a"), Color("e6e0d2")])
    b.box("solid", Vector3(cx, h * 0.5, g.zf - bd * 0.5), Vector3(bw, h, bd), wall, 0.0, true)
    b.box("solid", Vector3(cx, h + 0.3, g.zf - bd * 0.5), Vector3(bw + 0.5, 0.6, bd + 0.5), wall.darkened(0.15))
    b.box("shop_glass", Vector3(cx - bw * 0.25, 1.6, g.zf + 0.07), Vector3(bw * 0.4, 2.6, 0.1), Color(0.35, 0.5, 0.58))
    b.box("shop_glass", Vector3(cx + bw * 0.28, 1.6, g.zf + 0.07), Vector3(bw * 0.3, 2.6, 0.1), Color(0.35, 0.5, 0.58))
    b.box("solid", Vector3(cx, 3.6, g.zf + 0.9), Vector3(bw * 0.9, 0.1, 1.8), _pick(AWNING), 0.0, false, Vector3(0.22, 0, 0))
    var sc := _pick(SIGN_COLS)
    _sign_board(b, blk, g.door.x, 4.4, g.zf + 0.12, 9.0, 1.3, sc, str(p.name), 90, 120.0)
    _windows(b, 0, Vector3(cx, 0, g.zf), bw, 2, 2.6, 0.0, 1.4, 1.0, 2.0, 1)
    _windows(b, 2, Vector3(cx + bw * 0.5, 0, g.zf - bd * 0.5), bd, 2, 2.6, 0.0, 1.4, 1.0, 2.2, 0)
    _windows(b, 3, Vector3(cx - bw * 0.5, 0, g.zf - bd * 0.5), bd, 2, 2.6, 0.0, 1.4, 1.0, 2.2, 0)
    # פינת ישיבה מחוץ למסעדה: שולחנות ושמשיות (הכניסה נשארת פנויה)
    var dx: float = g.door.x
    for sx in [-9.0, -5.5, 5.5, 9.0]:
        var tx: float = dx + sx
        b.cyl("solid", Vector3(tx, 0.4, g.zf + 2.2), 0.45, 0.8, Color("3c3f44"))
        b.cyl("solid", Vector3(tx, 0.82, g.zf + 2.2), 0.55, 0.05, Color("e8e4d8"))
        b.cyl("solid", Vector3(tx, 1.2, g.zf + 2.2), 0.04, 2.4, Color("3c3f44"))
        b.cone("solid", Vector3(tx, 2.45, g.zf + 2.2), 1.2, 0.5, _pick(AWNING))
    b.box("metal", Vector3(cx + bw * 0.3, h + 1.0, g.zf - bd * 0.7), Vector3(2.0, 2.0, 2.0), Color("9aa0a6"))
    _roof(b, cx, g.zf - bd * 0.5, bw, bd, h)
    _entrance(b, blk, g, p, true)
    var avoid := [[dx - 12.0, dx + 12.0]]
    _scatter_row(b, g.x0 + 2.0, g.x0 + g.w - 2.0, g.zf + 2.6, 11.0, avoid, 0.6, 0.8)
    _scatter_area(b, g.x0 + 2.0, g.z0 + 2.0, g.x0 + g.w - 2.0, g.zf - bd - 2.0, 4)


func _build_bank(b: MeshBatch, blk: Node3D, g: Dictionary) -> void:
    var p: Dictionary = g.p
    var cx: float = g.cx
    var bw := 30.0
    var bd := 22.0
    var top := _mass(b, cx, g.zf, bw, bd, 4, 3.8, 0.0, Color("d5dde6"), {"glass": false, "ww": 2.8, "wh": 2.2, "gap": 1.2, "ff": 1})
    b.box("glass_dark", Vector3(cx, 2.2, g.zf + 0.1), Vector3(bw - 6.0, 4.0, 0.2), Color(0.25, 0.38, 0.5))
    b.box("solid", Vector3(cx, 4.4, g.zf + 1.5), Vector3(bw - 4.0, 0.3, 3.0), Color("8d949b"))
    for sx in [-1.0, 1.0]:
        b.box("solid", Vector3(cx + sx * (bw * 0.5 - 3.0), 2.2, g.zf + 2.8), Vector3(0.6, 4.4, 0.6), Color("e8e8e8"), 0.0, true)
    _sign_board(b, blk, g.door.x, 5.4, g.zf + 0.12, 10.0, 1.4, Color("1d4f91"), str(p.name), 90, 120.0)
    _atm(b, blk, g.door.x + 5.5, g.zf + 0.6)
    _atm(b, blk, g.door.x - 5.5, g.zf + 0.6)
    _roof(b, cx, g.zf - bd * 0.5, bw, bd, top)
    _entrance(b, blk, g, p, true)
    var dx: float = g.door.x
    _scatter_row(b, g.x0 + 2.0, g.x0 + g.w - 2.0, g.zf + 2.6, 12.0, [[dx - 9.0, dx + 9.0]], 0.5, 0.8)
    _scatter_area(b, g.x0 + 2.0, g.z0 + 2.0, g.x0 + g.w - 2.0, g.zf - bd - 2.0, 4)


func _build_supermarket(b: MeshBatch, blk: Node3D, g: Dictionary) -> void:
    var p: Dictionary = g.p
    var cx: float = g.cx
    var zf: float = g.z0 + 33.0
    var bw := 38.0
    var bd := 24.0
    var h := 6.5
    var col := _pick([Color("f2efe6"), Color("e8e4d8"), Color("dfe6e2")])
    b.box("solid", Vector3(cx, h * 0.5, zf - bd * 0.5), Vector3(bw, h, bd), col, 0.0, true)
    b.box("solid", Vector3(cx, h + 0.3, zf - bd * 0.5), Vector3(bw + 0.4, 0.6, bd + 0.4), col.darkened(0.1))
    b.box("shop_glass", Vector3(cx, 1.8, zf + 0.07), Vector3(bw - 4.0, 3.2, 0.12), Color(0.35, 0.5, 0.58))
    b.box("solid", Vector3(cx, 4.0, zf + 1.2), Vector3(bw - 2.0, 0.2, 2.4), Color("2f5d8a"))
    var sc := _pick(SIGN_COLS)
    _sign_board(b, blk, cx, 5.3, zf + 0.14, 18.0, 2.0, sc, str(p.name), 110, 160.0)
    b.box("shop_glass", Vector3(g.door.x, 1.4, zf + 0.14), Vector3(5.0, 2.8, 0.1), Color(0.5, 0.7, 0.8))
    _atm(b, blk, g.door.x + 6.0, zf + 0.6)
    # עגלות קניות
    for k in range(4):
        b.box("metal", Vector3(g.door.x - 7.0 - k * 0.6, 0.55, zf + 1.2), Vector3(0.5, 0.7, 0.9), Color("9aa0a6"))
    # רציף פריקה מאחור + עצים
    b.box("solid", Vector3(cx + 10.0, 1.1, g.z0 + 7.0), Vector3(8.0, 2.2, 3.0), Color("8d8a82"))
    _parking_lot(b, g, g.z0 + 35.5, g.z0 + g.w - 1.5)
    _scatter_row(b, g.x0 + 2.0, g.x0 + g.w - 2.0, g.z0 + 3.0, 10.0, [], 1.0, 0.8)
    for sx in [-1.0, 1.0]:
        _lamp(b, g.door.x + sx * 17.0, g.z0 + 38.0, 0.0, 1.0)
    _label(blk, "פתוח 07:00-23:00", Vector3(g.door.x, 3.0, zf + 0.2), 22, Color("a0ffb0"), 0, 40.0)


func _build_gas(b: MeshBatch, blk: Node3D, g: Dictionary) -> void:
    var p: Dictionary = g.p
    var cx: float = g.cx
    var z0: float = g.z0
    var zs := z0 + 33.0
    # מבנה שירות
    b.box("solid", Vector3(cx, 2.2, zs - 6.0), Vector3(18.0, 4.4, 12.0), Color("f2efe6"), 0.0, true)
    b.box("solid", Vector3(cx, 4.55, zs - 6.0), Vector3(18.6, 0.3, 12.6), Color("c0392b"))
    b.box("shop_glass", Vector3(cx, 1.5, zs + 0.07), Vector3(12.0, 2.6, 0.1), Color(0.35, 0.5, 0.58))
    _label(blk, "מינימרקט 24 שעות", Vector3(cx, 3.6, zs + 0.2), 36, Color.WHITE, 0, 70.0)
    _atm(b, blk, cx + 7.5, zs + 0.6)
    # סככה עם משאבות
    var zc := z0 + 42.0
    for sx in [-12.0, 12.0]:
        for sz in [-4.0, 4.0]:
            b.box("metal", Vector3(cx + sx, 2.7, zc + sz), Vector3(0.5, 5.4, 0.5), Color("c9ced3"), 0.0, true)
    b.box("solid", Vector3(cx, 5.7, zc), Vector3(27.0, 0.6, 11.0), Color("f2efe6"))
    b.box("sign", Vector3(cx, 5.7, zc + 5.55), Vector3(27.0, 0.5, 0.1), Color("c0392b"))
    b.box("lamp", Vector3(cx, 5.35, zc), Vector3(24.0, 0.08, 8.0), Color("fff4d8"))
    for sx in [-7.0, 7.0]:
        b.box("solid", Vector3(cx + sx, 0.1, zc), Vector3(1.4, 0.2, 8.0), Color("8d949b"), 0.0, true)
        for sz in [-2.0, 2.0]:
            b.box("metal", Vector3(cx + sx, 0.95, zc + sz), Vector3(0.6, 1.5, 0.45), Color("d9dde0"), 0.0, true)
            b.wall_quad("sign", Vector3(cx + sx, 1.4, zc + sz + 0.24), 0.4, 0.3, 0, Color(0.5, 1.0, 0.6))
            b.box("metal", Vector3(cx + sx + 0.35, 1.0, zc + sz), Vector3(0.1, 0.1, 0.5), Color("111111"))
    # עמוד מחירים
    b.box("metal", Vector3(g.x0 + 5.0, 4.5, g.z0 + g.w - 3.0), Vector3(0.4, 9.0, 0.4), Color("5a5f66"), 0.0, true)
    _sign_board(b, blk, g.x0 + 5.0, 8.6, g.z0 + g.w - 2.7, 3.4, 2.2, Color("c0392b"), "דלק", 70, 140.0)
    _label(blk, str(p.name), Vector3(cx, 6.6, zc + 5.7), 50, Color.WHITE, 0, 100.0)
    b.flat("paint", Vector3(cx, 0.035, z0 + 40.0), g.w - 2.0, 20.0, Color("6f7378"))
    _scatter_row(b, g.x0 + 2.0, g.x0 + g.w - 2.0, g.z0 + 3.0, 10.0, [], 1.0, 0.8)
    Traffic.add_car(b, 0, Traffic.random_color(_rng), Vector3(cx - 7.0, 0.0, zc + 9.0), 0.0, true)


func _build_school(b: MeshBatch, blk: Node3D, g: Dictionary) -> void:
    var p: Dictionary = g.p
    var x0: float = g.x0
    var z0: float = g.z0
    var w: float = g.w
    var cx: float = g.cx
    var wall := Color("ecd9a6")
    var top := _mass(b, cx, z0 + 16.0, 40.0, 12.0, 3, 3.4, 0.0, wall, {"ww": 1.6, "wh": 1.8, "gap": 1.8})
    var top2 := _mass(b, x0 + 8.0, z0 + 38.0, 10.0, 22.0, 2, 3.4, 0.0, wall.darkened(0.04), {"ww": 1.6, "wh": 1.8, "gap": 1.8})
    _roof(b, cx, z0 + 10.0, 40.0, 12.0, top)
    _roof(b, x0 + 8.0, z0 + 27.0, 10.0, 22.0, top2)
    b.box("solid", Vector3(cx - 10.0, 1.6, z0 + 16.2), Vector3(5.0, 3.2, 0.3), Color("8d949b"))
    _sign_board(b, blk, cx, 9.4, z0 + 16.1, 16.0, 1.4, Color("2f8f5b"), str(p.name), 70, 120.0)
    # חצר: מגרש כדורסל, פינות ישיבה, תורן
    b.flat("paint", Vector3(cx + 11.0, 0.035, z0 + 31.0), 16.0, 10.0, Color("b5651d"))
    b.box("paint", Vector3(cx + 11.0, 0.04, z0 + 31.0), Vector3(15.6, 0.01, 0.1), Color("f0f0f0"))
    for sx in [-1.0, 1.0]:
        b.box("metal", Vector3(cx + 11.0 + sx * 7.6, 1.6, z0 + 31.0), Vector3(0.1, 3.2, 0.1), Color("3c3f44"))
        b.box("solid", Vector3(cx + 11.0 + sx * 7.3, 3.0, z0 + 31.0), Vector3(0.05, 1.0, 1.4), Color("e8e8e8"))
    b.box("metal", Vector3(cx - 12.0, 4.0, z0 + 26.0), Vector3(0.1, 8.0, 0.1), Color("c9ced3"))
    b.box("solid", Vector3(cx - 11.2, 7.4, z0 + 26.0), Vector3(1.6, 1.0, 0.03), Color("2980b9"))
    _bench(b, cx - 6.0, z0 + 22.0, 0.0)
    _bench(b, cx - 12.0, z0 + 34.0, PI / 2.0)
    # גדר היקפית עם שער (נקודת הכניסה בגדר, פנויה)
    var gate := [[g.door.x - 3.5, g.door.x + 3.5]]
    _fence(b, x0 + 0.5, z0 + w - 1.2, x0 + w - 0.5, z0 + w - 1.2, 2.0, Color("2f5d8a"), gate)
    _fence(b, x0 + 0.5, z0 + 0.5, x0 + w - 0.5, z0 + 0.5, 2.0, Color("2f5d8a"))
    _fence(b, x0 + 0.5, z0 + 0.5, x0 + 0.5, z0 + w - 1.2, 2.0, Color("2f5d8a"))
    _fence(b, x0 + w - 0.5, z0 + 0.5, x0 + w - 0.5, z0 + w - 1.2, 2.0, Color("2f5d8a"))
    b.box("solid", Vector3(g.door.x - 3.8, 1.6, z0 + w - 1.2), Vector3(0.6, 3.2, 0.6), Color("e8e8e8"))
    b.box("solid", Vector3(g.door.x + 3.8, 1.6, z0 + w - 1.2), Vector3(0.6, 3.2, 0.6), Color("e8e8e8"))
    _scatter_area(b, x0 + 2.0, z0 + 22.0, x0 + w - 2.0, z0 + w - 4.0, 6, [[g.door.x - 6.0, z0 + 20.0, g.door.x + 6.0, z0 + w], [cx + 2.0, z0 + 24.0, cx + 21.0, z0 + 38.0]])
    _label(blk, "בית ספר", Vector3(g.door.x, 3.4, z0 + w - 1.0), 36, Color.WHITE, 0, 60.0)


func _build_park(b: MeshBatch, blk: Node3D, g: Dictionary) -> void:
    var x0: float = g.x0
    var z0: float = g.z0
    var w: float = g.w
    var cx: float = g.cx
    var cz: float = g.cz
    b.flat("foliage", Vector3(cx, 0.04, cz), w - 0.6, w - 0.6, Color("5a9a45").lerp(Color("4a8a3c"), _rng.randf()))
    # שבילים
    b.flat("paint", Vector3(cx, 0.05, cz), 3.0, w - 1.0, Color("d8cdb0"))
    b.flat("paint", Vector3(cx, 0.05, cz), w - 1.0, 3.0, Color("d8cdb0"))
    b.flat("paint", Vector3(cx, 0.052, cz), 2.6, w * 1.2, Color("d8cdb0"), PI / 4.0)
    # פינה / בריכת נוי / מתקני משחק / ספסלים
    b.cyl("water", Vector3(cx + 13.0, 0.08, cz - 12.0), 5.0, 0.16, Color("5fb7d6"))
    b.cyl("solid", Vector3(cx + 13.0, 0.1, cz - 12.0), 5.6, 0.1, Color("d0c8b4"))
    _playground(b, x0 + 11.0, z0 + 12.0)
    _bench(b, cx + 3.2, cz + 8.0, PI / 2.0)
    _bench(b, cx - 3.2, cz - 8.0, -PI / 2.0)
    _bench(b, cx + 8.0, cz + 2.2, 0.0)
    _bench(b, cx - 8.0, cz - 2.2, PI)
    _bin(b, cx + 2.6, cz + 14.0)
    _bin(b, cx - 2.6, cz - 14.0)
    _lamp(b, cx + 3.0, cz + 3.0, 1.0, 0.0)
    _lamp(b, cx - 3.0, cz - 3.0, -1.0, 0.0)
    _lamp(b, cx + 3.0, cz - 15.0, 1.0, 0.0)
    var paths := [[cx - 4.0, z0, cx + 4.0, z0 + w], [x0, cz - 4.0, x0 + w, cz + 4.0]]
    var pg: Array = paths.duplicate()
    pg.append([x0 + 2.0, z0 + 3.0, x0 + 20.0, z0 + 22.0])
    pg.append([cx + 6.0, cz - 19.0, cx + 20.0, cz - 5.0])
    _scatter_area(b, x0 + 1.5, z0 + 1.5, x0 + w - 1.5, z0 + w - 1.5, 26, pg)
    for _k in range(10):
        _shrub(b, _rng.randf_range(x0 + 2.0, x0 + w - 2.0), _rng.randf_range(z0 + 2.0, z0 + w - 2.0))
    _label(blk, str(g.p.name), Vector3(g.door.x, 3.2, z0 + w - 1.0), 40, Color("c6ffb0"), 0, 70.0)


func _build_sport(b: MeshBatch, blk: Node3D, g: Dictionary) -> void:
    var x0: float = g.x0
    var z0: float = g.z0
    var w: float = g.w
    var cx: float = g.cx
    var cz: float = g.cz
    var basket := str(g.p.name).find("כדורסל") >= 0 or (int(g.p.h) % 2 == 1 and str(g.p.name).find("כדורגל") < 0)
    b.flat("solid", Vector3(cx, 0.035, cz), w - 1.0, w - 1.0, Color("b8b4aa"))
    if not basket:
        b.flat("foliage", Vector3(cx, 0.05, cz), 40.0, 26.0, Color("3f9a3f"))
        var lc := Color("f4f4f4")
        b.box("paint", Vector3(cx, 0.06, cz), Vector3(0.14, 0.01, 26.0), lc)
        b.box("paint", Vector3(cx - 20.0, 0.06, cz), Vector3(0.14, 0.01, 26.0), lc)
        b.box("paint", Vector3(cx + 20.0, 0.06, cz), Vector3(0.14, 0.01, 26.0), lc)
        b.box("paint", Vector3(cx, 0.06, cz - 13.0), Vector3(40.0, 0.01, 0.14), lc)
        b.box("paint", Vector3(cx, 0.06, cz + 13.0), Vector3(40.0, 0.01, 0.14), lc)
        for sx in [-1.0, 1.0]:
            b.box("paint", Vector3(cx + sx * 15.0, 0.06, cz), Vector3(0.14, 0.01, 14.0), lc)
            b.box("paint", Vector3(cx + sx * 17.5, 0.06, cz - 7.0), Vector3(5.0, 0.01, 0.14), lc)
            b.box("paint", Vector3(cx + sx * 17.5, 0.06, cz + 7.0), Vector3(5.0, 0.01, 0.14), lc)
            for sz in [-1.0, 1.0]:
                b.box("metal", Vector3(cx + sx * 20.0, 1.2, cz + sz * 1.8), Vector3(0.12, 2.4, 0.12), lc)
            b.box("metal", Vector3(cx + sx * 20.0, 2.4, cz), Vector3(0.12, 0.12, 3.8), lc)
    else:
        b.flat("paint", Vector3(cx, 0.05, cz), 28.0, 15.0, Color("b5651d"))
        var lc2 := Color("f4f4f4")
        b.box("paint", Vector3(cx, 0.06, cz), Vector3(0.12, 0.01, 15.0), lc2)
        b.box("paint", Vector3(cx, 0.06, cz - 7.5), Vector3(28.0, 0.01, 0.12), lc2)
        b.box("paint", Vector3(cx, 0.06, cz + 7.5), Vector3(28.0, 0.01, 0.12), lc2)
        for sx in [-1.0, 1.0]:
            b.box("metal", Vector3(cx + sx * 14.6, 1.7, cz), Vector3(0.14, 3.4, 0.14), Color("3c3f44"))
            b.box("solid", Vector3(cx + sx * 14.2, 3.1, cz), Vector3(0.06, 1.0, 1.6), Color("f0f0f0"))
            b.cyl("metal", Vector3(cx + sx * 13.7, 2.85, cz), 0.25, 0.04, Color("e0502a"))
    # גדר, שער, פנסי הצפה
    var gate := [[g.door.x - 3.5, g.door.x + 3.5]]
    _fence(b, x0 + 0.5, z0 + w - 1.2, x0 + w - 0.5, z0 + w - 1.2, 3.0, Color("3c4a55"), gate)
    _fence(b, x0 + 0.5, z0 + 0.5, x0 + w - 0.5, z0 + 0.5, 3.0, Color("3c4a55"))
    _fence(b, x0 + 0.5, z0 + 0.5, x0 + 0.5, z0 + w - 1.2, 3.0, Color("3c4a55"))
    _fence(b, x0 + w - 0.5, z0 + 0.5, x0 + w - 0.5, z0 + w - 1.2, 3.0, Color("3c4a55"))
    for sx in [-1.0, 1.0]:
        for sz in [-1.0, 1.0]:
            var fx := cx + sx * 22.0
            var fz := cz + sz * 17.0
            b.box("metal", Vector3(fx, 6.0, fz), Vector3(0.3, 12.0, 0.3), Color("5a5f66"), 0.0, true)
            b.box("lamp", Vector3(fx, 12.2, fz), Vector3(1.6, 0.3, 0.9), Color("fff4d8"))
            b.flat("lamp_pool", Vector3(fx - sx * 6.0, 0.08, fz - sz * 5.0), 20.0, 20.0, Color.WHITE)
    _bench(b, cx - 8.0, z0 + w - 5.0, 0.0)
    _bench(b, cx + 8.0, z0 + w - 5.0, 0.0)
    _label(blk, str(g.p.name), Vector3(g.door.x, 3.6, z0 + w - 1.0), 40, Color("ffd9a0"), 0, 70.0)


func _build_construction(b: MeshBatch, blk: Node3D, g: Dictionary) -> void:
    var x0: float = g.x0
    var z0: float = g.z0
    var w: float = g.w
    var cx: float = g.cx
    b.flat("solid", Vector3(cx, 0.04, g.cz), w - 1.0, w - 1.0, Color("a89a82"))
    b.flat("paint", Vector3(cx + 4.0, 0.05, z0 + 18.0), 22.0, 16.0, Color("6b5a44"))
    # שלד בטון (עמודים ותקרות)
    for f in range(3):
        for sx in [-1.0, 1.0]:
            for sz in [-1.0, 1.0]:
                b.box("solid", Vector3(cx + 4.0 + sx * 8.0, f * 3.4 + 1.7, z0 + 16.0 + sz * 5.0), Vector3(0.6, 3.4, 0.6), Color("b8b4aa"), 0.0, f == 0)
        b.box("solid", Vector3(cx + 4.0, (f + 1) * 3.4, z0 + 16.0), Vector3(17.0, 0.3, 11.0), Color("b0aca2"))
    # פיגומים
    for k in range(9):
        b.box("metal", Vector3(cx - 4.4 + k * 2.2, 5.0, z0 + 21.5), Vector3(0.08, 10.0, 0.08), Color("c9a227"))
    for k in range(5):
        b.box("metal", Vector3(cx + 4.0, 1.0 + k * 2.0, z0 + 21.5), Vector3(19.0, 0.08, 0.08), Color("c9a227"))
        b.box("solid", Vector3(cx + 4.0, 1.0 + k * 2.0, z0 + 21.9), Vector3(19.0, 0.06, 0.6), Color("8a6a3a"))
    # מנוף צריח
    var kx := x0 + 9.0
    var kz := z0 + 30.0
    b.box("metal", Vector3(kx, 19.0, kz), Vector3(1.4, 38.0, 1.4), Color("e8b21a"), 0.0, true)
    b.box("metal", Vector3(kx + 8.0, 38.5, kz), Vector3(32.0, 1.0, 1.0), Color("e8b21a"))
    b.box("metal", Vector3(kx - 8.0, 38.5, kz), Vector3(8.0, 1.0, 1.0), Color("e8b21a"))
    b.box("solid", Vector3(kx - 11.0, 37.5, kz), Vector3(3.0, 2.5, 2.0), Color("7a7f85"))
    b.box("solid", Vector3(kx + 1.0, 36.5, kz + 1.4), Vector3(2.0, 2.4, 2.0), Color("e8e8e8"))
    b.box("metal", Vector3(kx + 18.0, 30.0, kz), Vector3(0.05, 16.0, 0.05), Color("2b2b2b"))
    b.box("solid", Vector3(kx + 18.0, 21.5, kz), Vector3(1.2, 1.0, 1.2), Color("7a7f85"))
    b.box("lamp", Vector3(kx, 39.4, kz), Vector3(0.5, 0.4, 0.5), Color("ff5533"))
    # חומרי בנייה
    for k in range(3):
        b.cone("solid", Vector3(x0 + 6.0 + k * 5.0, 1.2, z0 + 44.0 - k * 1.5), 2.2, 2.4, Color("d9c28a"))
    for k in range(3):
        b.box("solid", Vector3(x0 + w - 8.0, 1.3, z0 + 8.0 + k * 7.0), Vector3(2.4, 2.6, 6.0), _pick([Color("c0392b"), Color("2980b9"), Color("d68910")]), 0.0, true)
    b.box("solid", Vector3(cx + 12.0, 0.6, z0 + 38.0), Vector3(3.0, 1.2, 2.0), Color("c97a4a"), 0.0, true)
    b.box("solid", Vector3(cx + 16.0, 0.6, z0 + 38.0), Vector3(3.0, 1.2, 2.0), Color("c97a4a"), 0.0, true)
    b.box("metal", Vector3(x0 + 5.0, 0.2, z0 + 12.0), Vector3(6.0, 0.4, 0.5), Color("8d949b"))
    # גדר אתר עם פתח לשער
    var gate := [[g.door.x - 4.0, g.door.x + 4.0]]
    _fence(b, x0 + 0.5, z0 + w - 1.4, x0 + w - 0.5, z0 + w - 1.4, 2.4, Color("e8b21a"), gate)
    _fence(b, x0 + 0.5, z0 + 0.5, x0 + w - 0.5, z0 + 0.5, 2.4, Color("e8b21a"))
    _fence(b, x0 + 0.5, z0 + 0.5, x0 + 0.5, z0 + w - 1.4, 2.4, Color("e8b21a"))
    _fence(b, x0 + w - 0.5, z0 + 0.5, x0 + w - 0.5, z0 + w - 1.4, 2.4, Color("e8b21a"))
    for k in range(6):
        b.box("paint", Vector3(g.door.x - 3.0 + k * 1.2, 0.045, z0 + w - 3.0), Vector3(0.6, 0.01, 2.0), Color("e8b21a") if k % 2 == 0 else Color("222222"), 0.5)
    _sign_board(b, blk, g.door.x, 3.6, z0 + w - 1.3, 6.0, 1.0, Color("c0392b"), "אתר בנייה - סכנה", 40, 70.0)
    b.box("lamp", Vector3(cx, 4.0, z0 + w - 3.0), Vector3(0.6, 0.15, 0.4), Color("fff2cc"))


func _build_clinic(b: MeshBatch, blk: Node3D, g: Dictionary) -> void:
    var cx: float = g.cx
    var bw := 30.0
    var bd := 18.0
    var top := _mass(b, cx, g.zf, bw, bd, 3, 3.6, 0.0, Color("f4f6f7"), {"ww": 2.2, "wh": 1.8, "gap": 1.4})
    b.box("sign", Vector3(g.door.x, 8.8, g.zf + 0.12), Vector3(3.0, 0.9, 0.12), Color("e8f4ea"))
    b.box("sign", Vector3(g.door.x, 8.8, g.zf + 0.2), Vector3(0.9, 2.4, 0.1), Color("d62828"))
    b.box("sign", Vector3(g.door.x, 8.8, g.zf + 0.21), Vector3(2.4, 0.9, 0.1), Color("d62828"))
    _label(blk, str(g.p.name), Vector3(g.door.x, 4.3, g.zf + 0.2), 48, Color("2f8f5b"), 0, 90.0)
    b.box("solid", Vector3(cx - 11.0, 3.2, g.zf + 2.0), Vector3(7.0, 0.2, 4.0), Color("c9ced3"))
    Traffic.add_car(b, 2, Color("f6f6f6"), Vector3(cx - 11.0, 0.0, g.zf + 2.0), PI * 0.5, true)
    _roof(b, cx, g.zf - bd * 0.5, bw, bd, top)
    _entrance(b, blk, g, g.p, true)
    var dx: float = g.door.x
    _scatter_row(b, g.x0 + 2.0, g.x0 + g.w - 2.0, g.zf + 2.8, 11.0, [[dx - 5.0, dx + 5.0], [cx - 16.0, cx - 5.0]], 0.5, 0.8)
    _scatter_area(b, g.x0 + 2.0, g.z0 + 2.0, g.x0 + g.w - 2.0, g.zf - bd - 2.0, 5)


func _build_waterpark(b: MeshBatch, blk: Node3D, g: Dictionary) -> void:
    var x0: float = g.x0
    var z0: float = g.z0
    var w: float = g.w
    var cx: float = g.cx
    var cz: float = g.cz
    b.flat("paint", Vector3(cx, 0.04, cz), w - 1.0, w - 1.0, Color("e8d8b0"))
    # בריכות (תפאורה בלבד; לא ניתנות לכניסה)
    b.box("water", Vector3(cx + 8.0, 0.12, z0 + 14.0), Vector3(22.0, 0.24, 12.0), Color("3fb4e0"))
    b.box("solid", Vector3(cx + 8.0, 0.16, z0 + 14.0), Vector3(23.0, 0.2, 13.0), Color("f4f4f0"))
    b.box("water", Vector3(cx + 8.0, 0.18, z0 + 14.0), Vector3(21.0, 0.2, 11.0), Color("3fb4e0"))
    b.cyl("solid", Vector3(x0 + 10.0, 0.12, z0 + 38.0), 5.5, 0.24, Color("f4f4f0"))
    b.cyl("water", Vector3(x0 + 10.0, 0.18, z0 + 38.0), 5.0, 0.24, Color("5fd0e8"))
    # נהר עצלן (טבעת)
    b.box("water", Vector3(cx + 4.0, 0.12, z0 + 30.0), Vector3(22.0, 0.2, 3.0), Color("46bfe8"))
    b.box("water", Vector3(cx + 4.0, 0.12, z0 + 42.0), Vector3(22.0, 0.2, 3.0), Color("46bfe8"))
    b.box("water", Vector3(cx - 6.5, 0.12, z0 + 36.0), Vector3(3.0, 0.2, 15.0), Color("46bfe8"))
    b.box("water", Vector3(cx + 14.5, 0.12, z0 + 36.0), Vector3(3.0, 0.2, 15.0), Color("46bfe8"))
    # מגדלי מגלשות
    var cols := [Color("e63946"), Color("f2c200"), Color("2a9df4")]
    for k in range(3):
        var tx := x0 + w - 8.0
        var tz := z0 + 8.0 + k * 9.0
        b.box("solid", Vector3(tx, 6.0, tz), Vector3(3.0, 12.0, 3.0), Color("e8e8e8"), 0.0, true)
        b.box("solid", Vector3(tx - 7.0, 6.2, tz), Vector3(15.0, 0.6, 1.4), cols[k], 0.0, false, Vector3(0, 0, 0.42))
        b.box("solid", Vector3(tx - 14.5, 0.4, tz), Vector3(3.0, 0.8, 2.0), cols[k])
    # שמשיות ושזלונגים
    for k in range(8):
        var ux := x0 + 6.0 + (k % 4) * 8.0
        var uz := z0 + 22.0 + (k / 4) * 22.0
        b.cyl("solid", Vector3(ux, 1.2, uz), 0.04, 2.4, Color("e8e8e8"))
        b.cone("solid", Vector3(ux, 2.5, uz), 1.4, 0.5, _pick(AWNING))
        b.box("solid", Vector3(ux + 1.4, 0.2, uz), Vector3(0.6, 0.3, 1.8), Color("f4f4f0"))
    for k in range(5):
        _palm(b, _rng.randf_range(x0 + 3.0, x0 + w - 3.0), _rng.randf_range(z0 + 3.0, z0 + w - 8.0))
    # כניסה, קופה, גדר עם שער
    b.box("solid", Vector3(g.door.x + 5.0, 1.4, z0 + w - 3.0), Vector3(2.4, 2.8, 2.4), Color("2a9df4"), 0.0, true)
    b.box("solid", Vector3(g.door.x - 5.0, 3.0, z0 + w - 1.4), Vector3(0.7, 6.0, 0.7), Color("f2c200"), 0.0, true)
    b.box("solid", Vector3(g.door.x + 5.0, 3.0, z0 + w - 1.4), Vector3(0.7, 6.0, 0.7), Color("f2c200"), 0.0, true)
    _sign_board(b, blk, g.door.x, 6.4, z0 + w - 1.3, 10.0, 1.6, Color("2a9df4"), str(g.p.name), 70, 130.0)
    var gate := [[g.door.x - 4.0, g.door.x + 4.0]]
    _fence(b, x0 + 0.5, z0 + w - 1.4, x0 + w - 0.5, z0 + w - 1.4, 1.8, Color("2a9df4"), gate)
    _fence(b, x0 + 0.5, z0 + 0.5, x0 + w - 0.5, z0 + 0.5, 1.8, Color("2a9df4"))
    _fence(b, x0 + 0.5, z0 + 0.5, x0 + 0.5, z0 + w - 1.4, 1.8, Color("2a9df4"))
    _fence(b, x0 + w - 0.5, z0 + 0.5, x0 + w - 0.5, z0 + w - 1.4, 1.8, Color("2a9df4"))


# ---------- מסילת רכבת ----------
func _build_rail(b: MeshBatch, blk: Node3D, g: Dictionary, station := false) -> void:
    var x0: float = g.x0
    var z0: float = g.z0
    var w: float = g.w
    var cx: float = g.cx
    # השטח כולו: עשב יבש; פס חצץ; פסי מסילה ורדודים מעל כל אורך הבלוק + חצי כביש משני הצדדים
    b.flat("foliage", Vector3(cx, 0.04, g.cz), w - 0.5, w - 0.5, Color("8a8a58"))
    var za := z0 - 7.0
    var zb := z0 + w + 7.0
    var zm := (za + zb) * 0.5
    b.flat("solid", Vector3(cx, 0.06, zm), 5.0, zb - za, Color("7d7a74"))
    b.box("metal", Vector3(cx - 0.72, 0.17, zm), Vector3(0.12, 0.14, zb - za), Color("9aa0a6"))
    b.box("metal", Vector3(cx + 0.72, 0.17, zm), Vector3(0.12, 0.14, zb - za), Color("9aa0a6"))
    var z := za + 0.5
    while z < zb:
        b.box("solid", Vector3(cx, 0.1, z), Vector3(2.6, 0.1, 0.32), Color("5a4a3a"))
        z += 1.4
    # תיל עילי ועמודים
    for zz in [z0 + 6.0, z0 + 38.0]:
        for sx in [-3.6, 3.6]:
            b.box("metal", Vector3(cx + sx, 3.5, zz), Vector3(0.18, 7.0, 0.18), Color("7d848c"), 0.0, true)
            b.box("metal", Vector3(cx + sx * 0.5, 6.6, zz), Vector3(3.6, 0.12, 0.12), Color("7d848c"))
    b.box("metal", Vector3(cx, 6.2, zm), Vector3(0.04, 0.04, zb - za), Color("202225"))
    # גדרות לאורך המסילה (מחוץ לתחנה): התנגשות מלאה, פתוח בצמתים עם הכבישים
    if not station:
        _fence(b, cx - 4.5, z0, cx - 4.5, z0 + w, 1.8, Color("6d737a"))
    _fence(b, cx + 4.5, z0, cx + 4.5, z0 + w, 1.8, Color("6d737a"))
    # תמרור מעבר רכבת בשני קצות הבלוק
    for zz in [z0 - 1.0, z0 + w + 1.0]:
        for sx in [-5.4, 5.4]:
            b.box("metal", Vector3(cx + sx, 1.6, zz), Vector3(0.08, 3.2, 0.08), Color("8d949b"), 0.0, true)
            b.box("solid", Vector3(cx + sx, 3.0, zz), Vector3(1.2, 0.18, 0.04), Color("d62828"), 0.0, false, Vector3(0, 0, 0.7))
            b.box("solid", Vector3(cx + sx, 3.0, zz), Vector3(1.2, 0.18, 0.04), Color("f4f4f4"), 0.0, false, Vector3(0, 0, -0.7))
    _scatter_row(b, x0 + 1.0, cx - 6.0, z0 + w - 3.0, 9.0, [], 1.5, 0.8)
    _scatter_row(b, cx + 6.0, x0 + w - 1.0, z0 + w - 3.0, 9.0, [], 1.5, 0.8)
    _scatter_area(b, x0 + 1.0, z0 + 2.0, cx - 6.0, z0 + w - 6.0, 6)
    _scatter_area(b, cx + 6.0, z0 + 2.0, x0 + w - 1.0, z0 + w - 6.0, 6)


## הרכבת עצמה: קטר ו-4 קרונות על המסילה (x = מרכז עמודה RAIL_I). נעה רק לאורך Z.
func _build_train() -> void:
    train = AnimatableBody3D.new()
    train.name = "Train"
    var cxp := RAIL_I * S + R * 0.5 + (S - R) * 0.5
    train.position = Vector3(cxp, 0.0, -140.0)
    var b := MeshBatch.new()
    var cars := 5
    var clen := 14.0
    for k in range(cars):
        var zc := -k * (clen + 0.8)
        var body := Color("d9dde0") if k > 0 else Color("2f5d8a")
        b.box("solid", Vector3(0, 2.1, zc), Vector3(3.0, 3.0, clen), body)
        b.box("solid", Vector3(0, 0.7, zc), Vector3(3.0, 0.5, clen), Color("2b2e33"))
        b.box("solid", Vector3(0, 3.65, zc), Vector3(2.6, 0.2, clen - 0.4), Color("b0b6bb"))
        b.box("sign", Vector3(0, 2.2, zc), Vector3(3.04, 0.35, clen - 1.0), Color("2f8f5b") if k > 0 else Color("e8b21a"))
        for s in [-1.0, 1.0]:
            for m in range(6):
                var wz := zc - clen * 0.5 + 1.6 + m * 2.3
                var wk := "win_a" if (m + k) % 3 == 0 else "glass_dark"
                b.box(wk, Vector3(s * 1.52, 2.7, wz), Vector3(0.04, 1.0, 1.5), Color(0.2, 0.28, 0.34) if wk == "glass_dark" else Color(1.0, 0.88, 0.6))
    b.box("carlight", Vector3(0.9, 1.2, clen * 0.5 + 0.1), Vector3(0.4, 0.3, 0.1), Color.WHITE)
    b.box("carlight", Vector3(-0.9, 1.2, clen * 0.5 + 0.1), Vector3(0.4, 0.3, 0.1), Color.WHITE)
    var mi := MeshInstance3D.new()
    mi.mesh = b.to_mesh(["solid", "glass_dark", "win_a", "sign", "carlight"], mats)
    train.add_child(mi)
    var cs := CollisionShape3D.new()
    var sh := BoxShape3D.new()
    var total := cars * (clen + 0.8)
    sh.size = Vector3(3.0, 3.6, total)
    cs.shape = sh
    cs.position = Vector3(0, 1.8, -total * 0.5 + clen * 0.5)
    train.add_child(cs)
    train.sync_to_physics = false
    add_child(train)


# ---------- ציוני דרך ----------
func _build_landmark(b: MeshBatch, blk: Node3D, g: Dictionary) -> void:
    var p: Dictionary = g.p
    var x0: float = g.x0
    var z0: float = g.z0
    var w: float = g.w
    var cx: float = g.cx
    var cz: float = g.cz
    var sub: String = p.sub
    var sign_y := 6.0
    var sign_z: float = g.zf + 0.4
    match sub:
        "azrieli":
            _azrieli_tower(b, Vector3(cx - 14.0, 55.0, cz), 6.0, 110.0, 40, Color("9fb3c4"))
            _azrieli_tower(b, Vector3(cx, 55.0, cz), 7.0, 110.0, 3, Color("8da4b8"))
            _azrieli_tower(b, Vector3(cx + 14.0, 55.0, cz), 6.5, 110.0, 4, Color("a9bccb"))
            b.box("solid", Vector3(cx, 2.0, cz + 8.0), Vector3(40.0, 4.0, 14.0), Color("c9d1d6"), 0.0, true)
            b.box("lamp", Vector3(cx - 14.0, 110.5, cz), Vector3(3.0, 0.6, 3.0), Color("ff5533"))
            _entrance(b, blk, g, p, true)
            _scatter_row(b, x0 + 2.0, x0 + w - 2.0, g.zf + 2.6, 10.0, [[g.door.x - 6.0, g.door.x + 6.0]], 0.6, 0.9)
        "mall":
            var zf: float = z0 + 31.0
            var bw := 42.0
            var bd := 26.0
            b.box("solid", Vector3(cx, 6.0, zf - bd * 0.5), Vector3(bw, 12.0, bd), Color("c9d1d6"), 0.0, true)
            b.box("glass_dark", Vector3(cx, 5.0, zf + 0.1), Vector3(bw - 4.0, 8.0, 0.2), Color(0.28, 0.42, 0.52))
            b.box("shop_glass", Vector3(cx, 2.4, zf + 0.15), Vector3(bw - 8.0, 4.0, 0.1), Color(0.5, 0.7, 0.8))
            b.box("solid", Vector3(cx, 5.2, zf + 2.0), Vector3(14.0, 0.3, 4.0), Color("8d949b"))
            for sx in [-6.5, 6.5]:
                b.box("solid", Vector3(cx + sx, 2.6, zf + 3.6), Vector3(0.5, 5.2, 0.5), Color("e8e8e8"), 0.0, true)
            _sign_board(b, blk, cx, 10.0, zf + 0.2, 20.0, 2.0, Color("2f5d8a"), str(p.name), 110, 180.0)
            _atm(b, blk, cx + 12.0, zf + 0.7)
            _roof(b, cx, zf - bd * 0.5, bw, bd, 12.0)
            _parking_lot(b, g, z0 + 35.5, z0 + w - 1.5)
            for sx in [-1.0, 1.0]:
                _lamp(b, g.door.x + sx * 18.0, z0 + 38.0, 0.0, 1.0)
            sign_y = 0.0
        "market":
            for a in range(3):
                for k in range(6):
                    var sx := x0 + 6.0 + k * 7.5
                    var sz := z0 + 10.0 + a * 11.0
                    var ac := _pick([Color("c0392b"), Color("e67e22"), Color("27ae60"), Color("2980b9"), Color("f2c200"), Color("8e44ad")])
                    b.box("solid", Vector3(sx, 0.55, sz), Vector3(3.6, 1.1, 2.0), Color("8a6a43"), 0.0, true)
                    b.box("solid", Vector3(sx, 2.7, sz - 0.4), Vector3(4.2, 0.12, 3.0), ac, 0.0, false, Vector3(0.18, 0, 0))
                    b.box("metal", Vector3(sx - 1.9, 1.3, sz + 1.1), Vector3(0.07, 2.6, 0.07), Color("8d949b"))
                    b.box("metal", Vector3(sx + 1.9, 1.3, sz + 1.1), Vector3(0.07, 2.6, 0.07), Color("8d949b"))
                    for m in range(4):
                        b.box("foliage", Vector3(sx - 1.2 + m * 0.8, 1.2, sz + 0.2), Vector3(0.6, 0.25, 0.6), _pick([Color("e0503a"), Color("f2c200"), Color("4a8a3c"), Color("e67e22"), Color("8e44ad")]))
            _lamp(b, cx, z0 + 4.0, 0.0, 1.0)
            sign_y = 5.0
        "beach":
            b.flat("paint", Vector3(cx, 0.04, cz), w - 0.6, w - 0.6, Color("e8d6a6"))
            b.flat("solid", Vector3(x0 + w - 4.0, 0.05, cz), 8.0, w - 0.6, Color("b08a5a"))
            b.box("solid", Vector3(cx - 6.0, 2.4, cz - 6.0), Vector3(4.0, 0.2, 3.0), Color("f2efe6"))
            for sx in [-1.5, 1.5]:
                for sz in [-1.0, 1.0]:
                    b.box("solid", Vector3(cx - 6.0 + sx, 1.1, cz - 6.0 + sz), Vector3(0.18, 2.2, 0.18), Color("8a6a43"))
            b.box("solid", Vector3(cx - 6.0, 3.6, cz - 6.0), Vector3(3.0, 2.2, 2.4), Color("f2efe6"), 0.0, true)
            b.box("solid", Vector3(cx - 6.0, 4.9, cz - 6.0), Vector3(3.4, 0.3, 2.8), Color("d62828"))
            b.box("solid", Vector3(cx + 4.0, 1.4, cz + 10.0), Vector3(7.0, 2.8, 5.0), Color("f2efe6"), 0.0, true)
            b.box("solid", Vector3(cx + 4.0, 3.0, cz + 10.0), Vector3(7.6, 0.3, 5.6), Color("2a9df4"))
            _label(blk, "קיוסק", Vector3(cx + 4.0, 2.4, cz + 12.55), 30, Color.WHITE, 0, 50.0)
            for k in range(9):
                var ux := x0 + 5.0 + _rng.randf_range(0.0, w - 20.0)
                var uz := z0 + 4.0 + _rng.randf_range(0.0, w - 10.0)
                b.cyl("solid", Vector3(ux, 1.2, uz), 0.04, 2.4, Color("e8e8e8"))
                b.cone("solid", Vector3(ux, 2.5, uz), 1.5, 0.55, _pick(AWNING))
            for k in range(6):
                _palm(b, x0 + w - 7.0 + _rng.randf_range(-0.8, 0.8), z0 + 4.0 + k * 8.5)
            for k in range(4):
                _bench(b, x0 + w - 2.2, z0 + 8.0 + k * 11.0, -PI / 2.0)
            for k in range(3):
                _lamp(b, x0 + w - 1.0, z0 + 6.0 + k * 18.0, 1.0, 0.0)
            sign_y = 4.0
        "plaza":
            b.flat("paint", Vector3(cx, 0.04, cz), w - 1.0, w - 1.0, Color("d9d4c6"))
            b.cyl("solid", Vector3(cx, 0.4, cz), 4.6, 0.8, Color("c9c3b4"), true)
            b.cyl("water", Vector3(cx, 0.82, cz), 4.1, 0.1, Color("6fc3df"))
            b.cyl("solid", Vector3(cx, 1.6, cz), 0.5, 2.4, Color("b8b2a4"))
            b.cyl("water", Vector3(cx, 2.9, cz), 1.2, 0.2, Color("6fc3df"))
            for k in range(5):
                _tree(b, x0 + 6.0 + k * 9.5 + _rng.randf_range(-1.0, 1.0), z0 + 5.0 + _rng.randf_range(-0.6, 0.6), 8)
                _tree(b, x0 + 6.0 + k * 9.5 + _rng.randf_range(-1.0, 1.0), z0 + w - 14.0 + _rng.randf_range(-0.6, 0.6), 8)
            b.box("solid", Vector3(x0 + 8.0, 1.4, cz), Vector3(5.0, 2.8, 3.5), Color("e8dcc4"), 0.0, true)
            b.box("solid", Vector3(x0 + 8.0, 3.0, cz), Vector3(6.0, 0.25, 4.5), Color("c0392b"))
            _label(blk, "קפה הכיכר", Vector3(x0 + 8.0, 2.2, cz + 1.8), 28, Color.WHITE, 0, 45.0)
            for k in range(4):
                _bench(b, cx - 9.0 + k * 6.0, cz + 8.0, 0.0)
            for sx in [-1.0, 1.0]:
                for sz in [-1.0, 1.0]:
                    b.box("solid", Vector3(cx + 14.0 + sx * 3.0, 1.5, cz - 12.0 + sz * 3.0), Vector3(0.3, 3.0, 0.3), Color("e8e8e8"))
            b.box("solid", Vector3(cx + 14.0, 3.1, cz - 12.0), Vector3(7.0, 0.2, 7.0), Color("e8e8e8"))
            for k in range(3):
                _lamp(b, x0 + 4.0 + k * 20.0, cz + 14.0, 0.0, -1.0)
            sign_y = 3.0
        "ayalon":
            b.box("solid", Vector3(cx - 12.0, 0.6, cz), Vector3(2.0, 1.2, w - 8.0), Color("8d8d8d"), 0.0, true)
            b.box("solid", Vector3(cx + 12.0, 0.6, cz), Vector3(2.0, 1.2, w - 8.0), Color("8d8d8d"), 0.0, true)
            b.box("solid", Vector3(cx + 14.0, 3.0, cz), Vector3(0.4, 6.0, w - 8.0), Color("b0b6bb"), 0.0, true)
            # גשר הולכי רגל מעל איילון: סיפון, מעקות, עמודים ומדרגות
            var bx0 := cx + 6.0
            var bx1 := cx + 58.0
            var bm := (bx0 + bx1) * 0.5
            b.box("solid", Vector3(bm, 6.5, cz), Vector3(bx1 - bx0 - 30.0, 0.4, 3.2), Color("b8b4aa"))
            b.box("metal", Vector3(bm, 7.2, cz - 1.55), Vector3(bx1 - bx0 - 30.0, 1.0, 0.06), Color("5a5f66"))
            b.box("metal", Vector3(bm, 7.2, cz + 1.55), Vector3(bx1 - bx0 - 30.0, 1.0, 0.06), Color("5a5f66"))
            b.box("solid", Vector3(cx + 24.5, 3.2, cz), Vector3(1.0, 6.4, 3.0), Color("b8b4aa"), 0.0, true)
            b.box("solid", Vector3(cx + 39.5, 3.2, cz), Vector3(1.0, 6.4, 3.0), Color("b8b4aa"), 0.0, true)
            b.box("solid", Vector3(cx + 15.0, 3.3, cz), Vector3(20.0, 0.35, 3.0), Color("a8a49b"), 0.0, false, Vector3(0, 0, 0.0))
            b.box("solid", Vector3(cx + 49.0, 3.3, cz), Vector3(20.0, 0.35, 3.0), Color("a8a49b"))
            sign_y = 4.0
        "station":
            _build_rail(b, blk, g, true)
            # רציף ושביל נוסעים
            b.box("solid", Vector3(cx - 4.0, 0.45, cz), Vector3(4.0, 0.9, 46.0), Color("c9c6bf"), 0.0, true)
            b.box("solid", Vector3(cx - 4.0, 0.92, cz), Vector3(4.0, 0.06, 46.0), Color("e8c200"), 0.0)
            b.box("solid", Vector3(cx - 4.5, 3.8, cz), Vector3(3.6, 0.2, 32.0), Color("8d949b"))
            for k in range(5):
                b.box("metal", Vector3(cx - 5.6, 2.2, cz - 14.0 + k * 7.0), Vector3(0.2, 4.4, 0.2), Color("5a5f66"), 0.0, true)
                b.box("lamp", Vector3(cx - 4.5, 3.6, cz - 14.0 + k * 7.0), Vector3(1.2, 0.1, 0.4), Color("fff2cc"))
            for k in range(3):
                _bench(b, cx - 4.3, cz - 8.0 + k * 8.0, PI / 2.0)
            # מבנה התחנה
            b.box("solid", Vector3(x0 + 8.0, 5.0, cz), Vector3(12.0, 10.0, 28.0), Color("e8e4d8"), 0.0, true)
            b.box("glass_dark", Vector3(x0 + 14.1, 4.0, cz), Vector3(0.2, 6.0, 22.0), Color(0.28, 0.42, 0.52))
            b.box("solid", Vector3(x0 + 8.0, 10.2, cz), Vector3(13.0, 0.5, 29.0), Color("2f5d8a"))
            _windows(b, 2, Vector3(x0 + 14.0, 0, cz), 24.0, 2, 4.0, 0.0, 2.0, 1.6, 2.0)
            _sign_board(b, blk, x0 + 14.2, 8.4, cz, 14.0, 1.8, Color("2f5d8a"), "תחנת הרכבת", 80, 160.0)
            _atm(b, blk, x0 + 14.4, cz + 14.0)
            _scatter_row(b, x0 + 2.0, x0 + 16.0, z0 + w - 3.0, 8.0, [], 1.0, 0.9)
            sign_y = 0.0
    if sign_y > 0.0 and sub != "station":
        _label(blk, str(p.name), Vector3(g.door.x, sign_y, sign_z), 110, Color("ffd600"), 0, 160.0)


## מגדל עזריאלי: קירות מסך עם חלונות דולקים בלילה
func _azrieli_tower(b: MeshBatch, c: Vector3, r: float, h: float, sides: int, col: Color) -> void:
    var rot := PI / 4.0 if sides == 4 else (PI / 6.0 if sides == 3 else 0.0)
    var rad := r if sides >= 16 else r * 1.15
    b.prism("solid", c, rad, h, sides, col, rot, Vector3(r * 2.0, h, r * 2.0))
    var floors := int(h / 4.0)
    for f in range(floors):
        var y := c.y - h * 0.5 + 3.0 + f * 4.0
        var roll := _rng.randf()
        var key := "glass_dark"
        var gc := Color(0.2, 0.3, 0.4)
        if roll > 0.78:
            key = "win_a"
            gc = Color(1.0, 0.88, 0.6)
        elif roll > 0.64:
            key = "win_b"
            gc = Color(0.9, 0.95, 1.0)
        b.prism(key, Vector3(c.x, y, c.z), rad + 0.06, 1.8, sides, gc, rot)
