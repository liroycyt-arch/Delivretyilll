extends Node
## התזמור: עולם, שחקן, סביבה, זרימת משימות, שמירה, השהיה והגדרות.

var world: World
var player: Player
var ui: UI
var sun: DirectionalLight3D
var env: Environment
var sky_mat: ProceduralSkyMaterial
var marker: MeshInstance3D
var marker_mat: StandardMaterial3D
var customer: Figure = null
var sfx_player: AudioStreamPlayer
var sounds := {}
var in_game := false
var is_paused := false
var _offer_t := 8.0
var _save_t := 0.0
var _pos_t := 0.0
var _last_state := ""
var nav_marker: MeshInstance3D
var nav_mat: StandardMaterial3D
var audio: CityAudio
var _sky_hour := -99.0
var _shadows_applied := true
var _disp_sig := ""
const RESOLUTIONS := [Vector2i(1280, 720), Vector2i(1600, 900), Vector2i(1920, 1080), Vector2i(2560, 1440)]
const SKY_KF := [
    [0.0, "060b1c", "0f1a38", "9fb4ff", 0.14, 0.35],
    [5.0, "060b1c", "0f1a38", "9fb4ff", 0.14, 0.35],
    [6.0, "3a4f86", "f0a070", "ffb070", 0.55, 0.5],
    [7.5, "2a6ab5", "bcd6ea", "ffe0b8", 1.0, 0.8],
    [12.0, "1e4a85", "a9c6e0", "ffffff", 1.3, 1.0],
    [16.0, "2a5a95", "c4d6e0", "fff0d0", 1.1, 0.95],
    [18.0, "3a4a80", "ff8a50", "ff9050", 0.7, 0.6],
    [19.5, "141f45", "5a3a5a", "8090c0", 0.22, 0.42],
    [21.0, "060b1c", "0f1a38", "9fb4ff", 0.14, 0.35],
    [24.0, "060b1c", "0f1a38", "9fb4ff", 0.14, 0.35],
]


func _ready() -> void:
    process_mode = Node.PROCESS_MODE_ALWAYS
    get_window().title = "משלוחים בישראל"
    world = World.new()
    world.process_mode = Node.PROCESS_MODE_PAUSABLE
    add_child(world)
    Game.world = world
    _make_environment()
    marker = MeshInstance3D.new()
    var cy := CylinderMesh.new()
    cy.top_radius = 1.4
    cy.bottom_radius = 1.4
    cy.height = 50.0
    marker.mesh = cy
    var mm := StandardMaterial3D.new()
    mm.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    mm.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
    mm.albedo_color = Color(1, 0.84, 0, 0.3)
    marker.material_override = mm
    marker_mat = mm
    marker.visible = false
    add_child(marker)
    nav_marker = MeshInstance3D.new()
    var nc := CylinderMesh.new()
    nc.top_radius = 1.0
    nc.bottom_radius = 1.0
    nc.height = 60.0
    nav_marker.mesh = nc
    nav_mat = StandardMaterial3D.new()
    nav_mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    nav_mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
    nav_mat.albedo_color = Color(0.2, 0.8, 1.0, 0.35)
    nav_marker.material_override = nav_mat
    nav_marker.visible = false
    add_child(nav_marker)
    audio = CityAudio.new()
    audio.world = world
    audio.process_mode = Node.PROCESS_MODE_PAUSABLE
    add_child(audio)
    sfx_player = AudioStreamPlayer.new()
    add_child(sfx_player)
    sounds = {
        "offer": _tone([880, 1175]), "pickup": _tone([660, 880]), "done": _tone([660, 880, 1320]),
        "error": _tone([220]), "boost": _tone([440, 660, 990], 0.2), "atm": _tone([1046, 784]), "shop": _tone([784, 1046]),
        "phone": _tone([988, 1318], 0.08), "step": _tone([300], 0.05), "msg": _tone([1175, 1568], 0.1),
    }
    ui = UI.new()
    ui.main = self
    add_child(ui)
    Game.notify.connect(_on_notify)
    Game.sfx.connect(_play)
    Game.mission_changed.connect(_on_mission_changed)
    Game.appearance_changed.connect(_on_appearance)
    apply_settings()
    ui.show_main_menu()
    if OS.get_cmdline_user_args().has("--autotest"):
        _autotest.call_deferred()


func _tone(freqs: Array, dur := 0.13) -> AudioStreamWAV:
    var rate := 22050
    var n := int(rate * dur)
    var data := PackedByteArray()
    data.resize(n * 2 * freqs.size())
    var idx := 0
    for f in freqs:
        for k in range(n):
            var e := 1.0 - float(k) / n
            data.encode_s16(idx, int(sin(TAU * f * k / rate) * e * 0.4 * 32767.0))
            idx += 2
    var w := AudioStreamWAV.new()
    w.format = AudioStreamWAV.FORMAT_16_BITS
    w.mix_rate = rate
    w.stereo = false
    w.data = data
    return w


func _play(n: String) -> void:
    if bool(Game.settings.get("mute_notify", false)) or not sounds.has(n):
        return
    sfx_player.stream = sounds[n]
    sfx_player.volume_db = linear_to_db(maxf(0.001, float(Game.settings.get("volume", 0.8))))
    sfx_player.play()


func _on_notify(t: String) -> void:
    if bool(Game.settings.get("voice", false)):
        var voices := DisplayServer.tts_get_voices_for_language("he")
        if voices.size() > 0:
            DisplayServer.tts_speak(t, voices[0])


func _make_environment() -> void:
    sun = DirectionalLight3D.new()
    sun.shadow_enabled = true
    sun.directional_shadow_max_distance = 140.0
    add_child(sun)
    sky_mat = ProceduralSkyMaterial.new()
    var sky := Sky.new()
    sky.sky_material = sky_mat
    env = Environment.new()
    env.background_mode = Environment.BG_SKY
    env.sky = sky
    env.ambient_light_source = Environment.AMBIENT_SOURCE_SKY
    env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
    env.fog_enabled = true
    env.fog_density = 0.0012
    var we := WorldEnvironment.new()
    we.environment = env
    add_child(we)


func apply_settings() -> void:
    var s: Dictionary = Game.settings
    world.set_quality(int(s.quality))
    Engine.max_fps = int(s.fps)
    if bool(s.shadows) != _shadows_applied or sun.shadow_enabled != bool(s.shadows):
        sun.shadow_enabled = bool(s.shadows)
        _shadows_applied = bool(s.shadows)
    get_viewport().msaa_3d = [Viewport.MSAA_DISABLED, Viewport.MSAA_2X, Viewport.MSAA_4X][clampi(int(s.quality), 0, 2)]
    apply_display()
    _sky_hour = -99.0
    update_sky(true)


## מצבי תצוגה: חלון / מסך מלא / חלון ללא מסגרת. רזולוציה לא נתמכת מוחלפת בגדולה נתמכת ונשמרת.
func apply_display() -> void:
    if DisplayServer.get_name() == "headless":
        return
    var s: Dictionary = Game.settings
    var win := get_window()
    var screen := DisplayServer.window_get_current_screen()
    var ssize := DisplayServer.screen_get_size(screen)
    var spos := DisplayServer.screen_get_position(screen)
    var ri := clampi(int(s.get("resolution", 1)), 0, RESOLUTIONS.size() - 1)
    if RESOLUTIONS[ri].x > ssize.x or RESOLUTIONS[ri].y > ssize.y:
        var best := 0
        for k in range(RESOLUTIONS.size()):
            if RESOLUTIONS[k].x <= ssize.x and RESOLUTIONS[k].y <= ssize.y:
                best = k
        ri = best
        s["resolution"] = ri
    var res: Vector2i = RESOLUTIONS[ri]
    var mode := clampi(int(s.get("display_mode", 0)), 0, 2)
    s["display_mode"] = mode
    s["fullscreen"] = mode == 1
    var sig := "%d_%d" % [mode, ri]
    if sig == _disp_sig:
        return        # לא משנים חלון בכל תזוזת סליידר
    _disp_sig = sig
    match mode:
        0:
            win.mode = Window.MODE_WINDOWED
            win.borderless = false
            win.size = res
            win.position = spos + (ssize - res) / 2
        1:
            win.borderless = false
            win.mode = Window.MODE_EXCLUSIVE_FULLSCREEN
        2:
            win.mode = Window.MODE_WINDOWED
            win.borderless = true
            win.size = ssize
            win.position = spos


## שמיים, שמש/ירח, צבע אור ועוצמות לפי שעת המשחק (מחזור זריחה-שקיעה-לילה רציף)
func update_sky(force := false) -> void:
    var h := Game.hour_float()
    if not force and absf(h - _sky_hour) < 0.02:
        return
    _sky_hour = h
    var a: Array = SKY_KF[0]
    var b: Array = SKY_KF[SKY_KF.size() - 1]
    for k in range(SKY_KF.size() - 1):
        if h >= float(SKY_KF[k][0]) and h <= float(SKY_KF[k + 1][0]):
            a = SKY_KF[k]
            b = SKY_KF[k + 1]
            break
    var f := inverse_lerp(float(a[0]), float(b[0]), h) if float(b[0]) > float(a[0]) else 0.0
    sky_mat.sky_top_color = Color(a[1]).lerp(Color(b[1]), f)
    sky_mat.sky_horizon_color = Color(a[2]).lerp(Color(b[2]), f)
    sky_mat.ground_horizon_color = sky_mat.sky_horizon_color
    sky_mat.ground_bottom_color = sky_mat.sky_top_color.darkened(0.5)
    sun.light_color = Color(a[3]).lerp(Color(b[3]), f)
    sun.light_energy = lerpf(float(a[4]), float(b[4]), f)
    env.ambient_light_energy = lerpf(float(a[5]), float(b[5]), f)
    env.fog_light_color = sky_mat.sky_horizon_color
    var day := h >= 6.0 and h < 18.0
    var t := 0.0
    var elev := 8.0
    if day:
        t = (h - 6.0) / 12.0
        elev = sin(t * PI) * 66.0 + 5.0
    else:
        t = fposmod(h - 18.0, 24.0) / 12.0
        elev = sin(t * PI) * 45.0 + 6.0
    sun.rotation_degrees = Vector3(-elev, lerpf(-80.0, 80.0, t), 0.0)
    if world != null:
        world.set_hour(h)
    if player != null:
        var dark := world.night_factor() > 0.25 or sun.light_energy < 0.35
        player.light.visible = dark
        player.light.shadow_enabled = false


# ---------- זרימה ----------
func new_game() -> void:
    Game.reset_new()
    ui.show_setup()


func continue_game() -> void:
    Game.load_game()
    begin_play(false)


func begin_play(is_new: bool) -> void:
    ui.show_loading()
    Game.world = world
    var pos: Vector3 = Vector3(8 * World.S, 0.3, 12 * World.S) if is_new else Game.last_pos
    if is_new:
        Game.last_pos = pos
        Game.last_heading = 0.0
        Game.mission = {}
        Game.stop_nav()
    await world.preload_around(pos, ui.set_progress)
    if player != null:
        player.queue_free()
    player = Player.new()
    add_child(player)
    player.global_position = pos
    player.heading = Game.last_heading
    player.rotation.y = player.heading
    player.setup(Game.look, Game.company, Game.vehicle)
    Game.player = player
    in_game = true
    is_paused = false
    get_tree().paused = false
    ui.clear_screen()
    Game.clock_resume()
    ui.show_hud(player, world)
    _offer_t = 6.0
    _last_state = ""
    _on_mission_changed()
    apply_settings()
    _update_mouse()
    if is_new:
        Game.notify.emit("ברוך הבא, %s! הזמנה ראשונה תגיע בקרוב. P פותח את הטלפון" % Game.player_name)
        Game.save_game()


func _on_appearance() -> void:
    if player != null and in_game:
        player.setup(Game.look, Game.company, Game.vehicle)
        player.set_carrying(Game.mission.get("state", "") == "to_customer")


func _on_mission_changed() -> void:
    if player == null:
        return
    var m: Dictionary = Game.mission
    var st: String = m.get("state", "")
    marker.visible = false
    if st == "to_pickup" or st == "to_customer":
        var p: Dictionary = world.poi(m.ri, m.rj) if st == "to_pickup" else world.poi(m.hi, m.hj)
        marker.global_position = Vector3(p.door.x, 25.0, p.door.z)
        marker_mat.albedo_color = Color(1, 0.84, 0, 0.3) if st == "to_pickup" else Color(0.18, 0.8, 0.44, 0.3)
        marker.visible = true
    if st != _last_state:
        if st == "to_customer" and not bool(m.get("leave", false)):
            _spawn_customer(world.poi(m.hi, m.hj))
        elif st != "to_customer":
            _free_customer()
        _last_state = st
    player.set_carrying(st == "to_customer" and not player.bag.visible)
    if m.is_empty() and not Game.nav_free:
        Game.stop_nav()


func _spawn_customer(p: Dictionary) -> void:
    _free_customer()
    customer = Figure.new()
    add_child(customer)
    var lk := {"skin": p.h % 5, "hair_color": (p.h / 5) % 5, "hair_style": (p.h / 25) % 4, "body": (p.h / 7) % 3, "shirt": (p.h / 11) % 6, "shorts": (p.h % 2) == 0}
    customer.build(lk, "customer")
    customer.global_position = p.door + Vector3(1.4, 0, -0.9)
    customer.rotation.y = PI


func _free_customer() -> void:
    if customer != null and is_instance_valid(customer):
        customer.queue_free()
    customer = null


func set_phone(open: bool, page := "home") -> void:
    if not in_game:
        return
    if open:
        ui.open_phone(page)
        _play("phone")
    else:
        ui.close_phone()
        if not ui.modal_open:
            _play("phone")
    player.input_enabled = not (open or ui.modal_open)
    player.set_phone_hand(open)
    _update_mouse()


func set_modal(open: bool) -> void:
    if not in_game:
        return
    player.input_enabled = not (open or ui.phone_open)
    _update_mouse()


func _update_mouse() -> void:
    # העכבר חופשי; לחצן ימני לחוץ (במחלקת Player) תופס אותו לסיבוב המצלמה
    Input.mouse_mode = Input.MOUSE_MODE_VISIBLE


func pause_game() -> void:
    if not in_game or is_paused:
        return
    _save_progress()
    is_paused = true
    get_tree().paused = true
    ui.show_pause()
    _update_mouse()


func resume() -> void:
    Game.clock_resume()
    is_paused = false
    get_tree().paused = false
    ui.clear_screen()
    _update_mouse()


func _save_progress() -> void:
    if player != null:
        Game.last_pos = Vector3(player.global_position.x, maxf(0.3, player.global_position.y), player.global_position.z)
        Game.last_heading = player.heading
    Game.save_game()


func save_and_menu() -> void:
    _save_progress()
    get_tree().paused = false
    in_game = false
    is_paused = false
    if player != null:
        player.queue_free()
        player = null
        Game.player = null
    _free_customer()
    marker.visible = false
    ui.close_phone()
    Game.load_game()
    ui.show_main_menu()
    _update_mouse()


func quit_game() -> void:
    if in_game:
        _save_progress()
    get_tree().quit()


func _notification(what: int) -> void:
    if what == NOTIFICATION_WM_CLOSE_REQUEST:
        quit_game()


func _unhandled_input(event: InputEvent) -> void:
    if not in_game:
        return
    if event.is_action_pressed("pause"):
        if is_paused:
            resume()
        elif ui.modal_open:
            ui.close_modal()
        elif ui.phone_open:
            set_phone(false)
        else:
            pause_game()
    elif is_paused:
        return
    elif event.is_action_pressed("phone"):
        set_phone(not ui.phone_open)
    elif event.is_action_pressed("map"):
        set_phone(true, "map")
    elif event.is_action_pressed("interact"):
        var it := current_interaction()
        if it.has("fn"):
            it.fn.call()


func current_interaction() -> Dictionary:
    var m: Dictionary = Game.mission
    var p := player.global_position
    var st: String = m.get("state", "")
    if st == "to_pickup":
        var r: Dictionary = world.poi(m.ri, m.rj)
        if _near(p, r.door, 10.0):
            if absf(player.speed) < 3.0:
                return {"text": "E — איסוף משלוח מ%s" % r.name, "fn": _do_pickup}
            return {"text": "האט כדי לאסוף את ההזמנה"}
    elif st == "to_customer":
        var h: Dictionary = world.poi(m.hi, m.hj)
        if _near(p, h.door, 10.0):
            if absf(player.speed) < 3.0:
                return {"text": "E — השאר ליד הדלת" if bool(m.leave) else "E — מסירת המשלוח", "fn": _do_deliver}
            return {"text": "האט כדי למסור את ההזמנה"}
    var b: Dictionary = world.poi_at(p)
    if world.has_shop(b) and _near(p, b.entry, 10.0):
        return {"text": "E — קניות ב%s" % b.name, "fn": func(): ui.show_shop(b)}
    if world.has_atm(b) and _near(p, b.entry, 10.0):
        return {"text": "E — כספומט: %s" % b.name, "fn": func(): set_phone(true, "bank")}
    return {}


## האם השחקן קרוב לכספומט / סניף בנק (נדרש להפקדה ומשיכה)
func near_atm() -> bool:
    if player == null:
        return false
    var b: Dictionary = world.poi_at(player.global_position)
    return world.has_atm(b) and _near(player.global_position, b.entry, 14.0)


func _near(a: Vector3, b: Vector3, r: float) -> bool:
    return Vector2(a.x - b.x, a.z - b.z).length() < r


func _do_pickup() -> void:
    player.play_pickup()
    Game.pickup()


func _do_deliver() -> void:
    var m: Dictionary = Game.mission
    var h: Dictionary = world.poi(m.hi, m.hj)
    var leave := bool(m.leave)
    var summary := Game.complete_mission()
    if summary.is_empty():
        return
    player.drop_bag()
    if leave:
        var bm := MeshInstance3D.new()
        var b := BoxMesh.new()
        b.size = Vector3(0.3, 0.3, 0.16)
        bm.mesh = b
        var mt := StandardMaterial3D.new()
        mt.albedo_color = Color("111111")
        bm.material_override = mt
        add_child(bm)
        bm.global_position = h.door + Vector3(-1.0, 0.15, -1.2)
        get_tree().create_timer(8.0).timeout.connect(bm.queue_free)
    elif customer != null and is_instance_valid(customer):
        customer.pose_receive()
        var c := customer
        customer = null
        var tw := c.create_tween()
        tw.tween_interval(2.0)
        tw.tween_property(c, "position", c.position + Vector3(0, 0, -3.0), 1.5)
        tw.tween_callback(c.queue_free)
    ui.show_summary(summary)


func _process(delta: float) -> void:
    if customer != null and is_instance_valid(customer):
        customer.pose_stand(0.0, 0.0)
    if not in_game or is_paused or player == null:
        return
    world.update_streaming(player.global_position, player.velocity)
    Game.clock_update()
    update_sky()
    Game.tick(delta)
    _update_nav_marker(delta)
    audio.tick(delta, player, world.night_factor(), str(world.poi_at(player.global_position).kind))
    if Game.mission.is_empty():
        _offer_t -= delta
        if _offer_t <= 0.0:
            Game.new_offer()
            _offer_t = randf_range(15.0, 30.0)
    _pos_t += delta
    if _pos_t > 4.0:
        _pos_t = 0.0
        if player.is_on_floor():
            Game.last_pos = player.global_position
    _save_t += delta
    if _save_t > 45.0:
        _save_t = 0.0
        _save_progress()
    var it := current_interaction()
    ui.set_prompt(str(it.get("text", "")))
    ui.update_hud(player, world)
    if marker.visible:
        marker.rotation.y += delta


func _update_nav_marker(delta: float) -> void:
    if Game.nav_active and not Game.nav_poi.is_empty():
        var e: Vector3 = Game.nav_poi.entry
        nav_marker.global_position = Vector3(e.x, 30.0, e.z)
        nav_mat.albedo_color.a = 0.25 + 0.15 * sin(Time.get_ticks_msec() * 0.005)
        nav_marker.visible = true
        nav_marker.rotation.y += delta
    else:
        nav_marker.visible = false


# ---------- בדיקה אוטומטית (רצה רק עם --autotest, לשימוש ב-CI) ----------
var _at_errors := 0


func _chk(cond: bool, msg: String) -> void:
    if cond:
        print("AT ok: ", msg)
    else:
        _at_errors += 1
        print("AUTOTEST FAIL: ", msg)


func _frames(n: int) -> void:
    for i in range(n):
        await get_tree().process_frame


func _autotest() -> void:
    await _frames(5)
    Game.reset_new()
    ui.show_setup()
    await _frames(3)
    ui._setup_name = "בדיקה"
    ui._finish_setup()
    var guard := 0
    while not in_game and guard < 3000:
        await get_tree().process_frame
        guard += 1
    _chk(in_game, "game started")
    if not in_game:
        _finish_autotest()
        return
    await _frames(30)
    _chk(world.chunks.size() > 0, "chunks loaded")
    _chk(world.mats.has("win_a") and world.traffic != null and world.train != null, "world systems exist")
    # --- שעון משחק ---
    Game.game_seconds = 10.0 * 3600.0
    Game.clock_resume()
    var gs0 := Game.game_seconds
    await get_tree().create_timer(2.0).timeout
    var dgs := Game.game_seconds - gs0
    _chk(dgs > 90.0 and dgs < 160.0, "clock runs 1 real sec = 1 game min (got %.0f game sec in 2s)" % dgs)
    set_phone(true, "clock")
    await _frames(3)
    _chk(ui.l_clock.text == ui.phone_clock.text, "HUD clock equals phone clock (%s)" % ui.l_clock.text)
    set_phone(false)
    # --- יום / לילה ---
    Game.game_seconds = 23.0 * 3600.0
    update_sky(true)
    var lamp: StandardMaterial3D = world.mats["lamp"]
    var wina: StandardMaterial3D = world.mats["win_a"]
    _chk(lamp.emission_energy_multiplier > 1.0 and wina.emission_energy_multiplier > 1.0, "night: lamps and windows lit")
    Game.game_seconds = 12.0 * 3600.0
    update_sky(true)
    _chk(lamp.emission_energy_multiplier < 0.01, "day: street lamps off")
    # --- Boost ---
    _chk(Game.try_boost(), "boost starts")
    _chk(Game.boost_state() == "active", "boost active")
    _chk(not Game.try_boost(), "boost cannot restart while active")
    await get_tree().create_timer(5.3).timeout
    _chk(Game.boost_state() == "cooldown", "boost ended after 5s, now cooldown")
    _chk(is_equal_approx(Game.boost_factor(), 1.0), "boost factor back to 1")
    Game.boost_cd = 0.0
    # --- בנק ומזומן ---
    Game.cash = 50
    var bal0 := Game.balance
    _chk(Game.deposit(20), "deposit ok")
    _chk(Game.cash == 30 and Game.balance == bal0 + 20, "deposit moves cash to bank exactly")
    _chk(not Game.deposit(1000), "deposit above cash rejected")
    _chk(not Game.withdraw(-5), "negative withdraw rejected")
    _chk(not Game.withdraw(Game.balance + 1), "withdraw above balance rejected")
    _chk(Game.withdraw(10) and Game.cash == 40 and Game.balance == bal0 + 10, "withdraw moves bank to cash exactly")
    # --- סופרמרקט ---
    var cash0 := Game.cash
    _chk(Game.buy_item("water") and Game.cash == cash0 - 5, "buy water costs exactly 5 cash")
    Game.cash = 0
    var bal1 := Game.balance
    _chk(Game.buy_item("coffee") and Game.balance == bal1 - 12, "buy coffee from bank when no cash")
    Game.cash = 0
    Game.balance = 0
    _chk(not Game.buy_item("milk"), "buy rejected without money")
    Game.balance = 500
    Game.cash = 50
    # --- הזמנה וניווט חופשי ---
    var cafe: Dictionary = world.nearest_poi("bank", player.global_position)
    _chk(world.is_reachable(player.global_position, cafe), "bank reachable")
    Game.start_free_nav(cafe)
    await _frames(3)
    _chk(Game.nav_active and Game.nav_free, "free navigation active")
    var last: Vector3 = Game.nav_route[Game.nav_route.size() - 1]
    _chk(last.distance_to(cafe.entry) < 1.0, "route ends at entrance/access point")
    _chk(Game.nav_route.size() > 3, "route follows road graph")
    Game.new_offer()
    _chk(Game.nav_active and Game.nav_free, "new offer does not cancel free nav")
    Game.decline()
    _chk(Game.nav_active and Game.nav_free, "declining offer keeps free nav")
    Game.stop_nav()
    for pg in ["home", "delivery", "map", "bank", "clock", "settings", "msgs", "profile", "vehicle", "history"]:
        set_phone(true, pg)
        await _frames(2)
    set_phone(false)
    Game.new_offer()
    _chk(Game.mission.get("state", "") == "offered", "offer created")
    Game.accept()
    var m: Dictionary = Game.mission
    var rest: Dictionary = world.poi(m.ri, m.rj)
    var home: Dictionary = world.poi(m.hi, m.hj)
    Game.start_nav(rest)
    await _frames(5)
    _chk(Game.nav_route.size() > 1, "route computed")
    player.global_position = Vector3(rest.door.x, 0.3, rest.door.z)
    player.velocity = Vector3.ZERO
    player.speed = 0.0
    await _frames(5)
    var it := current_interaction()
    _chk(it.has("fn"), "pickup interaction available")
    if it.has("fn"):
        it.fn.call()
    await _frames(60)
    _chk(Game.mission.get("state", "") == "to_customer", "picked up")
    Game.start_nav(home)
    await _frames(5)
    player.global_position = Vector3(home.door.x, 0.3, home.door.z)
    player.velocity = Vector3.ZERO
    player.speed = 0.0
    await _frames(5)
    var before := Game.balance
    it = current_interaction()
    _chk(it.has("fn"), "deliver interaction available")
    if it.has("fn"):
        it.fn.call()
    _chk(Game.balance > before, "paid for delivery")
    var after := Game.balance
    _chk(Game.complete_mission().is_empty(), "no double completion")
    _chk(Game.balance == after, "no double payment")
    await _frames(10)
    # --- תנועה ---
    player.global_position = Vector3(8 * World.S, 0.3, 12 * World.S)
    player.velocity = Vector3.ZERO
    player.speed = 0.0
    var start := player.global_position
    Input.action_press("forward")
    await get_tree().create_timer(2.0).timeout
    Input.action_release("forward")
    _chk(player.global_position.distance_to(start) > 1.0, "vehicle moves")
    player.first_person = true
    await _frames(5)
    player.first_person = false
    await _frames(5)
    # ירידה וחזרה לכלי
    player.speed = 0.0
    player.toggle_foot()
    await _frames(5)
    _chk(player.on_foot, "dismounted")
    player.toggle_foot()
    await _frames(5)
    _chk(not player.on_foot, "remounted")
    # --- כלי תחבורה ושדרוגים ---
    Game._tx(20000, "test")
    for k in Game.VEHICLES:
        if not Game.owned.has(k):
            Game.buy_vehicle(k)
        Game.switch_vehicle(k)
        await _frames(5)
        _chk(player.kind == k, "vehicle built: " + k)
    Game.switch_vehicle("ebike")
    await _frames(3)
    for c in Game.COMPANIES:
        Game.company = c
        Game.appearance_changed.emit()
        await _frames(3)
    for u in Game.UPGRADES:
        Game.buy_upgrade(u)
    for q in range(3):
        Game.settings.quality = q
        apply_settings()
    Game.settings.quality = 1
    for dm in range(3):
        Game.settings.display_mode = dm
        apply_settings()
    Game.settings.display_mode = 0
    apply_settings()
    # --- תנועה עירונית ---
    Game.settings.traffic = 3
    await _frames(120)
    var active_cars := 0
    for c in world.traffic.cars:
        if c.active:
            active_cars += 1
    _chk(active_cars > 0, "traffic cars active (%d)" % active_cars)
    # --- שמירה וטעינה ---
    Game.cash = 77
    Game.game_seconds = 15.0 * 3600.0
    var bal := Game.balance
    Game.save_game()
    Game.balance = 0
    Game.cash = 0
    Game.game_seconds = 3.0 * 3600.0
    _chk(Game.load_game(), "save loaded")
    _chk(Game.balance == bal, "balance restored from save")
    _chk(Game.cash == 77, "cash restored from save")
    _chk(absf(Game.game_seconds - 15.0 * 3600.0) < 1.0, "game time restored from save")
    player.global_position = Vector3(20 * World.S, 0.3, 4 * World.S)
    await _frames(90)
    _chk(world.chunks.size() > 0, "streaming after teleport")
    pause_game()
    await _frames(3)
    resume()
    _finish_autotest()


func _finish_autotest() -> void:
    if _at_errors == 0:
        print("AUTOTEST OK")
    else:
        print("AUTOTEST FAILED: ", _at_errors, " errors")
    get_tree().quit(1 if _at_errors > 0 else 0)
