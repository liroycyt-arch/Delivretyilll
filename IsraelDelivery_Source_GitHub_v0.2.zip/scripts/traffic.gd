class_name Traffic
extends Node3D
## תנועה עירונית יעילה: מאגר (pool) קבוע של כלי רכב שנוסעים על גרף הכבישים בנתיב ימני,
## עוצרים ברמזורים, שומרים מרחק, מאטים לפני השחקן, עוצרים למעבר רכבת, ונשארים צמודים לשחקן (מתחדשים מקרוב).
## צפיפות לפי הגדרה ושעה. כלי הרכב הם AnimatableBody3D (השחקן לא עובר דרכם).

const KINDS := 5   # 0 סדאן, 1 האצ'בק, 2 טנדר/ואן, 3 משאית, 4 אוטובוס
const DENSITY := [0, 14, 26, 40]
const COLORS := [Color("e8e8e8"), Color("2b2e33"), Color("c0392b"), Color("2f5d8a"), Color("8d949b"), Color("f2f2f2"), Color("3d6b4f"), Color("d4a017"), Color("7a2f2f"), Color("b0b6bb")]
const LANE := 3.0
const CORNER := 7.0
const SIZES := [Vector3(1.8, 1.4, 4.4), Vector3(1.8, 1.5, 3.9), Vector3(2.0, 2.1, 5.0), Vector3(2.4, 3.0, 7.0), Vector3(2.5, 3.2, 11.0)]

var world = null
var cars: Array = []
var _variants: Array = []
var _t := 0.0
var _active_target := 0
var _built := false
var _rng := RandomNumberGenerator.new()


static func random_color(rng: RandomNumberGenerator) -> Color:
    return COLORS[rng.randi() % COLORS.size()]


## גיאומטריה של רכב (חזית ב-Z שלילי). origin+rot_y מיקום וכיוון; solid=מוסיף התנגשות.
static func add_car(b: MeshBatch, kind: int, col: Color, origin: Vector3, rot_y: float, solid: bool) -> void:
    var sz: Vector3 = SIZES[clampi(kind, 0, KINDS - 1)]
    var rb := Basis(Vector3.UP, rot_y)
    var w := sz.x
    var h := sz.y
    var l := sz.z
    var body_h := h * 0.5
    _p(b, "solid", rb, origin, Vector3(0, 0.35 + body_h * 0.5, 0), Vector3(w, body_h, l), col, rot_y)
    var cab_h := h - body_h - 0.3
    var cab_l := l * 0.5
    var cab_z := l * 0.05
    var glass := Color(0.12, 0.17, 0.22)
    if kind == 2:
        cab_l = l * 0.85
        cab_z = l * 0.1
    elif kind == 3:
        cab_l = l * 0.28
        cab_z = -l * 0.32
    elif kind == 4:
        cab_l = l * 0.95
        cab_z = 0.0
    var cy := 0.35 + body_h + cab_h * 0.5
    _p(b, "glass_dark", rb, origin, Vector3(0, cy, cab_z), Vector3(w * 0.92, cab_h, cab_l), glass, rot_y)
    _p(b, "solid", rb, origin, Vector3(0, cy + cab_h * 0.5 + 0.03, cab_z), Vector3(w * 0.95, 0.07, cab_l * 0.96), col, rot_y)
    if kind == 3:
        _p(b, "solid", rb, origin, Vector3(0, 0.35 + h * 0.5, l * 0.18), Vector3(w, h - 0.4, l * 0.55), col.lightened(0.15), rot_y)
    if kind == 4:
        _p(b, "solid", rb, origin, Vector3(0, 0.9, 0), Vector3(w + 0.02, 0.5, l), Color("2f8f5b"), rot_y)
    for sx in [-1.0, 1.0]:
        for sz2 in [-0.33, 0.33]:
            _p(b, "solid", rb, origin, Vector3(sx * (w * 0.5), 0.3, sz2 * l * (1.2 if kind >= 3 else 1.0)), Vector3(0.22, 0.6, 0.6), Color("141414"), rot_y)
        _p(b, "carlight", rb, origin, Vector3(sx * w * 0.33, 0.62, -l * 0.5 - 0.01), Vector3(0.3, 0.16, 0.05), Color.WHITE, rot_y)
        _p(b, "taillight", rb, origin, Vector3(sx * w * 0.33, 0.62, l * 0.5 + 0.01), Vector3(0.3, 0.16, 0.05), Color.WHITE, rot_y)
    if solid:
        b.solids.append([origin + Vector3(0, sz.y * 0.5 + 0.2, 0), Vector3(sz.x, sz.y, sz.z), rot_y])


static func _p(b: MeshBatch, key: String, rb: Basis, origin: Vector3, local: Vector3, size: Vector3, col: Color, rot_y: float) -> void:
    b.box(key, origin + rb * local, size, col, rot_y)


func _ready() -> void:
    _rng.randomize()
    process_mode = Node.PROCESS_MODE_PAUSABLE


func _build_pool() -> void:
    _built = true
    var keys := ["solid", "glass_dark", "carlight", "taillight"]
    for kind in range(KINDS):
        for ci in range(4 if kind < 3 else 2):
            var b := MeshBatch.new()
            var col: Color = COLORS[(kind * 3 + ci * 2) % COLORS.size()]
            if kind == 4:
                col = Color("e8e8e8")
            add_car(b, kind, col, Vector3.ZERO, 0.0, false)
            _variants.append({"kind": kind, "mesh": b.to_mesh(keys, world.mats)})
    for k in range(DENSITY[3]):
        var v: Dictionary = _variants[(k * 7 + (k % 5)) % _variants.size()]
        if k % 11 == 0:
            v = _variants[_variants.size() - 1 - (k % 3)]
        var body := AnimatableBody3D.new()
        body.sync_to_physics = false
        var mi := MeshInstance3D.new()
        mi.mesh = v.mesh
        body.add_child(mi)
        var sz: Vector3 = SIZES[int(v.kind)]
        var cs := CollisionShape3D.new()
        var sh := BoxShape3D.new()
        sh.size = sz
        cs.shape = sh
        cs.position = Vector3(0, sz.y * 0.5 + 0.2, 0)
        body.add_child(cs)
        body.visible = false
        body.collision_layer = 0
        add_child(body)
        var d := {"node": body, "kind": int(v.kind), "active": false, "a": Vector2i.ZERO, "b": Vector2i.ZERO, "next": Vector2i.ZERO,
            "mode": 0, "d": 0.0, "u": 0.0, "v": 0.0, "vmax": 10.0 + _rng.randf() * 3.0, "wait": 0.0, "pos": Vector3.ZERO}
        if int(v.kind) == 4:
            d.vmax = 9.0
        elif int(v.kind) == 3:
            d.vmax = 10.0
        cars.append(d)


func target_count() -> int:
    var q := int(Game.settings.get("traffic", 1))
    var base: int = DENSITY[clampi(q, 0, 3)]
    var h: float = Game.hour_float()
    var f := 1.0
    if h >= 22.5 or h < 5.5:
        f = 0.3
    elif (h >= 7.0 and h < 9.5) or (h >= 16.0 and h < 19.0):
        f = 1.0
    elif h < 7.0 or h >= 19.0:
        f = 0.6
    else:
        f = 0.8
    return int(round(base * f))


func _moves(i: int, j: int, from_dir: Vector2i) -> Array:
    var out: Array = []
    var N: int = World.N
    # מזרח
    if i < N and int(World.ONEWAY_H.get(j, 0)) >= 0:
        out.append(Vector2i(i + 1, j))
    if i > 0 and int(World.ONEWAY_H.get(j, 0)) == 0:
        out.append(Vector2i(i - 1, j))
    if j < N and int(World.ONEWAY_V.get(i, 0)) >= 0:
        out.append(Vector2i(i, j + 1))
    if j > 0 and int(World.ONEWAY_V.get(i, 0)) == 0:
        out.append(Vector2i(i, j - 1))
    var res: Array = []
    for m in out:
        var dv: Vector2i = m - Vector2i(i, j)
        if dv == -from_dir:
            continue
        res.append(m)
    if res.is_empty():
        res = out
    return res


func _dir(a: Vector2i, b: Vector2i) -> Vector2:
    return Vector2(b.x - a.x, b.y - a.y).normalized()


func _node_pos(n: Vector2i) -> Vector3:
    return Vector3(n.x * World.S, 0.0, n.y * World.S)


func _straight_pos(c: Dictionary, d: float) -> Vector3:
    var f := _dir(c.a, c.b)
    var r := Vector2(-f.y, f.x)
    var p: Vector3 = _node_pos(c.a)
    return p + Vector3((f.x * (CORNER + d)) + r.x * LANE, 0.0, (f.y * (CORNER + d)) + r.y * LANE)


func _spawn(c: Dictionary, near: Vector3) -> bool:
    var N: int = World.N
    for _t2 in range(20):
        var ang := _rng.randf() * TAU
        var dist := _rng.randf_range(90.0, 320.0)
        var p := near + Vector3(cos(ang) * dist, 0, sin(ang) * dist)
        var i := clampi(roundi(p.x / World.S), 0, N)
        var j := clampi(roundi(p.z / World.S), 0, N)
        var ms := _moves(i, j, Vector2i.ZERO)
        if ms.is_empty():
            continue
        var m: Vector2i = ms[_rng.randi() % ms.size()]
        c.a = Vector2i(i, j)
        c.b = m
        c.mode = 0
        c.d = _rng.randf_range(0.0, World.S - 2.0 * CORNER - 4.0)
        c.v = 0.0
        c.wait = 0.0
        var pos := _straight_pos(c, c.d)
        var clash := false
        for o in cars:
            if o != c and o.active and (o.pos as Vector3).distance_to(pos) < 12.0:
                clash = true
                break
        if clash:
            continue
        if pos.distance_to(near) < 60.0:
            continue
        c.pos = pos
        return true
    return false


func _physics_process(delta: float) -> void:
    if world == null or Game.player == null or not is_instance_valid(Game.player):
        return
    if not _built:
        _build_pool()
    var player: Node3D = Game.player
    var pp: Vector3 = player.global_position
    _t += delta
    _active_target = target_count()
    var active := 0
    for c in cars:
        if c.active:
            active += 1
    # הפעלה / כיבוי הדרגתי
    if active < _active_target:
        for c in cars:
            if not c.active and _spawn(c, pp):
                c.active = true
                c.node.visible = true
                c.node.collision_layer = 1
                break
    elif active > _active_target:
        for c in cars:
            if c.active and (c.pos as Vector3).distance_to(pp) > 150.0:
                c.active = false
                c.node.visible = false
                c.node.collision_layer = 0
                break
    var by_edge := {}
    for c in cars:
        if c.active and int(c.mode) == 0:
            var key := Vector4i(c.a.x, c.a.y, c.b.x, c.b.y)
            if not by_edge.has(key):
                by_edge[key] = []
            by_edge[key].append(c)
    for c in cars:
        if not c.active:
            continue
        if (c.pos as Vector3).distance_to(pp) > 380.0:
            if not _spawn(c, pp):
                c.active = false
                c.node.visible = false
                c.node.collision_layer = 0
            continue
        _step(c, delta, pp, player, by_edge)


func _step(c: Dictionary, delta: float, pp: Vector3, player: Node3D, by_edge: Dictionary) -> void:
    var f := _dir(c.a, c.b)
    var seg_len: float = World.S - 2.0 * CORNER
    var target: float = c.vmax
    var accel := 3.0
    var heading_vec := Vector3(f.x, 0, f.y)
    if int(c.mode) == 0:
        var d: float = c.d
        # רכב מלפנים באותו נתיב
        var key := Vector4i(c.a.x, c.a.y, c.b.x, c.b.y)
        var lead_gap := 1e9
        for o in by_edge.get(key, []):
            if o != c and float(o.d) > d:
                lead_gap = minf(lead_gap, float(o.d) - d)
        var self_len: float = (SIZES[int(c.kind)] as Vector3).z
        var need := 6.0 + self_len + float(c.v) * 0.8
        if lead_gap < need:
            target = 0.0
        elif lead_gap < need * 2.5:
            target = minf(target, 5.0)
        # רמזור בסוף הקטע
        var axis := 0 if absf(f.x) > 0.5 else 1
        var st: int = world.signal_state(axis)
        var to_stop := seg_len - d
        if st != 2 and to_stop > -0.5:
            var brake_d := (float(c.v) * float(c.v)) / (2.0 * 6.0) + 1.5
            if st == 0 or to_stop > brake_d:
                if to_stop < maxf(brake_d, 14.0):
                    target = minf(target, maxf(0.0, (to_stop - 0.8) * 0.9))
        # מעבר רכבת (בין עמודות RAIL_I ו-RAIL_I+1 בשורה j)
        if absf(f.x) > 0.5 and mini(c.a.x, c.b.x) == World.RAIL_I and world.train_blocks_row(c.a.y):
            if d < 16.0:
                target = minf(target, maxf(0.0, (15.0 - d) * 0.8))
        # השחקן מלפנים
        var pl := pp - (c.pos as Vector3)
        var fwd := heading_vec.dot(pl)
        if fwd > 0.0 and fwd < 12.0 + float(c.v) * 0.6:
            var lat := absf(Vector3(-heading_vec.z, 0, heading_vec.x).dot(pl))
            if lat < 2.6:
                target = 0.0
        if target < float(c.v):
            accel = 8.0
        c.v = move_toward(float(c.v), target, accel * delta)
        c.d = d + float(c.v) * delta
        if float(c.d) >= seg_len:
            # בחירת המשך והתחלת פנייה
            var ms := _moves(c.b.x, c.b.y, Vector2i(roundi(f.x), roundi(f.y)))
            c.next = ms[_rng.randi() % ms.size()]
            c.mode = 1
            c.u = 0.0
        c.pos = _straight_pos(c, minf(float(c.d), seg_len))
        _apply(c, heading_vec)
    else:
        var f2 := _dir(c.b, c.next)
        var r1 := Vector2(-f.y, f.x)
        var r2 := Vector2(-f2.y, f2.x)
        var nb: Vector3 = _node_pos(c.b)
        var s1 := nb + Vector3(-f.x * CORNER + r1.x * LANE, 0, -f.y * CORNER + r1.y * LANE)
        var s2 := nb + Vector3(f2.x * CORNER + r2.x * LANE, 0, f2.y * CORNER + r2.y * LANE)
        var ctrl := (s1 + s2) * 0.5
        if f.distance_to(f2) > 0.1:
            ctrl = nb + Vector3(r1.x * LANE + r2.x * LANE, 0, r1.y * LANE + r2.y * LANE)
        var arc := maxf(8.0, s1.distance_to(ctrl) + ctrl.distance_to(s2))
        target = minf(target, 6.0 if f.distance_to(f2) > 0.1 else target)
        c.v = move_toward(float(c.v), target, accel * delta)
        c.u = float(c.u) + float(c.v) * delta / arc
        var u := minf(float(c.u), 1.0)
        var pos: Vector3 = s1.lerp(ctrl, u).lerp(ctrl.lerp(s2, u), u)
        var tan_v: Vector3 = (ctrl - s1).lerp(s2 - ctrl, u)
        c.pos = pos
        if tan_v.length() > 0.01:
            _apply(c, tan_v.normalized())
        if float(c.u) >= 1.0:
            c.a = c.b
            c.b = c.next
            c.mode = 0
            c.d = 0.0
    (c.node as Node3D).global_position = c.pos


func _apply(c: Dictionary, dirv: Vector3) -> void:
    var n: Node3D = c.node
    n.rotation.y = atan2(-dirv.x, -dirv.z)
