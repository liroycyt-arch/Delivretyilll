extends Node
## מצב גלובלי: כסף ובנק (מקור אמת יחיד), שמירה, משימות, ניווט.

signal notify(text)
signal sfx(sound_name)
signal money_changed
signal mission_changed
signal appearance_changed
signal boost_changed

## --- שעון משחק: שנייה אמיתית = דקה במשחק (מבוסס על זמן שעבר בפועל, לא על פריימים) ---
const TIME_SCALE := 60.0            # דקות משחק לשנייה אמיתית
const DAY_SECONDS := 86400.0
const BOOST_DURATION := 5.0
const BOOST_COOLDOWN := 15.0
const SHOP_ITEMS := {
    "water": {"name": "מים", "price": 5},
    "milk": {"name": "חלב", "price": 8},
    "coffee": {"name": "קפה", "price": 12},
    "candy": {"name": "ממתק", "price": 4},
    "icecream": {"name": "גלידה", "price": 8},
}

const SAVE_VERSION := 2
const SAVE_PATH := "user://save.json"
const SAVE_BAK := "user://save.bak.json"

const VEHICLES := {
    "ebike": {"name": "אופניים חשמליים", "max": 40.0, "accel": 6, "handling": 8, "comfort": 7, "reliab": 7, "maint": "נמוכה", "rate": 3.0, "price": 1500},
    "scooter": {"name": "קורקינט חשמלי", "max": 45.0, "accel": 8, "handling": 9, "comfort": 5, "reliab": 6, "maint": "נמוכה", "rate": 3.0, "price": 1800},
    "moped": {"name": "קטנוע", "max": 55.0, "accel": 5, "handling": 6, "comfort": 6, "reliab": 5, "maint": "בינונית", "rate": 6.0, "price": 1200},
    "motorcycle": {"name": "אופנוע קטן", "max": 65.0, "accel": 7, "handling": 7, "comfort": 6, "reliab": 8, "maint": "גבוהה", "rate": 9.0, "price": 6500},
}
const UPGRADES := {
    "brakes": {"name": "בלמים", "costs": [150, 300, 600], "desc": "בלימה חזקה יותר"},
    "battery": {"name": "סוללה", "costs": [200, 400, 800], "desc": "מהירות מרבית גבוהה יותר"},
    "tires": {"name": "צמיגים", "costs": [120, 250, 500], "desc": "היגוי ויציבות טובים יותר"},
    "light": {"name": "תאורה", "costs": [80, 160, 320], "desc": "פנס חזק יותר בשעות החשיכה"},
}
const COMPANIES := {"mishloha": "משלוחה", "wolt": "וולט", "indie": "שליח עצמאי"}
const RANKS := [["שליח מתחיל", 0], ["שליח פעיל", 5], ["שליח מנוסה", 15], ["שליח מקצועי", 30], ["שליח מצטיין", 60]]

var world = null
var player = null
var font: Font

var has_save := false
var player_name := "שליח"
var company := "mishloha"
var vehicle := "ebike"
var owned: Array = ["ebike"]
var look := {"skin": 1, "hair_color": 0, "hair_style": 0, "body": 1, "helmet": 0, "shorts": false}
var upgrades := {}
var balance := 100        # יתרת בנק
var cash := 50            # מזומן
var inventory := {}
var game_seconds := 8.0 * 3600.0   # שעה במשחק (שניות משחק מתחילת יום), מתחיל ב-08:00
var _clock_msec := 0
var boost_t := 0.0        # זמן Boost שנותר
var boost_cd := 0.0       # זמן המתנה שנותר
var nav_free := false     # ניווט חופשי (לא קשור להזמנה)
var total_income := 0
var total_spent := 0
var ledger: Array = []
var history: Array = []
var messages: Array = []
var stats := {}
var last_pos := Vector3(8 * 64.0, 0.3, 12 * 64.0)
var last_heading := 0.0
var settings := {}
var mission := {}
var paid_ids: Array = []
var next_mission_id := 1

var nav_active := false
var nav_poi := {}
var nav_route := PackedVector3Array()
var nav_idx := 0
var nav_text := ""
var nav_remaining := 0.0
var _nav_t := 0.0


func _ready() -> void:
    setup_inputs()
    font = load_font()
    reset_new()
    load_game()


func setup_inputs() -> void:
    var map := {
        "forward": [KEY_W, KEY_UP], "back": [KEY_S, KEY_DOWN], "left": [KEY_A, KEY_LEFT], "right": [KEY_D, KEY_RIGHT],
        "brake": [KEY_SPACE], "boost": [KEY_SHIFT, KEY_B], "dismount": [KEY_F], "interact": [KEY_E], "map": [KEY_M], "phone": [KEY_P], "cam": [KEY_C], "pause": [KEY_ESCAPE],
    }
    for a in map:
        if not InputMap.has_action(a):
            InputMap.add_action(a)
        for k in map[a]:
            var ev := InputEventKey.new()
            ev.physical_keycode = k
            InputMap.action_add_event(a, ev)


func load_font() -> Font:
    for p in ["res://fonts/Rubik.ttf", "res://fonts/Rubik-Regular.ttf", "res://fonts/Heebo.ttf"]:
        if ResourceLoader.exists(p):
            return load(p)
    var sf := SystemFont.new()
    sf.font_names = PackedStringArray(["Rubik", "Heebo", "Assistant", "Segoe UI", "Arial", "Tahoma"])
    return sf


func default_settings() -> Dictionary:
    return {"volume": 0.8, "fov": 75.0, "time": 12.0, "quality": 1, "shadows": true, "fps": 60, "fullscreen": false, "notify_sec": 4.0, "mute_notify": false, "voice": false,
        "display_mode": 0, "resolution": 1, "traffic": 1, "cam_sens": 1.0, "cam_zoom": 1.0, "cam_invert_y": false}


func sanitize_name(s: String) -> String:
    var re := RegEx.new()
    re.compile("[^\\p{L}\\p{N} '\\-]")
    var t := re.sub(s, "", true).strip_edges().substr(0, 16)
    return t if t != "" else "שליח"


func reset_new() -> void:
    player_name = "שליח"
    company = "mishloha"
    vehicle = "ebike"
    owned = ["ebike"]
    look = {"skin": 1, "hair_color": 0, "hair_style": 0, "body": 1, "helmet": 0, "shorts": false}
    upgrades = {}
    for k in VEHICLES:
        upgrades[k] = {"brakes": 0, "battery": 0, "tires": 0, "light": 0}
    balance = 100
    cash = 50
    inventory = {}
    game_seconds = 8.0 * 3600.0
    boost_t = 0.0
    boost_cd = 0.0
    nav_free = false
    total_income = 0
    total_spent = 0
    ledger = []
    history = []
    messages = []
    stats = {"done": 0, "declined": 0, "on_time": 0, "dist": 0.0, "time_sum": 0.0, "by_veh": {}}
    last_pos = Vector3(8 * 64.0, 0.3, 12 * 64.0)
    last_heading = 0.0
    mission = {}
    paid_ids = []
    next_mission_id = 1
    stop_nav()
    if settings.is_empty():
        settings = default_settings()


func rank_index() -> int:
    var idx := 0
    for i in range(RANKS.size()):
        if int(stats.get("done", 0)) >= RANKS[i][1]:
            idx = i
    return idx


func rank_name() -> String:
    return RANKS[rank_index()][0]


func vehicle_stats() -> Dictionary:
    var v: Dictionary = VEHICLES[vehicle]
    var u: Dictionary = upgrades[vehicle]
    return {
        "max_ms": (float(v.max) + 1.5 * u.battery) / 3.6,
        "accel": 1.0 + float(v.accel) * 0.35,
        "brake": 5.0 + 1.5 * u.brakes + float(v.handling) * 0.2,
        "turn": 1.1 + float(v.handling) * 0.1 + 0.08 * u.tires,
        "comfort": v.comfort,
        "light": u.light,
    }


# ---------- שעון משחק ----------
## זמן משחק מחושב מהזמן האמיתי שחלף (Time.get_ticks_msec), לא מתוספת קבועה בכל פריים.
func clock_resume() -> void:
    _clock_msec = Time.get_ticks_msec()


func clock_update() -> void:
    var now := Time.get_ticks_msec()
    if _clock_msec == 0:
        _clock_msec = now
    var real_dt := clampf(float(now - _clock_msec) / 1000.0, 0.0, 5.0)
    _clock_msec = now
    game_seconds = fposmod(game_seconds + real_dt * TIME_SCALE, DAY_SECONDS)


func hour_float() -> float:
    return game_seconds / 3600.0


func time_string() -> String:
    var total_min := int(game_seconds / 60.0) % 1440
    return "%02d:%02d" % [total_min / 60, total_min % 60]


func is_night() -> bool:
    var h := hour_float()
    return h < 5.5 or h >= 19.5


# ---------- Boost ----------
func boost_state() -> String:
    if boost_t > 0.0:
        return "active"
    if boost_cd > 0.0:
        return "cooldown"
    return "ready"


func try_boost() -> bool:
    if boost_state() != "ready":
        return false
    boost_t = BOOST_DURATION
    boost_cd = BOOST_COOLDOWN
    sfx.emit("boost")
    boost_changed.emit()
    return true


func tick_boost(delta: float) -> void:
    var was := boost_state()
    if boost_t > 0.0:
        boost_t = maxf(0.0, boost_t - delta)
    elif boost_cd > 0.0:
        boost_cd = maxf(0.0, boost_cd - delta)
    if boost_state() != was:
        boost_changed.emit()


## גורם הגברה הדרגתי: עולה מהר בתחילת ה-Boost ויורד בהדרגה בסופו (בלי קפיצת מהירות מיידית).
func boost_factor() -> float:
    if boost_t <= 0.0:
        return 1.0
    var ramp_in := clampf((BOOST_DURATION - boost_t) / 0.5, 0.0, 1.0)
    var ramp_out := clampf(boost_t / 1.0, 0.0, 1.0)
    return 1.0 + 0.30 * minf(ramp_in, ramp_out)


# ---------- בנק ומזומן (מקור אמת יחיד: Game) ----------
func deposit(amount: int) -> bool:
    if amount <= 0:
        notify.emit("סכום לא תקין")
        sfx.emit("error")
        return false
    if amount > cash:
        notify.emit("אין מספיק מזומן להפקדה")
        sfx.emit("error")
        return false
    cash -= amount
    _tx_bank(amount, "הפקדת מזומן")
    notify.emit("הופקדו %d ₪ בחשבון" % amount)
    sfx.emit("atm")
    save_game()
    return true


func withdraw(amount: int) -> bool:
    if amount <= 0:
        notify.emit("סכום לא תקין")
        sfx.emit("error")
        return false
    if amount > balance:
        notify.emit("אין מספיק כסף בחשבון")
        sfx.emit("error")
        return false
    cash += amount
    _tx_bank(-amount, "משיכת מזומן")
    notify.emit("נמשכו %d ₪ מהחשבון" % amount)
    sfx.emit("atm")
    save_game()
    return true


## תנועת בנק פנימית שאינה הכנסה/הוצאה אמיתית (הפקדה/משיכה) ולכן לא נספרת בסך ההכנסות וההוצאות.
func _tx_bank(amount: int, reason: String) -> void:
    balance += amount
    ledger.append({"t": Time.get_unix_time_from_system(), "a": amount, "r": reason})
    if ledger.size() > 200:
        ledger = ledger.slice(ledger.size() - 200)
    money_changed.emit()


# ---------- סופרמרקט ----------
## תשלום: קודם במזומן; אם אין מספיק מזומן - בכרטיס מהבנק; אחרת הקנייה נדחית.
func buy_item(key: String) -> bool:
    if not SHOP_ITEMS.has(key):
        return false
    var it: Dictionary = SHOP_ITEMS[key]
    var price := int(it.price)
    if cash >= price:
        cash -= price
        total_spent += price
        money_changed.emit()
    elif balance >= price:
        _tx(-price, "קנייה: " + str(it.name))
    else:
        notify.emit("אין מספיק כסף לקנות %s (%d ₪)" % [it.name, price])
        sfx.emit("error")
        return false
    inventory[key] = int(inventory.get(key, 0)) + 1
    notify.emit("נקנה: %s — %d ₪" % [it.name, price])
    sfx.emit("shop")
    save_game()
    return true


# ---------- כסף: כל שינוי יתרה עובר רק כאן ----------
func _tx(amount: int, reason: String) -> void:
    balance += amount
    if amount > 0:
        total_income += amount
    else:
        total_spent += -amount
    ledger.append({"t": Time.get_unix_time_from_system(), "a": amount, "r": reason})
    if ledger.size() > 200:
        ledger = ledger.slice(ledger.size() - 200)
    money_changed.emit()


func spend(amount: int, reason: String) -> bool:
    if balance < amount:
        notify.emit("אין מספיק כסף בחשבון")
        sfx.emit("error")
        return false
    _tx(-amount, reason)
    return true


func switch_vehicle(k: String) -> void:
    if owned.has(k):
        vehicle = k
        appearance_changed.emit()


func buy_vehicle(k: String) -> bool:
    if owned.has(k):
        return false
    if spend(int(VEHICLES[k].price), "רכישת " + VEHICLES[k].name):
        owned.append(k)
        vehicle = k
        notify.emit("נפתח כלי תחבורה חדש: " + VEHICLES[k].name)
        appearance_changed.emit()
        save_game()
        return true
    return false


func buy_upgrade(key: String) -> bool:
    var lvl: int = upgrades[vehicle][key]
    var costs: Array = UPGRADES[key].costs
    if lvl >= costs.size():
        return false
    if spend(int(costs[lvl]), "שדרוג " + UPGRADES[key].name):
        upgrades[vehicle][key] = lvl + 1
        notify.emit("שודרג: %s (רמה %d)" % [UPGRADES[key].name, lvl + 1])
        save_game()
        return true
    return false


func push_msg(from: String, text: String) -> void:
    messages.append({"from": from, "text": text})
    if messages.size() > 60:
        messages = messages.slice(messages.size() - 60)


# ---------- משימות ----------
func new_offer() -> void:
    if not mission.is_empty() or world == null or player == null:
        return
    var rest: Dictionary = world.random_poi("restaurant", player.global_position, 500.0)
    var home: Dictionary = world.random_poi("home", rest.door, 650.0)
    var dist: float = rest.door.distance_to(home.door)
    var to_rest: float = player.global_position.distance_to(rest.door)
    var pay := roundi(16.0 + dist * 0.035 + rank_index())
    var leave := randf() < 0.35
    mission = {
        "id": "m%d" % next_mission_id, "state": "offered",
        "ri": rest.i, "rj": rest.j, "hi": home.i, "hj": home.j,
        "pay": pay, "bonus": roundi(pay * 0.25), "dist": dist, "to_rest": to_rest,
        "limit": int(75.0 + (to_rest + dist) * 1.5 / 5.5), "elapsed": 0.0, "age": 0.0,
        "leave": leave, "note": "השאר ליד הדלת" if leave else "מסירה ללקוח ביד",
    }
    next_mission_id += 1
    notify.emit("התקבלה הזמנה חדשה")
    sfx.emit("offer")
    push_msg("משלוחים", "הזמנה חדשה מ%s ליעד %s" % [rest.name, home.addr])
    mission_changed.emit()


func accept() -> void:
    if mission.get("state", "") != "offered":
        return
    mission.state = "to_pickup"
    mission.elapsed = 0.0
    notify.emit("המשלוח התקבל. יעד האיסוף סומן במפה")
    mission_changed.emit()


func decline() -> void:
    if mission.get("state", "") != "offered":
        return
    stats.declined = int(stats.declined) + 1
    mission = {}
    notify.emit("המשלוח נדחה")
    mission_changed.emit()


func pickup() -> void:
    if mission.get("state", "") != "to_pickup":
        return
    mission.state = "to_customer"
    _stop_mission_nav()
    notify.emit("המשלוח נאסף בהצלחה")
    sfx.emit("pickup")
    push_msg("מסעדה", "ההזמנה נמסרה לשליח. בהצלחה!")
    mission_changed.emit()


func cancel_mission() -> void:
    if mission.is_empty():
        return
    mission = {}
    _stop_mission_nav()
    notify.emit("המשלוח בוטל. לא שולם תשלום")
    mission_changed.emit()


func complete_mission() -> Dictionary:
    if mission.get("state", "") != "to_customer":
        return {}
    var m: Dictionary = mission
    mission = {}
    if paid_ids.has(m.id):
        mission_changed.emit()
        return {}
    paid_ids.append(m.id)
    if paid_ids.size() > 300:
        paid_ids = paid_ids.slice(paid_ids.size() - 300)
    var on_time: bool = float(m.elapsed) <= float(m.limit)
    var pay_total := 0
    if on_time:
        _tx(int(m.pay), "תשלום משלוח")
        _tx(int(m.bonus), "בונוס עמידה בזמן")
        pay_total = int(m.pay) + int(m.bonus)
    else:
        pay_total = roundi(int(m.pay) * 0.8)
        _tx(pay_total, "תשלום מופחת (איחור)")
    var v: Dictionary = VEHICLES[vehicle]
    var km: float = float(m.dist) * 1.4 / 1000.0
    var cost := maxi(1, roundi(km * float(v.rate) * (1.0 + (10.0 - float(v.reliab)) * 0.08)))
    _tx(-cost, "עלות תחזוקה")
    var rest: Dictionary = world.poi(m.ri, m.rj)
    var home: Dictionary = world.poi(m.hi, m.hj)
    var prev_rank := rank_index()
    stats.done = int(stats.done) + 1
    if on_time:
        stats.on_time = int(stats.on_time) + 1
    stats.dist = float(stats.dist) + float(m.dist)
    stats.time_sum = float(stats.time_sum) + float(m.elapsed)
    stats.by_veh[vehicle] = int(stats.by_veh.get(vehicle, 0)) + 1
    history.append({"rest": rest.name, "addr": home.addr, "pay": pay_total, "on_time": on_time, "time": int(m.elapsed), "veh": vehicle})
    if history.size() > 60:
        history = history.slice(history.size() - 60)
    notify.emit("המשלוח הושלם")
    notify.emit("הועבר תשלום לחשבון שלך: %d ₪" % pay_total)
    sfx.emit("done")
    if rank_index() > prev_rank:
        notify.emit("הושגה דרגה חדשה: " + rank_name())
    push_msg("לקוח", "תודה רבה על המשלוח!")
    _stop_mission_nav()
    mission_changed.emit()
    save_game()
    return {"pay": pay_total, "on_time": on_time, "cost": cost, "time": int(m.elapsed), "rest": rest.name, "addr": home.addr}


func tick(delta: float) -> void:
    if not mission.is_empty():
        var st: String = mission.state
        if st == "offered":
            mission.age = float(mission.age) + delta
            if float(mission.age) > 35.0:
                mission = {}
                notify.emit("ההזמנה פגה")
                mission_changed.emit()
        else:
            mission.elapsed = float(mission.elapsed) + delta
    tick_boost(delta)
    tick_nav(delta)


# ---------- ניווט ----------
## ניווט להזמנה (איסוף/מסירה). מחליף מסלול קיים רק בפעולה מפורשת של השחקן.
func start_nav(poi: Dictionary) -> void:
    nav_free = false
    _begin_nav(poi)


## ניווט חופשי: יעד שהשחקן בחר במפה. לא מושפע מקבלה/דחייה/ביטול של הזמנות.
func start_free_nav(poi: Dictionary) -> void:
    nav_free = true
    _begin_nav(poi)


func _stop_mission_nav() -> void:
    if not nav_free:
        stop_nav()


func _begin_nav(poi: Dictionary) -> void:
    if player == null or world == null:
        return
    nav_poi = poi
    nav_active = true
    _recalc()
    notify.emit("הניווט החל: " + str(poi.name))


func stop_nav() -> void:
    nav_active = false
    nav_free = false
    nav_poi = {}
    nav_route = PackedVector3Array()
    nav_text = ""
    nav_remaining = 0.0


func _recalc() -> void:
    nav_route = world.route(player.global_position, nav_poi)
    nav_idx = 0
    _nav_t = 0.0


func tick_nav(delta: float) -> void:
    if not nav_active or player == null or nav_route.size() == 0:
        return
    var p: Vector3 = player.global_position
    var last := nav_route.size() - 1
    while nav_idx < last and _d2(p, nav_route[nav_idx]) < 16.0:
        nav_idx += 1
    _nav_t += delta
    if _nav_t > 2.0 and _d2(p, nav_route[mini(nav_idx, last)]) > 110.0:
        _recalc()
        return
    var rem := _d2(p, nav_route[nav_idx])
    for k in range(nav_idx, last):
        rem += _d2(nav_route[k], nav_route[k + 1])
    nav_remaining = rem
    if nav_idx >= last:
        nav_text = "היעד לפניך"
        if rem < 9.0 and str(nav_poi.get("kind", "")) != "":
            if nav_free or mission.is_empty():
                notify.emit("הגעת ליעד")
                stop_nav()
        return
    var wp: Vector3 = nav_route[nav_idx]
    var nxt: Vector3 = nav_route[nav_idx + 1]
    var din := Vector2(wp.x - p.x, wp.z - p.z)
    if nav_idx > 0:
        din = Vector2(wp.x - nav_route[nav_idx - 1].x, wp.z - nav_route[nav_idx - 1].z)
    var dout := Vector2(nxt.x - wp.x, nxt.z - wp.z)
    var ang := din.angle_to(dout)
    var turn := "המשך ישר"
    if ang > 0.6:
        turn = "פנה ימינה"
    elif ang < -0.6:
        turn = "פנה שמאלה"
    nav_text = "בעוד %d מ׳ %s אל %s" % [roundi(_d2(p, wp)), turn, world.street_name(wp, nxt)]


func _d2(a: Vector3, b: Vector3) -> float:
    return Vector2(a.x - b.x, a.z - b.z).length()


# ---------- שמירה ----------
func to_dict() -> Dictionary:
    var m := {}
    if not mission.is_empty() and mission.state != "offered":
        m = mission
    return {
        "name": player_name, "company": company, "vehicle": vehicle, "owned": owned, "look": look,
        "cash": cash, "inventory": inventory, "game_seconds": game_seconds,
        "upgrades": upgrades, "balance": balance, "income": total_income, "spent": total_spent,
        "ledger": ledger, "history": history, "messages": messages, "stats": stats,
        "pos": [last_pos.x, last_pos.y, last_pos.z], "heading": last_heading,
        "settings": settings, "mission": m, "paid": paid_ids, "next_id": next_mission_id,
    }


func save_game() -> void:
    var txt := JSON.stringify({"version": SAVE_VERSION, "data": to_dict()})
    var f := FileAccess.open("user://save.json.tmp", FileAccess.WRITE)
    if f == null:
        return
    f.store_string(txt)
    f.close()
    var da := DirAccess.open("user://")
    if da == null:
        return
    if da.file_exists("save.json"):
        da.copy("save.json", "save.bak.json")
        da.remove("save.json")
    da.rename("save.json.tmp", "save.json")
    has_save = true


func load_game() -> bool:
    for path in [SAVE_PATH, SAVE_BAK]:
        if not FileAccess.file_exists(path):
            continue
        var f := FileAccess.open(path, FileAccess.READ)
        if f == null:
            continue
        var parsed = JSON.parse_string(f.get_as_text())
        f.close()
        if parsed is Dictionary and int(parsed.get("version", 0)) >= 1 and int(parsed.get("version", 0)) <= SAVE_VERSION and parsed.get("data") is Dictionary:
            apply_dict(parsed.data)
            has_save = true
            return true
    has_save = false
    return false


func apply_dict(d: Dictionary) -> void:
    reset_new()
    player_name = sanitize_name(str(d.get("name", "שליח")))
    var c := str(d.get("company", "mishloha"))
    company = c if COMPANIES.has(c) else "mishloha"
    var v := str(d.get("vehicle", "ebike"))
    vehicle = v if VEHICLES.has(v) else "ebike"
    var o = d.get("owned", ["ebike"])
    owned = []
    if o is Array:
        for k in o:
            if VEHICLES.has(str(k)) and not owned.has(str(k)):
                owned.append(str(k))
    if owned.is_empty():
        owned = ["ebike"]
    if not owned.has(vehicle):
        vehicle = owned[0]
    var lk = d.get("look", {})
    if lk is Dictionary:
        for k in look.keys():
            if lk.has(k):
                look[k] = lk[k]
    var up = d.get("upgrades", {})
    if up is Dictionary:
        for vk in upgrades.keys():
            var u = up.get(vk, {})
            if u is Dictionary:
                for uk in upgrades[vk].keys():
                    upgrades[vk][uk] = clampi(int(u.get(uk, 0)), 0, 3)
    balance = int(d.get("balance", 100))
    cash = maxi(0, int(d.get("cash", 50)))
    var inv = d.get("inventory", {})
    inventory = {}
    if inv is Dictionary:
        for k in inv:
            if SHOP_ITEMS.has(str(k)):
                inventory[str(k)] = maxi(0, int(inv[k]))
    game_seconds = fposmod(float(d.get("game_seconds", 8.0 * 3600.0)), DAY_SECONDS)
    total_income = int(d.get("income", 0))
    total_spent = int(d.get("spent", 0))
    ledger = d.get("ledger", []) if d.get("ledger") is Array else []
    history = d.get("history", []) if d.get("history") is Array else []
    messages = d.get("messages", []) if d.get("messages") is Array else []
    var st = d.get("stats", {})
    if st is Dictionary:
        for k in stats.keys():
            if st.has(k):
                stats[k] = st[k]
    var pos = d.get("pos", [])
    if pos is Array and pos.size() == 3:
        last_pos = Vector3(float(pos[0]), maxf(0.3, float(pos[1])), float(pos[2]))
    last_heading = float(d.get("heading", 0.0))
    var se = d.get("settings", {})
    if se is Dictionary:
        for k in settings.keys():
            if se.has(k):
                settings[k] = se[k]
    if se is Dictionary and not se.has("display_mode") and bool(se.get("fullscreen", false)):
        settings["display_mode"] = 1   # מיגרציה משמירה ישנה (v1)
    balance = maxi(0, balance)
    paid_ids = d.get("paid", []) if d.get("paid") is Array else []
    next_mission_id = int(d.get("next_id", 1))
    var m = d.get("mission", {})
    mission = {}
    if m is Dictionary and m.get("state", "") in ["to_pickup", "to_customer"] and not paid_ids.has(m.get("id", "")):
        mission = m
