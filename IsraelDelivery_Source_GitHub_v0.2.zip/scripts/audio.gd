class_name CityAudio
extends Node
## אווירה וצלילים מחוללים בקוד (ללא קבצי שמע חיצוניים, ללא בעיות רישוי):
## מנוע לפי מהירות וסוג כלי, המולת עיר (שונה ביום/בלילה), צרצרים בלילה, ציפורים בפארקים ביום, צעדים.

const RATE := 22050

var world = null
var engine: AudioStreamPlayer
var amb: AudioStreamPlayer
var cricket: AudioStreamPlayer
var bird: AudioStreamPlayer
var step: AudioStreamPlayer
var _bird_t := 3.0
var _step_t := 0.0
var _birds: Array = []


func _ready() -> void:
    engine = _loop_player(_saw(100.0, 0.30))
    amb = _loop_player(_noise(0.045, 0.5))
    cricket = _loop_player(_crickets())
    bird = AudioStreamPlayer.new()
    add_child(bird)
    step = AudioStreamPlayer.new()
    step.stream = _click()
    add_child(step)
    for k in range(4):
        _birds.append(_chirp(2600.0 + k * 500.0))
    engine.volume_db = -80.0
    cricket.volume_db = -80.0
    amb.volume_db = -80.0


func _loop_player(w: AudioStreamWAV) -> AudioStreamPlayer:
    var p := AudioStreamPlayer.new()
    p.stream = w
    add_child(p)
    p.play()
    return p


func _wav(data: PackedByteArray, loop: bool) -> AudioStreamWAV:
    var w := AudioStreamWAV.new()
    w.format = AudioStreamWAV.FORMAT_16_BITS
    w.mix_rate = RATE
    w.stereo = false
    w.data = data
    if loop:
        w.loop_mode = AudioStreamWAV.LOOP_FORWARD
        w.loop_begin = 0
        w.loop_end = data.size() / 2
    return w


func _saw(freq: float, amp: float) -> AudioStreamWAV:
    var n := RATE
    var d := PackedByteArray()
    d.resize(n * 2)
    for k in range(n):
        var ph := fmod(freq * float(k) / RATE, 1.0)
        var v := (ph * 2.0 - 1.0) * 0.6 + sin(TAU * freq * 2.0 * k / RATE) * 0.4
        d.encode_s16(k * 2, int(v * amp * 32767.0))
    return _wav(d, true)


func _noise(smooth: float, amp: float) -> AudioStreamWAV:
    var n := RATE * 2
    var d := PackedByteArray()
    d.resize(n * 2)
    var rng := RandomNumberGenerator.new()
    rng.seed = 7
    var y := 0.0
    var first := 0.0
    for k in range(n):
        y += (rng.randf_range(-1.0, 1.0) - y) * smooth
        var out := y
        # הצלבה בסוף כדי שהלולאה לא תקרקש
        if k == 0:
            first = y
        d.encode_s16(k * 2, int(clampf(out * 3.0, -1.0, 1.0) * amp * 32767.0))
    return _wav(d, true)


func _crickets() -> AudioStreamWAV:
    var n := RATE
    var d := PackedByteArray()
    d.resize(n * 2)
    for k in range(n):
        var pulse := 1.0 if fmod(float(k) / RATE * 8.0, 1.0) < 0.35 else 0.0
        var v := sin(TAU * 4400.0 * k / RATE) * pulse * 0.4
        d.encode_s16(k * 2, int(v * 32767.0))
    return _wav(d, true)


func _chirp(f0: float) -> AudioStreamWAV:
    var n := int(RATE * 0.18)
    var d := PackedByteArray()
    d.resize(n * 2)
    var ph := 0.0
    for k in range(n):
        var t := float(k) / n
        ph += TAU * (f0 + sin(t * 18.0) * 500.0) / RATE
        d.encode_s16(k * 2, int(sin(ph) * (1.0 - t) * 0.3 * 32767.0))
    return _wav(d, false)


func _click() -> AudioStreamWAV:
    var n := int(RATE * 0.06)
    var d := PackedByteArray()
    d.resize(n * 2)
    var rng := RandomNumberGenerator.new()
    rng.seed = 3
    for k in range(n):
        var e := 1.0 - float(k) / n
        d.encode_s16(k * 2, int(rng.randf_range(-1.0, 1.0) * e * e * 0.35 * 32767.0))
    return _wav(d, false)


func _db(v: float) -> float:
    return linear_to_db(maxf(0.0001, v))


func tick(delta: float, player: Node, hour_night: float, block_kind: String) -> void:
    var master := float(Game.settings.get("volume", 0.8))
    if player == null or not is_instance_valid(player):
        engine.volume_db = -80.0
        return
    var spd := absf(float(player.speed))
    var k: String = player.kind
    var on_foot: bool = player.on_foot
    # מנוע
    var base := 0.0
    var pitch := 1.0
    match k:
        "ebike":
            base = 0.05
            pitch = 1.6 + spd * 0.05
        "scooter":
            base = 0.07
            pitch = 1.8 + spd * 0.045
        "moped":
            base = 0.22
            pitch = 0.8 + spd * 0.045
        "motorcycle":
            base = 0.3
            pitch = 0.65 + spd * 0.04
    if on_foot:
        base = 0.0
    var run := clampf(spd / 6.0, 0.15, 1.0) if base > 0.0 else 0.0
    if Game.boost_t > 0.0:
        pitch *= 1.15
        run *= 1.2
    engine.pitch_scale = clampf(pitch, 0.5, 4.0)
    engine.volume_db = _db(base * run * master)
    # עיר
    var traffic_n := 0.0
    if world != null and world.traffic != null:
        traffic_n = float(world.traffic.target_count()) / 40.0
    var day := 1.0 - hour_night
    amb.volume_db = _db((0.05 + 0.10 * traffic_n) * (0.35 + 0.65 * day) * master)
    cricket.volume_db = _db(0.07 * hour_night * master) if (block_kind == "park" or block_kind == "home" or block_kind == "beach") else -80.0
    # ציפורים ביום בפארקים
    _bird_t -= delta
    if _bird_t <= 0.0:
        _bird_t = randf_range(2.0, 6.0)
        if day > 0.6 and (block_kind == "park" or block_kind == "sport" or block_kind == "waterpark"):
            bird.stream = _birds[randi() % _birds.size()]
            bird.volume_db = _db(0.3 * master)
            bird.pitch_scale = randf_range(0.9, 1.2)
            bird.play()
    # צעדים
    if on_foot and spd > 0.5:
        _step_t -= delta
        if _step_t <= 0.0:
            _step_t = 0.52 / maxf(0.5, spd / 2.0)
            step.volume_db = _db(0.5 * master)
            step.pitch_scale = randf_range(0.85, 1.15)
            step.play()
