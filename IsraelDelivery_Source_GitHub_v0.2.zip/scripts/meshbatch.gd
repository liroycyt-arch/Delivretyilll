class_name MeshBatch
extends RefCounted
## איחוד גאומטריה: אלפי תיבות/חלונות/עצים נאספים לפי "מפתח חומר" ונשלחים כמעט-מש אחד לכל חומר.
## מפחית דרמטית את מספר הצמתים וה-draw calls. גם איסוף התנגשויות (תיבות) לגוף סטטי אחד.
## כל החומרים כאן עם cull_mode=DISABLED, ולכן סדר הקודקודים לא יכול להפוך משטח לבלתי נראה.

static var _cube: Dictionary = {}
static var _sphere: Dictionary = {}
static var _cyl: Dictionary = {}
static var _cone: Dictionary = {}

var data: Dictionary = {}     # key -> {"v","n","c","i"}
var solids: Array = []        # [center: Vector3, size: Vector3, rot_y: float]
var vert_count := 0


# ---------- תבניות ----------
static func _tpl_new() -> Dictionary:
    return {"v": PackedVector3Array(), "n": PackedVector3Array(), "i": PackedInt32Array()}


static func _tpl_quad(t: Dictionary, a: Vector3, b: Vector3, c: Vector3, d: Vector3, nrm: Vector3) -> void:
    var base: int = t.v.size()
    t.v.append(a)
    t.v.append(b)
    t.v.append(c)
    t.v.append(d)
    for _k in range(4):
        t.n.append(nrm)
    t.i.append_array(PackedInt32Array([base, base + 1, base + 2, base, base + 2, base + 3]))


static func cube_tpl() -> Dictionary:
    if not _cube.is_empty():
        return _cube
    var t := _tpl_new()
    var h := 0.5
    _tpl_quad(t, Vector3(h, -h, -h), Vector3(h, h, -h), Vector3(h, h, h), Vector3(h, -h, h), Vector3.RIGHT)
    _tpl_quad(t, Vector3(-h, -h, h), Vector3(-h, h, h), Vector3(-h, h, -h), Vector3(-h, -h, -h), Vector3.LEFT)
    _tpl_quad(t, Vector3(-h, h, -h), Vector3(-h, h, h), Vector3(h, h, h), Vector3(h, h, -h), Vector3.UP)
    _tpl_quad(t, Vector3(-h, -h, h), Vector3(-h, -h, -h), Vector3(h, -h, -h), Vector3(h, -h, h), Vector3.DOWN)
    _tpl_quad(t, Vector3(-h, -h, h), Vector3(h, -h, h), Vector3(h, h, h), Vector3(-h, h, h), Vector3.BACK)
    _tpl_quad(t, Vector3(h, -h, -h), Vector3(-h, -h, -h), Vector3(-h, h, -h), Vector3(h, h, -h), Vector3.FORWARD)
    _cube = t
    return _cube


## כדור/אליפסואיד (רדיוס 0.5 ליחידה)
static func sphere_tpl() -> Dictionary:
    if not _sphere.is_empty():
        return _sphere
    var t := _tpl_new()
    var seg := 10
    var rings := 6
    for r in range(rings + 1):
        var phi := PI * float(r) / rings
        for s in range(seg + 1):
            var th := TAU * float(s) / seg
            var nrm := Vector3(sin(phi) * cos(th), cos(phi), sin(phi) * sin(th))
            t.v.append(nrm * 0.5)
            t.n.append(nrm)
    for r in range(rings):
        for s in range(seg):
            var a := r * (seg + 1) + s
            var b := a + seg + 1
            t.i.append_array(PackedInt32Array([a, b, a + 1, a + 1, b, b + 1]))
    _sphere = t
    return _sphere


## גליל אנכי (רדיוס 0.5, גובה 1, ציר Y, ממורכז)
static func cyl_tpl() -> Dictionary:
    if not _cyl.is_empty():
        return _cyl
    var t := _tpl_new()
    var seg := 12
    for s in range(seg + 1):
        var th := TAU * float(s) / seg
        var nrm := Vector3(cos(th), 0.0, sin(th))
        t.v.append(Vector3(nrm.x * 0.5, -0.5, nrm.z * 0.5))
        t.n.append(nrm)
        t.v.append(Vector3(nrm.x * 0.5, 0.5, nrm.z * 0.5))
        t.n.append(nrm)
    for s in range(seg):
        var a := s * 2
        t.i.append_array(PackedInt32Array([a, a + 1, a + 2, a + 2, a + 1, a + 3]))
    var top: int = t.v.size()
    t.v.append(Vector3(0, 0.5, 0))
    t.n.append(Vector3.UP)
    for s in range(seg + 1):
        var th := TAU * float(s) / seg
        t.v.append(Vector3(cos(th) * 0.5, 0.5, sin(th) * 0.5))
        t.n.append(Vector3.UP)
    for s in range(seg):
        t.i.append_array(PackedInt32Array([top, top + 1 + s, top + 2 + s]))
    _cyl = t
    return _cyl


## חרוט (רדיוס בסיס 0.5, גובה 1, קודקוד למעלה)
static func cone_tpl() -> Dictionary:
    if not _cone.is_empty():
        return _cone
    var t := _tpl_new()
    var seg := 10
    t.v.append(Vector3(0, 0.5, 0))
    t.n.append(Vector3.UP)
    for s in range(seg + 1):
        var th := TAU * float(s) / seg
        var nrm := Vector3(cos(th), 0.4, sin(th)).normalized()
        t.v.append(Vector3(cos(th) * 0.5, -0.5, sin(th) * 0.5))
        t.n.append(nrm)
    for s in range(seg):
        t.i.append_array(PackedInt32Array([0, 1 + s, 2 + s]))
    _cone = t
    return _cone


# ---------- הוספה ----------
func _slot(key: String) -> Dictionary:
    if not data.has(key):
        data[key] = {"v": PackedVector3Array(), "n": PackedVector3Array(), "c": PackedColorArray(), "i": PackedInt32Array()}
    return data[key]


func add_tpl(key: String, tpl: Dictionary, center: Vector3, scale: Vector3, rot: Basis, col: Color) -> void:
    var d: Dictionary = _slot(key)
    var base: int = d.v.size()
    var tv: PackedVector3Array = tpl.v
    var tn: PackedVector3Array = tpl.n
    for k in range(tv.size()):
        d.v.append(center + rot * (tv[k] * scale))
        d.n.append(rot * tn[k])
        d.c.append(col)
    var ti: PackedInt32Array = tpl.i
    for k in range(ti.size()):
        d.i.append(ti[k] + base)
    vert_count += tv.size()


## תיבה. rot_y בלבד (סיבוב סביב Y) + הטיות אופציונליות (x,z).
func box(key: String, center: Vector3, size: Vector3, col: Color, rot_y := 0.0, solid := false, tilt := Vector3.ZERO) -> void:
    var rb := Basis.IDENTITY
    if rot_y != 0.0 or tilt != Vector3.ZERO:
        rb = Basis.from_euler(Vector3(tilt.x, rot_y, tilt.z))
    add_tpl(key, cube_tpl(), center, size, rb, col)
    if solid:
        solids.append([center, size, rot_y])


func sphere(key: String, center: Vector3, size: Vector3, col: Color) -> void:
    add_tpl(key, sphere_tpl(), center, size, Basis.IDENTITY, col)


func cyl(key: String, center: Vector3, radius: float, height: float, col: Color, solid := false) -> void:
    add_tpl(key, cyl_tpl(), center, Vector3(radius * 2.0, height, radius * 2.0), Basis.IDENTITY, col)
    if solid:
        solids.append([center, Vector3(radius * 2.0, height, radius * 2.0), 0.0])


func cone(key: String, center: Vector3, radius: float, height: float, col: Color) -> void:
    add_tpl(key, cone_tpl(), center, Vector3(radius * 2.0, height, radius * 2.0), Basis.IDENTITY, col)


## מישור אנכי (חלון/שלט) הפונה לכיוון face: 0=+z, 1=-z, 2=+x, 3=-x. מרכז, רוחב, גובה.
func wall_quad(key: String, center: Vector3, w: float, h: float, face: int, col: Color) -> void:
    var d: Dictionary = _slot(key)
    var base: int = d.v.size()
    var right := Vector3.RIGHT
    var nrm := Vector3.BACK
    match face:
        1:
            right = Vector3.LEFT
            nrm = Vector3.FORWARD
        2:
            right = Vector3.FORWARD
            nrm = Vector3.RIGHT
        3:
            right = Vector3.BACK
            nrm = Vector3.LEFT
    var hw := w * 0.5
    var hh := h * 0.5
    d.v.append(center - right * hw - Vector3(0, hh, 0))
    d.v.append(center - right * hw + Vector3(0, hh, 0))
    d.v.append(center + right * hw + Vector3(0, hh, 0))
    d.v.append(center + right * hw - Vector3(0, hh, 0))
    for _k in range(4):
        d.n.append(nrm)
        d.c.append(col)
    d.i.append_array(PackedInt32Array([base, base + 1, base + 2, base, base + 2, base + 3]))
    vert_count += 4


## מישור אופקי (דשא, חציה, פס) ממורכז, בגודל sx × sz, בגובה y.
func flat(key: String, center: Vector3, sx: float, sz: float, col: Color, rot_y := 0.0) -> void:
    var d: Dictionary = _slot(key)
    var base: int = d.v.size()
    var rb := Basis(Vector3.UP, rot_y)
    var hx := sx * 0.5
    var hz := sz * 0.5
    d.v.append(center + rb * Vector3(-hx, 0, -hz))
    d.v.append(center + rb * Vector3(-hx, 0, hz))
    d.v.append(center + rb * Vector3(hx, 0, hz))
    d.v.append(center + rb * Vector3(hx, 0, -hz))
    for _k in range(4):
        d.n.append(Vector3.UP)
        d.c.append(col)
    d.i.append_array(PackedInt32Array([base, base + 1, base + 2, base, base + 2, base + 3]))
    vert_count += 4


## עלה דקל / משטח מוטה: מרובע דו-צדדי בין שתי נקודות עם רוחב.
func blade(key: String, from_p: Vector3, to_p: Vector3, width: float, col: Color) -> void:
    var d: Dictionary = _slot(key)
    var base: int = d.v.size()
    var dir := (to_p - from_p)
    var side := dir.cross(Vector3.UP)
    if side.length() < 0.001:
        side = Vector3.RIGHT
    side = side.normalized() * width * 0.5
    d.v.append(from_p - side * 0.35)
    d.v.append(from_p + side * 0.35)
    d.v.append(to_p + side * 0.05)
    d.v.append(to_p - side * 0.05)
    var nrm := side.cross(dir).normalized()
    for _k in range(4):
        d.n.append(nrm)
        d.c.append(col)
    d.i.append_array(PackedInt32Array([base, base + 1, base + 2, base, base + 2, base + 3]))
    vert_count += 4


## מנסרה רב-צלעית (3=משולש, 4=ריבוע, 16=כמעט גליל), ציר Y. אם solid_size שונה מאפס - מוסיף תיבת התנגשות.
func prism(key: String, center: Vector3, radius: float, height: float, sides: int, col: Color, rot := 0.0, solid_size := Vector3.ZERO) -> void:
    var d: Dictionary = _slot(key)
    var base: int = d.v.size()
    for s in range(sides + 1):
        var th := rot + TAU * float(s) / sides
        var nrm := Vector3(cos(th), 0.0, sin(th))
        d.v.append(center + Vector3(nrm.x * radius, -height * 0.5, nrm.z * radius))
        d.n.append(nrm)
        d.c.append(col)
        d.v.append(center + Vector3(nrm.x * radius, height * 0.5, nrm.z * radius))
        d.n.append(nrm)
        d.c.append(col)
    for s in range(sides):
        var a := base + s * 2
        d.i.append_array(PackedInt32Array([a, a + 1, a + 2, a + 2, a + 1, a + 3]))
    var top: int = d.v.size()
    d.v.append(center + Vector3(0, height * 0.5, 0))
    d.n.append(Vector3.UP)
    d.c.append(col)
    for s in range(sides + 1):
        var th := rot + TAU * float(s) / sides
        d.v.append(center + Vector3(cos(th) * radius, height * 0.5, sin(th) * radius))
        d.n.append(Vector3.UP)
        d.c.append(col)
    for s in range(sides):
        d.i.append_array(PackedInt32Array([top, top + 1 + s, top + 2 + s]))
    vert_count += (sides + 1) * 2 + sides + 2
    if solid_size != Vector3.ZERO:
        solids.append([center, solid_size, 0.0])


# ---------- פלט ----------
## יוצר MeshInstance3D לכל חומר ו-StaticBody3D אחד לכל ההתנגשויות. mats: key -> Material.
func commit(parent: Node3D, mats: Dictionary, shadow_keys: Array = [], vis_end: Dictionary = {}) -> void:
    for key in data:
        var d: Dictionary = data[key]
        if d.v.size() == 0:
            continue
        var arrays := []
        arrays.resize(Mesh.ARRAY_MAX)
        arrays[Mesh.ARRAY_VERTEX] = d.v
        arrays[Mesh.ARRAY_NORMAL] = d.n
        arrays[Mesh.ARRAY_COLOR] = d.c
        arrays[Mesh.ARRAY_INDEX] = d.i
        var am := ArrayMesh.new()
        am.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, arrays)
        var mi := MeshInstance3D.new()
        mi.mesh = am
        mi.name = "B_" + str(key)
        if mats.has(key):
            mi.material_override = mats[key]
        if not shadow_keys.has(key):
            mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
        if vis_end.has(key):
            mi.visibility_range_end = float(vis_end[key])
            mi.visibility_range_end_margin = 10.0
            mi.visibility_range_fade_mode = GeometryInstance3D.VISIBILITY_RANGE_FADE_DISABLED
        parent.add_child(mi)
    if solids.size() > 0:
        var sb := StaticBody3D.new()
        sb.name = "Solids"
        for s in solids:
            var cs := CollisionShape3D.new()
            var sh := BoxShape3D.new()
            sh.size = s[1]
            cs.shape = sh
            cs.position = s[0]
            cs.rotation.y = float(s[2])
            sb.add_child(cs)
        parent.add_child(sb)
    data.clear()
    solids.clear()
    vert_count = 0


## בונה ArrayMesh יחיד (משטח לכל מפתח, בסדר הנתון) ומשייך חומרים. לשימוש חוזר בדגמי רכב.
func to_mesh(keys: Array, mats: Dictionary) -> ArrayMesh:
    var am := ArrayMesh.new()
    for key in keys:
        if not data.has(key):
            continue
        var d: Dictionary = data[key]
        if d.v.size() == 0:
            continue
        var arrays := []
        arrays.resize(Mesh.ARRAY_MAX)
        arrays[Mesh.ARRAY_VERTEX] = d.v
        arrays[Mesh.ARRAY_NORMAL] = d.n
        arrays[Mesh.ARRAY_COLOR] = d.c
        arrays[Mesh.ARRAY_INDEX] = d.i
        am.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, arrays)
        if mats.has(key):
            am.surface_set_material(am.get_surface_count() - 1, mats[key])
    return am
