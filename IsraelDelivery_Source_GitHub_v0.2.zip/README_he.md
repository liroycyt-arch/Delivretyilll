# משלוחים בישראל — פרויקט Godot 4.3 (גרסה 0.2.0)

סימולטור שליחויות בתל אביב. פרויקט Godot 4 אמיתי (GDScript), ללא נכסים חיצוניים כבדים: הגאומטריה והצלילים נוצרים בקוד.

## מצב הבדיקה — חשוב לקרוא
**הקוד של גרסה זו נכתב ונבדק סטטית בלבד, ולא הורץ ב-Godot.** בסביבת הפיתוח לא היה Godot ולא הייתה גישת רשת, ולכן:
- לא נבנה EXE ולא הורץ המשחק. אין תוצר בנייה בחבילה זו.
- בוצעו רק בדיקות סטטיות: איזון סוגריים, כפילות פונקציות, קריאות לפונקציות לא מוגדרות, ותקינות YAML.
- סביר שיופיעו שגיאות הידור/ריצה קטנות בהרצה הראשונה. ה-Workflow מריץ בדיקה אוטומטית (`--autotest`) ומציג את השגיאות בבירור; שלחו אותן ואתקן.

פירוט מלא בקובץ `CHANGES_he.md`.

## דרישות
- Godot **4.3 stable** (Forward+). Export Templates של אותה גרסה.
- Windows 10/11 x64 לבנייה והרצה של ה-EXE.

## פתיחה והרצה
1. הורידו Godot 4.3 מ-godotengine.org.
2. Import → בחרו את `project.godot` → Open.
3. F5 להרצה.

### מקשים
W/A/S/D תנועה · רווח בלימה · **Shift / B** — Boost (5 שניות, טעינה 15 שניות) · **F** ירידה מהכלי / עלייה · E פעולה (איסוף, מסירה, קניות, כספומט) · M מפה · P טלפון · C מצלמה · **לחצן ימני לחוץ** סיבוב מצלמה · גלגלת עכבר זום · Esc השהיה.

## בנייה ל-Windows
### אוטומטית ב-GitHub Actions (מומלץ)
1. צרו מאגר ב-GitHub והעלו את **תוכן** התיקייה (לא ZIP): `project.godot`, `scripts/`, `scenes/`, `.github/` וכו'.
   ```
   git init
   git add .
   git commit -m "Israel Delivery 0.2.0"
   git branch -M main
   git remote add origin https://github.com/<user>/<repo>.git
   git push -u origin main
   ```
2. ה-Workflow `.github/workflows/main.yml` רץ אוטומטית ב-push ל-main/master, ב-Pull Request, בתג `v*`, ו**ידנית**: לשונית Actions → "Build Windows EXE" → Run workflow.
3. בסיום: ב-Actions בחרו את הריצה → **Artifacts** → `IsraelDelivery-Windows` (ZIP עם `IsraelDelivery.exe`, ו-`IsraelDelivery_Setup.exe` אם המתקין נבנה, ולוגים).
4. בתג `v*` (למשל `git tag v0.2.0 && git push --tags`) הקבצים מצורפים גם ל-Release.

שלבי ה-Workflow: איתור הפרויקט → הורדת Godot, תבניות ייצוא, rcedit ופונט Rubik → ייבוא (נכשל בשגיאת סקריפט) → ייצוא EXE יחיד → מתקין Inno Setup (אזהרה אם נכשל) → בדיקת משחק אוטומטית (נכשלת בגלוי) → העלאת Artifacts תמיד (גם בכישלון, כולל הלוגים).

### ידנית
1. התקינו Export Templates (Editor → Manage Export Templates).
2. הריצו `build_windows.bat`. נוצר `build/IsraelDelivery.exe` (ה-PCK משובץ).
3. אופציונלי: פתחו `installer/setup.iss` ב-Inno Setup → Compile → `build/IsraelDelivery_Setup.exe`.

## מבנה הפרויקט
```
project.godot            הגדרות, autoload: Game
scenes/main.tscn         סצנה יחידה (Main)
scripts/game.gd          מצב גלובלי: כסף, בנק, שעון, Boost, משימות, ניווט, שמירה (v2)
scripts/main.gd          תזמור: שמיים/יום-לילה, תצוגה, אינטראקציות, בדיקה אוטומטית
scripts/world.gd         עיר, בלוקים, מבנים, מקומות מיוחדים, רמזורים, רכבת, ניווט (A*)
scripts/meshbatch.gd     איחוד גאומטריה (ביצועים)
scripts/traffic.gd       תנועה עירונית (Pool)
scripts/player.gd        שליח + כלי תחבורה: פיזיקה, מצלמה, Boost, הליכה
scripts/figure.gd        דמות: שלד היררכי + IK, נשימה/מתיחות, הליכה
scripts/ui.gd            תפריטים, HUD, טלפון ואפליקציות, קניות, הגדרות
scripts/mapview.gd       מפה ומיני-מפה
scripts/audio.gd         מנוע/אווירה/צעדים (מחוללים בקוד)
```

## שמירה
`user://save.json` (גרסה 2; כולל מזומן, בנק, שעת משחק, מלאי, הגדרות תצוגה/מצלמה). שמירות ישנות (גרסה 1) נטענות עם ערכי ברירת מחדל לשדות החדשים. קובץ פגום → נטען הגיבוי `save.bak.json`, ואם גם הוא פגום — מתחילים נקי בלי קריסה.

## רישיונות
- פונט Rubik (OFL) נטען בזמן הבנייה אם חסר.
- אין בחבילה קבצי שמע/מודלים חיצוניים; הצלילים והגאומטריה נוצרים בקוד.
- OpenStreetMap: לא בשימוש. בעת שימוש בעתיד יש לצרף © OpenStreetMap contributors (ODbL).
